# SK Sales — E-commerce Platform 🛍️

A complete, modern, fully responsive e-commerce web application built for **SK Sales**, tailored for customers in Nepal. Built with **Next.js (App Router)**, **PostgreSQL**, **Drizzle ORM**, and **Tailwind CSS**.

Contact: 📞 9767948789 · ✉️ bksuprim634@gmail.com

---

## ✨ Features

### Customer Storefront
- Home page with hero, categories, featured / new / best-selling products, deals, recently viewed, reviews, and "Why choose us"
- Product catalog with search, category / brand / price / rating / availability filters, and sorting
- Product detail page with gallery, variants, specs, ratings, reviews, share, add-to-cart, buy-now, wishlist
- Shopping cart with quantity controls, coupon codes, delivery + tax calculation
- 5-step checkout (customer info → address → delivery → payment → confirm)
- Customer accounts: register, login, logout, forgot / reset password, profile, addresses, order history, order tracking, cancel/return, wishlist, notifications
- Invoices (print / download)

### Payment Methods (Nepal)
- **eSewa** — integration structure with server-side signature signing and transaction verification (configure via env vars)
- **Bank Transfer** — admin-configurable bank details + customer receipt upload + admin verification
- **Cash on Delivery (COD)** — toggleable by admin

### Admin Dashboard (`/admin`)
- Overview with real-time stats and charts (sales, orders, best-sellers, status & payment distribution)
- Orders management (search, filter, status updates, payment verification, invoices, contact customer)
- Products (add / edit / delete / hide, images via emoji themes, pricing, stock, tags)
- Categories, Customers, Inventory (low/out-of-stock alerts, stock updates)
- Coupons (percent / fixed, min order, max discount, usage limits, expiry)
- Reviews moderation, Returns/Refunds, Notifications, Reports, Settings

### Security
- Passwords hashed with bcrypt
- JWT sessions stored in secure HTTP-only cookies
- Role-based authorization (customer vs admin)
- Server-side validation; secrets kept server-side only

---

## 🚀 Getting Started

### 1. Prerequisites
- Node.js 18+
- PostgreSQL database

### 2. Environment
Copy `.env.example` to `.env` and fill in values:

```bash
cp .env.example .env
```

| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | PostgreSQL connection string |
| `AUTH_SECRET` | Long random string for signing sessions |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | Initial admin credentials (seeded on first run) |
| `NEXT_PUBLIC_BASE_URL` | Public site URL (for payment redirects) |
| `ESEWA_MERCHANT_ID` / `ESEWA_SECRET_KEY` | eSewa credentials (optional; blank = demo mode) |

### 3. Install & set up the database

```bash
npm install
npx drizzle-kit push      # creates all tables
npm run build
npm start
```

### 4. Seed demo data
Once the app is running, seed realistic demo products, categories, coupons, reviews and orders:

```bash
curl -X POST http://localhost:3000/api/seed
```

Or open the app — the storefront works immediately after seeding.

---

## 👤 Default Accounts (after seeding)

| Role | Email | Password |
|------|-------|----------|
| Admin | `admin@sksales.com` (or your `ADMIN_EMAIL`) | `Admin@123` (or your `ADMIN_PASSWORD`) |
| Customer | `ram@example.com` | `Customer@123` |

> ⚠️ Change the admin password immediately from **Admin → Settings → Security**.

---

## 🧹 Removing Demo Data
Go to **Admin → Settings → Security → Danger Zone → Delete All Demo Data**. This clears all demo products, categories, orders, reviews and coupons so you can add your real inventory.

---

## ☁️ Deployment

This app deploys to any Node.js host (Vercel, Railway, Render, VPS, etc.).

1. Provision a PostgreSQL database and set `DATABASE_URL`.
2. Set the other environment variables (`AUTH_SECRET`, `ADMIN_*`, `NEXT_PUBLIC_BASE_URL`, optional eSewa keys).
3. Run migrations: `npx drizzle-kit push`
4. Build & start: `npm run build && npm start`
5. Seed once: `POST /api/seed`

### Notes for eSewa in production
- Set `ESEWA_MERCHANT_ID` and `ESEWA_SECRET_KEY` from your eSewa merchant dashboard.
- Update the gateway URL in `src/app/api/payments/esewa/route.ts` from the RC (sandbox) endpoint to the production endpoint.
- Never commit real credentials.

---

## 🗄️ Database Schema
Tables: `users`, `addresses`, `categories`, `products`, `orders`, `order_items`, `coupons`, `reviews`, `wishlists`, `notifications`, `returns`, `messages`, `settings` — with proper primary keys, foreign keys, indexes and timestamps.

---

Built with ❤️ for SK Sales.
