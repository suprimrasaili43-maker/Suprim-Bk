import {
  pgTable,
  serial,
  text,
  varchar,
  integer,
  boolean,
  timestamp,
  numeric,
  jsonb,
  index,
} from "drizzle-orm/pg-core";

// ---------------- Users ----------------
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 160 }).notNull(),
    email: varchar("email", { length: 200 }).notNull().unique(),
    phone: varchar("phone", { length: 40 }),
    passwordHash: text("password_hash").notNull(),
    role: varchar("role", { length: 20 }).notNull().default("customer"), // customer | admin
    resetToken: varchar("reset_token", { length: 120 }),
    resetTokenExpiry: timestamp("reset_token_expiry"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => ({
    emailIdx: index("users_email_idx").on(t.email),
  }),
);

// ---------------- Addresses ----------------
export const addresses = pgTable("addresses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  label: varchar("label", { length: 60 }).default("Home"),
  province: varchar("province", { length: 80 }),
  district: varchar("district", { length: 80 }),
  city: varchar("city", { length: 80 }),
  area: varchar("area", { length: 120 }),
  fullAddress: text("full_address"),
  postalCode: varchar("postal_code", { length: 20 }),
  phone: varchar("phone", { length: 40 }),
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------------- Categories ----------------
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  slug: varchar("slug", { length: 140 }).notNull().unique(),
  parentId: integer("parent_id"),
  image: text("image"),
  emoji: varchar("emoji", { length: 12 }),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------------- Products ----------------
export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 220 }).notNull(),
    slug: varchar("slug", { length: 240 }).notNull().unique(),
    description: text("description"),
    sku: varchar("sku", { length: 60 }),
    brand: varchar("brand", { length: 120 }),
    categoryId: integer("category_id").references(() => categories.id, {
      onDelete: "set null",
    }),
    price: numeric("price", { precision: 12, scale: 2 }).notNull(), // selling (discounted) price
    originalPrice: numeric("original_price", { precision: 12, scale: 2 }),
    discountPercent: integer("discount_percent").default(0),
    stock: integer("stock").notNull().default(0),
    lowStockThreshold: integer("low_stock_threshold").default(5),
    soldCount: integer("sold_count").default(0),
    image: text("image"),
    images: jsonb("images").$type<string[]>().default([]),
    emoji: varchar("emoji", { length: 12 }),
    gradient: varchar("gradient", { length: 80 }),
    specs: jsonb("specs").$type<{ label: string; value: string }[]>().default([]),
    variants: jsonb("variants")
      .$type<{ name: string; options: string[] }[]>()
      .default([]),
    rating: numeric("rating", { precision: 3, scale: 2 }).default("0"),
    reviewCount: integer("review_count").default(0),
    featured: boolean("featured").default(false),
    isNew: boolean("is_new").default(false),
    bestSeller: boolean("best_seller").default(false),
    hidden: boolean("hidden").default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => ({
    catIdx: index("products_category_idx").on(t.categoryId),
    slugIdx: index("products_slug_idx").on(t.slug),
  }),
);

// ---------------- Orders ----------------
export const orders = pgTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    orderNumber: varchar("order_number", { length: 40 }).notNull().unique(),
    userId: integer("user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    customerName: varchar("customer_name", { length: 160 }),
    customerEmail: varchar("customer_email", { length: 200 }),
    phone: varchar("phone", { length: 40 }),
    status: varchar("status", { length: 30 }).notNull().default("Pending"),
    paymentMethod: varchar("payment_method", { length: 30 }).notNull(),
    paymentStatus: varchar("payment_status", { length: 30 })
      .notNull()
      .default("Unpaid"),
    subtotal: numeric("subtotal", { precision: 12, scale: 2 }).notNull(),
    deliveryCharge: numeric("delivery_charge", { precision: 12, scale: 2 }).default(
      "0",
    ),
    tax: numeric("tax", { precision: 12, scale: 2 }).default("0"),
    discount: numeric("discount", { precision: 12, scale: 2 }).default("0"),
    total: numeric("total", { precision: 12, scale: 2 }).notNull(),
    couponCode: varchar("coupon_code", { length: 60 }),
    deliveryMethod: varchar("delivery_method", { length: 60 }),
    address: jsonb("address").$type<Record<string, string>>(),
    note: text("note"),
    receiptUrl: text("receipt_url"),
    transactionId: varchar("transaction_id", { length: 120 }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => ({
    userIdx: index("orders_user_idx").on(t.userId),
    statusIdx: index("orders_status_idx").on(t.status),
  }),
);

// ---------------- Order Items ----------------
export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id")
    .notNull()
    .references(() => orders.id, { onDelete: "cascade" }),
  productId: integer("product_id").references(() => products.id, {
    onDelete: "set null",
  }),
  name: varchar("name", { length: 220 }).notNull(),
  price: numeric("price", { precision: 12, scale: 2 }).notNull(),
  quantity: integer("quantity").notNull(),
  variant: varchar("variant", { length: 160 }),
  emoji: varchar("emoji", { length: 12 }),
  gradient: varchar("gradient", { length: 80 }),
});

// ---------------- Coupons ----------------
export const coupons = pgTable("coupons", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 60 }).notNull().unique(),
  type: varchar("type", { length: 20 }).notNull().default("percent"), // percent | fixed
  value: numeric("value", { precision: 12, scale: 2 }).notNull(),
  minOrder: numeric("min_order", { precision: 12, scale: 2 }).default("0"),
  maxDiscount: numeric("max_discount", { precision: 12, scale: 2 }),
  expiresAt: timestamp("expires_at"),
  usageLimit: integer("usage_limit"),
  usedCount: integer("used_count").default(0),
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------------- Reviews ----------------
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id, { onDelete: "cascade" }),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  userName: varchar("user_name", { length: 160 }),
  rating: integer("rating").notNull(),
  comment: text("comment"),
  approved: boolean("approved").default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------------- Wishlists ----------------
export const wishlists = pgTable("wishlists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------------- Notifications ----------------
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
  forAdmin: boolean("for_admin").default(false),
  type: varchar("type", { length: 50 }),
  title: varchar("title", { length: 200 }),
  message: text("message"),
  read: boolean("read").default(false),
  link: varchar("link", { length: 200 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------------- Returns / Refunds ----------------
export const returns = pgTable("returns", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id")
    .notNull()
    .references(() => orders.id, { onDelete: "cascade" }),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  reason: text("reason"),
  status: varchar("status", { length: 30 }).notNull().default("Return Requested"),
  type: varchar("type", { length: 20 }).default("return"), // return | refund
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ---------------- Contact Messages ----------------
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }),
  email: varchar("email", { length: 200 }),
  phone: varchar("phone", { length: 40 }),
  subject: varchar("subject", { length: 200 }),
  message: text("message"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------------- Settings (singleton) ----------------
export const settings = pgTable("settings", {
  id: integer("id").primaryKey().default(1),
  data: jsonb("data").$type<Record<string, unknown>>().notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
