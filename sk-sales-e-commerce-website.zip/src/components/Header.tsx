"use client";

import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { useStore } from "./store";

type Cat = { id: number; name: string; slug: string; emoji?: string | null };

export default function Header() {
  const { cartCount, wishCount, user, logout } = useStore();
  const router = useRouter();
  const pathname = usePathname();
  const [q, setQ] = useState("");
  const [cats, setCats] = useState<Cat[]>([]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [catOpen, setCatOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifs, setNotifs] = useState<{ id: number; title: string; message: string; read: boolean; link?: string }[]>([]);
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    fetch("/api/categories")
      .then((r) => r.json())
      .then((d) => setCats(d.categories || []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (user) {
      fetch("/api/notifications?scope=user")
        .then((r) => r.json())
        .then((d) => {
          setNotifs(d.notifications || []);
          setUnread(d.unread || 0);
        })
        .catch(() => {});
    }
  }, [user, pathname]);

  const search = (e: React.FormEvent) => {
    e.preventDefault();
    if (q.trim()) router.push(`/shop?q=${encodeURIComponent(q.trim())}`);
  };

  const markRead = async () => {
    setNotifOpen((o) => !o);
    if (!notifOpen && unread > 0) {
      await fetch("/api/notifications", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scope: "user" }),
      });
      setUnread(0);
    }
  };

  if (pathname?.startsWith("/admin")) return null;

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/shop", label: "Shop" },
    { href: "/categories", label: "Categories" },
    { href: "/deals", label: "Deals" },
    { href: "/about", label: "About Us" },
    { href: "/contact", label: "Contact" },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      {/* Top bar */}
      <div className="bg-indigo-600 text-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-1.5 text-xs">
          <span className="hidden sm:block">📞 9767948789 · Free delivery over Rs. 5,000</span>
          <span className="sm:hidden">Free delivery over Rs. 5,000</span>
          <span>✉️ bksuprim634@gmail.com</span>
        </div>
      </div>

      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3">
        <button className="md:hidden text-2xl" onClick={() => setMenuOpen(true)} aria-label="Menu">
          ☰
        </button>
        <Link href="/" className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-600 text-lg font-black text-white">
            SK
          </span>
          <span className="hidden text-lg font-extrabold tracking-tight text-slate-900 sm:block">
            SK <span className="text-indigo-600">Sales</span>
          </span>
        </Link>

        <form onSubmit={search} className="relative mx-2 flex flex-1 items-center">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search products, brands, SKU..."
            className="w-full rounded-full border border-slate-200 bg-slate-50 px-4 py-2 text-sm outline-none focus:border-indigo-400 focus:bg-white"
          />
          <button type="submit" className="absolute right-1 rounded-full bg-indigo-600 px-3 py-1.5 text-sm text-white">
            🔍
          </button>
        </form>

        <div className="flex items-center gap-1 sm:gap-3">
          {/* Notifications */}
          {user && (
            <div className="relative">
              <button onClick={markRead} className="relative p-1 text-xl" aria-label="Notifications">
                🔔
                {unread > 0 && (
                  <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">
                    {unread}
                  </span>
                )}
              </button>
              {notifOpen && (
                <div className="absolute right-0 top-10 w-80 max-w-[90vw] overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl">
                  <div className="border-b px-4 py-2 text-sm font-semibold">Notifications</div>
                  <div className="max-h-80 overflow-y-auto">
                    {notifs.length === 0 && <p className="p-4 text-sm text-slate-400">No notifications yet.</p>}
                    {notifs.map((n) => (
                      <Link
                        key={n.id}
                        href={n.link || "#"}
                        onClick={() => setNotifOpen(false)}
                        className="block border-b px-4 py-2 text-sm hover:bg-slate-50"
                      >
                        <p className="font-medium text-slate-800">{n.title}</p>
                        <p className="text-xs text-slate-500">{n.message}</p>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          <Link href="/account/wishlist" className="relative p-1 text-xl" aria-label="Wishlist">
            ♡
            {wishCount > 0 && (
              <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">
                {wishCount}
              </span>
            )}
          </Link>

          <Link href="/cart" className="relative p-1 text-xl" aria-label="Cart">
            🛒
            {cartCount > 0 && (
              <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-indigo-600 px-1 text-[10px] font-bold text-white">
                {cartCount}
              </span>
            )}
          </Link>

          {/* Account */}
          <div className="group relative hidden md:block">
            <button className="flex items-center gap-1 rounded-full border border-slate-200 px-3 py-1.5 text-sm">
              <span>👤</span>
              <span className="max-w-24 truncate">{user ? user.name.split(" ")[0] : "Account"}</span>
            </button>
            <div className="invisible absolute right-0 top-full w-44 rounded-xl border border-slate-200 bg-white py-1 opacity-0 shadow-xl transition group-hover:visible group-hover:opacity-100">
              {user ? (
                <>
                  <Link href="/account" className="block px-4 py-2 text-sm hover:bg-slate-50">My Account</Link>
                  <Link href="/account/orders" className="block px-4 py-2 text-sm hover:bg-slate-50">My Orders</Link>
                  <Link href="/account/wishlist" className="block px-4 py-2 text-sm hover:bg-slate-50">Wishlist</Link>
                  {user.role === "admin" && (
                    <Link href="/admin" className="block px-4 py-2 text-sm font-semibold text-indigo-600 hover:bg-slate-50">Admin Panel</Link>
                  )}
                  <button onClick={() => logout()} className="block w-full px-4 py-2 text-left text-sm text-rose-600 hover:bg-slate-50">Logout</button>
                </>
              ) : (
                <>
                  <Link href="/login" className="block px-4 py-2 text-sm hover:bg-slate-50">Login</Link>
                  <Link href="/register" className="block px-4 py-2 text-sm hover:bg-slate-50">Register</Link>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Desktop nav */}
      <nav className="hidden border-t border-slate-100 md:block">
        <div className="mx-auto flex max-w-7xl items-center gap-6 px-4 py-2 text-sm font-medium">
          <div
            className="relative"
            onMouseEnter={() => setCatOpen(true)}
            onMouseLeave={() => setCatOpen(false)}
          >
            <button className="flex items-center gap-1 rounded-md bg-indigo-50 px-3 py-1.5 text-indigo-700">
              ☰ All Categories
            </button>
            {catOpen && (
              <div className="absolute left-0 top-full z-50 w-56 rounded-xl border border-slate-200 bg-white py-2 shadow-xl">
                {cats.map((c) => (
                  <Link key={c.id} href={`/shop?category=${c.slug}`} className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-slate-50">
                    <span>{c.emoji}</span> {c.name}
                  </Link>
                ))}
              </div>
            )}
          </div>
          {navLinks.map((l) => (
            <Link key={l.href} href={l.href} className={`hover:text-indigo-600 ${pathname === l.href ? "text-indigo-600" : "text-slate-700"}`}>
              {l.label}
            </Link>
          ))}
        </div>
      </nav>

      {/* Mobile drawer */}
      {menuOpen && (
        <div className="fixed inset-0 z-[60] md:hidden" onClick={() => setMenuOpen(false)}>
          <div className="absolute inset-0 bg-black/40" />
          <div className="absolute left-0 top-0 h-full w-72 max-w-[80vw] animate-slide-in bg-white p-4" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <span className="text-lg font-extrabold">SK <span className="text-indigo-600">Sales</span></span>
              <button onClick={() => setMenuOpen(false)} className="text-2xl">×</button>
            </div>
            {user && <p className="mb-3 rounded-lg bg-slate-50 p-2 text-sm">Hi, {user.name}</p>}
            <div className="flex flex-col">
              {navLinks.map((l) => (
                <Link key={l.href} href={l.href} onClick={() => setMenuOpen(false)} className="border-b py-2.5 text-sm">
                  {l.label}
                </Link>
              ))}
              <p className="mt-3 mb-1 text-xs font-semibold uppercase text-slate-400">Categories</p>
              {cats.map((c) => (
                <Link key={c.id} href={`/shop?category=${c.slug}`} onClick={() => setMenuOpen(false)} className="py-1.5 text-sm">
                  {c.emoji} {c.name}
                </Link>
              ))}
              <div className="mt-4 flex flex-col gap-2">
                {user ? (
                  <>
                    <Link href="/account" onClick={() => setMenuOpen(false)} className="rounded-lg bg-indigo-600 py-2 text-center text-sm text-white">My Account</Link>
                    {user.role === "admin" && (
                      <Link href="/admin" onClick={() => setMenuOpen(false)} className="rounded-lg border border-indigo-600 py-2 text-center text-sm text-indigo-600">Admin Panel</Link>
                    )}
                    <button onClick={() => { logout(); setMenuOpen(false); }} className="rounded-lg border py-2 text-center text-sm text-rose-600">Logout</button>
                  </>
                ) : (
                  <>
                    <Link href="/login" onClick={() => setMenuOpen(false)} className="rounded-lg bg-indigo-600 py-2 text-center text-sm text-white">Login</Link>
                    <Link href="/register" onClick={() => setMenuOpen(false)} className="rounded-lg border py-2 text-center text-sm">Register</Link>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
