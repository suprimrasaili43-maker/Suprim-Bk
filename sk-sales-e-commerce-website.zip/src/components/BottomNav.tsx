"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useStore } from "./store";

export default function BottomNav() {
  const pathname = usePathname();
  const { cartCount, wishCount, user } = useStore();
  if (pathname?.startsWith("/admin")) return null;

  const items = [
    { href: "/", label: "Home", icon: "🏠" },
    { href: "/shop", label: "Shop", icon: "🛍️" },
    { href: "/cart", label: "Cart", icon: "🛒", badge: cartCount },
    { href: "/account/wishlist", label: "Wishlist", icon: "♡", badge: wishCount },
    { href: user ? "/account" : "/login", label: "Account", icon: "👤" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 grid grid-cols-5 border-t border-slate-200 bg-white md:hidden">
      {items.map((it) => {
        const active = pathname === it.href;
        return (
          <Link key={it.label} href={it.href} className={`relative flex flex-col items-center py-2 text-[11px] ${active ? "text-indigo-600" : "text-slate-500"}`}>
            <span className="text-lg">{it.icon}</span>
            {it.label}
            {!!it.badge && it.badge > 0 && (
              <span className="absolute right-4 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[9px] font-bold text-white">
                {it.badge}
              </span>
            )}
          </Link>
        );
      })}
    </nav>
  );
}
