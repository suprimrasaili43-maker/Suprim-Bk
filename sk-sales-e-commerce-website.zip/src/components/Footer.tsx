"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Footer() {
  const pathname = usePathname();
  if (pathname?.startsWith("/admin")) return null;

  return (
    <footer className="mt-12 border-t border-slate-200 bg-slate-900 text-slate-300">
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-8 px-4 py-10 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-600 text-lg font-black text-white">SK</span>
            <span className="text-lg font-extrabold text-white">SK Sales</span>
          </div>
          <p className="mt-3 text-sm text-slate-400">Your trusted online shopping store. Quality products delivered across Nepal.</p>
        </div>

        <div>
          <h4 className="mb-3 font-semibold text-white">Quick Links</h4>
          <ul className="space-y-2 text-sm">
            <li><Link href="/" className="hover:text-white">Home</Link></li>
            <li><Link href="/shop" className="hover:text-white">Shop</Link></li>
            <li><Link href="/about" className="hover:text-white">About Us</Link></li>
            <li><Link href="/contact" className="hover:text-white">Contact</Link></li>
            <li><Link href="/account/orders" className="hover:text-white">Orders</Link></li>
            <li><Link href="/policy/privacy" className="hover:text-white">Privacy Policy</Link></li>
            <li><Link href="/policy/terms" className="hover:text-white">Terms &amp; Conditions</Link></li>
            <li><Link href="/policy/returns" className="hover:text-white">Return Policy</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="mb-3 font-semibold text-white">Customer Support</h4>
          <ul className="space-y-2 text-sm">
            <li>📞 <a href="tel:9767948789" className="hover:text-white">9767948789</a></li>
            <li>✉️ <a href="mailto:bksuprim634@gmail.com" className="hover:text-white">bksuprim634@gmail.com</a></li>
            <li>📍 Kathmandu, Nepal</li>
            <li className="pt-1"><Link href="/contact" className="text-indigo-400 hover:text-indigo-300">Send us a message →</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="mb-3 font-semibold text-white">Payment Methods</h4>
          <div className="flex flex-wrap gap-2">
            <span className="rounded-md bg-green-600 px-3 py-1.5 text-xs font-semibold text-white">eSewa</span>
            <span className="rounded-md bg-slate-700 px-3 py-1.5 text-xs font-semibold text-white">🏦 Bank Transfer</span>
            <span className="rounded-md bg-amber-600 px-3 py-1.5 text-xs font-semibold text-white">💵 Cash on Delivery</span>
          </div>
          <p className="mt-4 text-xs text-slate-500">100% secure payments. Your data is protected.</p>
        </div>
      </div>
      <div className="border-t border-slate-800 py-4 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} SK Sales. All rights reserved.
      </div>
    </footer>
  );
}
