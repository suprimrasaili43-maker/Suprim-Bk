"use client";

import Link from "next/link";
import { useStore, type WishItem } from "./store";
import { formatNPR } from "@/lib/utils";

export function Stars({ rating, size = "text-sm" }: { rating: number; size?: string }) {
  const full = Math.round(rating);
  return (
    <span className={`${size} text-amber-400 leading-none`}>
      {"★★★★★".slice(0, full)}
      <span className="text-slate-300">{"★★★★★".slice(full)}</span>
    </span>
  );
}

export type ProductLike = {
  id: number;
  name: string;
  slug: string;
  price: string | number;
  originalPrice?: string | number | null;
  discountPercent?: number | null;
  emoji?: string | null;
  gradient?: string | null;
  rating?: string | number | null;
  reviewCount?: number | null;
  stock: number;
  isNew?: boolean | null;
  bestSeller?: boolean | null;
};

export function ProductCard({ p }: { p: ProductLike }) {
  const { addToCart, toggleWishlist, inWishlist } = useStore();
  const price = Number(p.price);
  const original = p.originalPrice ? Number(p.originalPrice) : 0;
  const wished = inWishlist(p.id);

  const wishItem: WishItem = {
    id: p.id,
    name: p.name,
    slug: p.slug,
    price,
    originalPrice: original || undefined,
    emoji: p.emoji || undefined,
    gradient: p.gradient || undefined,
  };

  return (
    <div className="group relative flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white transition hover:shadow-lg">
      <Link href={`/product/${p.slug}`} className="relative block">
        <div
          className={`flex aspect-square items-center justify-center bg-gradient-to-br ${
            p.gradient || "from-indigo-400 to-sky-400"
          }`}
        >
          <span className="text-6xl drop-shadow-sm transition group-hover:scale-110">{p.emoji || "📦"}</span>
        </div>
        <div className="absolute left-2 top-2 flex flex-col gap-1">
          {!!p.discountPercent && p.discountPercent > 0 && (
            <span className="rounded-full bg-rose-500 px-2 py-0.5 text-[10px] font-bold text-white">
              -{p.discountPercent}%
            </span>
          )}
          {p.isNew && (
            <span className="rounded-full bg-emerald-500 px-2 py-0.5 text-[10px] font-bold text-white">NEW</span>
          )}
          {p.bestSeller && (
            <span className="rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-bold text-white">BESTSELLER</span>
          )}
        </div>
      </Link>
      <button
        onClick={() => toggleWishlist(wishItem)}
        aria-label="Toggle wishlist"
        className={`absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-white/90 text-lg shadow ${
          wished ? "text-rose-500" : "text-slate-400"
        }`}
      >
        {wished ? "♥" : "♡"}
      </button>

      <div className="flex flex-1 flex-col p-3">
        <Link href={`/product/${p.slug}`} className="line-clamp-2 text-sm font-medium text-slate-800 hover:text-indigo-600">
          {p.name}
        </Link>
        <div className="mt-1 flex items-center gap-1">
          <Stars rating={Number(p.rating || 0)} />
          <span className="text-xs text-slate-400">({p.reviewCount || 0})</span>
        </div>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-base font-bold text-slate-900">{formatNPR(price)}</span>
          {original > price && (
            <span className="text-xs text-slate-400 line-through">{formatNPR(original)}</span>
          )}
        </div>
        <div className="mt-2">
          {p.stock > 0 ? (
            <span className="text-[11px] font-medium text-emerald-600">In Stock</span>
          ) : (
            <span className="text-[11px] font-medium text-red-500">Out of Stock</span>
          )}
        </div>
        <button
          disabled={p.stock <= 0}
          onClick={() =>
            addToCart({
              id: p.id,
              name: p.name,
              slug: p.slug,
              price,
              originalPrice: original || undefined,
              emoji: p.emoji || undefined,
              gradient: p.gradient || undefined,
              stock: p.stock,
            })
          }
          className="mt-3 w-full rounded-lg bg-indigo-600 py-2 text-xs font-semibold text-white transition hover:bg-indigo-700 disabled:bg-slate-300"
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}
