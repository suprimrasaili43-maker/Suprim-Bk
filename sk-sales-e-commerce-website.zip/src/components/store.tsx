"use client";

import React, { createContext, useContext, useEffect, useState, useCallback } from "react";

export type CartItem = {
  id: number;
  name: string;
  slug: string;
  price: number;
  originalPrice?: number;
  quantity: number;
  emoji?: string;
  gradient?: string;
  stock: number;
  variant?: string;
};

export type WishItem = {
  id: number;
  name: string;
  slug: string;
  price: number;
  originalPrice?: number;
  emoji?: string;
  gradient?: string;
};

export type AuthUser = { id: number; name: string; email: string; phone?: string; role: string } | null;

type Toast = { id: number; message: string; type: "success" | "error" | "info" };

type StoreCtx = {
  cart: CartItem[];
  wishlist: WishItem[];
  recentlyViewed: WishItem[];
  user: AuthUser;
  authLoading: boolean;
  cartCount: number;
  cartSubtotal: number;
  wishCount: number;
  addToCart: (item: Omit<CartItem, "quantity">, qty?: number) => void;
  removeFromCart: (id: number, variant?: string) => void;
  updateQty: (id: number, qty: number, variant?: string) => void;
  clearCart: () => void;
  toggleWishlist: (item: WishItem) => void;
  inWishlist: (id: number) => boolean;
  addRecentlyViewed: (item: WishItem) => void;
  refreshUser: () => Promise<void>;
  logout: () => Promise<void>;
  toast: (message: string, type?: Toast["type"]) => void;
};

const Ctx = createContext<StoreCtx | null>(null);

export function useStore() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useStore must be used within StoreProvider");
  return c;
}

function load<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<WishItem[]>([]);
  const [recentlyViewed, setRecentlyViewed] = useState<WishItem[]>([]);
  const [user, setUser] = useState<AuthUser>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setCart(load<CartItem[]>("sk_cart", []));
    setWishlist(load<WishItem[]>("sk_wish", []));
    setRecentlyViewed(load<WishItem[]>("sk_recent", []));
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem("sk_cart", JSON.stringify(cart));
  }, [cart, ready]);
  useEffect(() => {
    if (ready) localStorage.setItem("sk_wish", JSON.stringify(wishlist));
  }, [wishlist, ready]);
  useEffect(() => {
    if (ready) localStorage.setItem("sk_recent", JSON.stringify(recentlyViewed));
  }, [recentlyViewed, ready]);

  const refreshUser = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me");
      const data = await res.json();
      setUser(data.user);
    } catch {
      setUser(null);
    } finally {
      setAuthLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  const toast = useCallback((message: string, type: Toast["type"] = "success") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, message, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3000);
  }, []);

  const addToCart: StoreCtx["addToCart"] = (item, qty = 1) => {
    setCart((prev) => {
      const idx = prev.findIndex((x) => x.id === item.id && x.variant === item.variant);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = { ...copy[idx], quantity: Math.min(copy[idx].quantity + qty, item.stock) };
        return copy;
      }
      return [...prev, { ...item, quantity: Math.min(qty, item.stock) }];
    });
    toast(`${item.name} added to cart`);
  };

  const removeFromCart = (id: number, variant?: string) =>
    setCart((prev) => prev.filter((x) => !(x.id === id && x.variant === variant)));

  const updateQty = (id: number, qty: number, variant?: string) =>
    setCart((prev) =>
      prev.map((x) =>
        x.id === id && x.variant === variant
          ? { ...x, quantity: Math.max(1, Math.min(qty, x.stock)) }
          : x,
      ),
    );

  const clearCart = () => setCart([]);

  const toggleWishlist = (item: WishItem) => {
    setWishlist((prev) => {
      if (prev.find((x) => x.id === item.id)) {
        toast("Removed from wishlist", "info");
        return prev.filter((x) => x.id !== item.id);
      }
      toast("Added to wishlist");
      return [...prev, item];
    });
  };

  const inWishlist = (id: number) => wishlist.some((x) => x.id === id);

  const addRecentlyViewed = (item: WishItem) =>
    setRecentlyViewed((prev) => [item, ...prev.filter((x) => x.id !== item.id)].slice(0, 8));

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    toast("Logged out");
  };

  const cartCount = cart.reduce((s, x) => s + x.quantity, 0);
  const cartSubtotal = cart.reduce((s, x) => s + x.price * x.quantity, 0);
  const wishCount = wishlist.length;

  return (
    <Ctx.Provider
      value={{
        cart,
        wishlist,
        recentlyViewed,
        user,
        authLoading,
        cartCount,
        cartSubtotal,
        wishCount,
        addToCart,
        removeFromCart,
        updateQty,
        clearCart,
        toggleWishlist,
        inWishlist,
        addRecentlyViewed,
        refreshUser,
        logout,
        toast,
      }}
    >
      {children}
      <div className="fixed bottom-20 md:bottom-6 right-4 z-[100] flex flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`animate-slide-in rounded-lg px-4 py-3 text-sm font-medium text-white shadow-lg ${
              t.type === "error" ? "bg-red-500" : t.type === "info" ? "bg-slate-700" : "bg-emerald-500"
            }`}
          >
            {t.message}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}
