"use client";

import { useEffect, useState } from "react";
import { use } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useStore } from "@/components/store";
import { ProductCard, Stars, type ProductLike } from "@/components/ui";
import { formatNPR } from "@/lib/utils";

type Product = ProductLike & {
  description?: string;
  sku?: string;
  brand?: string;
  specs?: { label: string; value: string }[];
  variants?: { name: string; options: string[] }[];
  soldCount?: number;
};
type Review = { id: number; userName: string; rating: number; comment: string; createdAt: string };

export default function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const router = useRouter();
  const { addToCart, toggleWishlist, inWishlist, addRecentlyViewed, user, toast } = useStore();
  const [product, setProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [related, setRelated] = useState<ProductLike[]>([]);
  const [category, setCategory] = useState<{ name: string; slug: string } | null>(null);
  const [qty, setQty] = useState(1);
  const [selVariants, setSelVariants] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"desc" | "specs" | "reviews">("desc");
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");

  useEffect(() => {
    setLoading(true);
    fetch(`/api/products/${slug}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.product) {
          setProduct(d.product);
          setReviews(d.reviews || []);
          setRelated(d.related || []);
          setCategory(d.category);
          addRecentlyViewed({
            id: d.product.id,
            name: d.product.name,
            slug: d.product.slug,
            price: Number(d.product.price),
            originalPrice: d.product.originalPrice ? Number(d.product.originalPrice) : undefined,
            emoji: d.product.emoji,
            gradient: d.product.gradient,
          });
        }
      })
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slug]);

  if (loading) return <div className="p-16 text-center text-slate-400">Loading product...</div>;
  if (!product) return <div className="p-16 text-center text-slate-500">Product not found.</div>;

  const price = Number(product.price);
  const original = product.originalPrice ? Number(product.originalPrice) : 0;
  const variantStr = Object.values(selVariants).join(" / ") || undefined;

  const cartItem = {
    id: product.id,
    name: product.name,
    slug: product.slug,
    price,
    originalPrice: original || undefined,
    emoji: product.emoji || undefined,
    gradient: product.gradient || undefined,
    stock: product.stock,
    variant: variantStr,
  };

  const buyNow = () => {
    addToCart(cartItem, qty);
    router.push("/checkout");
  };

  const share = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try { await navigator.share({ title: product.name, url }); } catch { /* ignore */ }
    } else {
      navigator.clipboard.writeText(url);
      toast("Link copied to clipboard");
    }
  };

  const submitReview = async () => {
    if (!user) { router.push("/login"); return; }
    const res = await fetch("/api/reviews", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId: product.id, rating, comment }),
    });
    const data = await res.json();
    if (data.ok) {
      toast("Review submitted!");
      setComment("");
      fetch(`/api/products/${slug}`).then((r) => r.json()).then((d) => { setReviews(d.reviews || []); setProduct(d.product); });
    } else toast(data.error || "Failed", "error");
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <nav className="mb-4 text-xs text-slate-500">
        <Link href="/" className="hover:underline">Home</Link> / <Link href="/shop" className="hover:underline">Shop</Link>
        {category && <> / <Link href={`/shop?category=${category.slug}`} className="hover:underline">{category.name}</Link></>}
        <span className="text-slate-800"> / {product.name}</span>
      </nav>

      <div className="grid gap-8 md:grid-cols-2">
        {/* Gallery */}
        <div>
          <div className={`flex aspect-square items-center justify-center rounded-2xl bg-gradient-to-br ${product.gradient || "from-indigo-400 to-sky-400"}`}>
            <span className="text-[9rem]">{product.emoji || "📦"}</span>
          </div>
          <div className="mt-3 flex gap-2">
            {[product.emoji, "📦", "✨"].map((e, i) => (
              <div key={i} className={`flex h-16 w-16 items-center justify-center rounded-xl border-2 bg-gradient-to-br ${product.gradient || "from-indigo-400 to-sky-400"} ${i === 0 ? "border-indigo-500" : "border-transparent"}`}>
                <span className="text-2xl">{e}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Info */}
        <div>
          <div className="flex flex-wrap items-center gap-2">
            {product.brand && <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600">{product.brand}</span>}
            <span className="text-xs text-slate-400">SKU: {product.sku}</span>
          </div>
          <h1 className="mt-2 text-2xl font-bold text-slate-900">{product.name}</h1>
          <div className="mt-2 flex items-center gap-2">
            <Stars rating={Number(product.rating || 0)} />
            <span className="text-sm text-slate-500">{Number(product.rating || 0).toFixed(1)} ({product.reviewCount || 0} reviews)</span>
            <span className="text-sm text-slate-400">· {product.soldCount || 0} sold</span>
          </div>

          <div className="mt-4 flex items-baseline gap-3">
            <span className="text-3xl font-extrabold text-indigo-600">{formatNPR(price)}</span>
            {original > price && <span className="text-lg text-slate-400 line-through">{formatNPR(original)}</span>}
            {!!product.discountPercent && product.discountPercent > 0 && (
              <span className="rounded-full bg-rose-100 px-2 py-1 text-sm font-bold text-rose-600">Save {product.discountPercent}%</span>
            )}
          </div>

          <div className="mt-3">
            {product.stock > 0 ? (
              <span className="text-sm font-medium text-emerald-600">✔ In Stock ({product.stock} available)</span>
            ) : (
              <span className="text-sm font-medium text-red-500">✘ Out of Stock</span>
            )}
          </div>

          {product.description && <p className="mt-4 text-sm text-slate-600">{product.description}</p>}

          {/* Variants */}
          {product.variants?.map((v) => (
            <div key={v.name} className="mt-4">
              <p className="mb-1 text-sm font-medium">{v.name}:</p>
              <div className="flex flex-wrap gap-2">
                {v.options.map((o) => (
                  <button
                    key={o}
                    onClick={() => setSelVariants((s) => ({ ...s, [v.name]: o }))}
                    className={`rounded-lg border px-3 py-1.5 text-sm ${selVariants[v.name] === o ? "border-indigo-600 bg-indigo-50 text-indigo-700" : "border-slate-200"}`}
                  >
                    {o}
                  </button>
                ))}
              </div>
            </div>
          ))}

          {/* Qty */}
          <div className="mt-4 flex items-center gap-3">
            <span className="text-sm font-medium">Quantity:</span>
            <div className="flex items-center rounded-lg border border-slate-200">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="px-3 py-1.5 text-lg">−</button>
              <span className="w-10 text-center">{qty}</span>
              <button onClick={() => setQty((q) => Math.min(product.stock, q + 1))} className="px-3 py-1.5 text-lg">+</button>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap gap-3">
            <button disabled={product.stock <= 0} onClick={() => addToCart(cartItem, qty)} className="flex-1 rounded-xl border-2 border-indigo-600 py-3 text-sm font-semibold text-indigo-600 hover:bg-indigo-50 disabled:opacity-50">
              🛒 Add to Cart
            </button>
            <button disabled={product.stock <= 0} onClick={buyNow} className="flex-1 rounded-xl bg-indigo-600 py-3 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-50">
              ⚡ Buy Now
            </button>
          </div>
          <div className="mt-3 flex gap-3">
            <button onClick={() => toggleWishlist({ id: product.id, name: product.name, slug: product.slug, price, originalPrice: original || undefined, emoji: product.emoji || undefined, gradient: product.gradient || undefined })} className="flex-1 rounded-xl border border-slate-200 py-2.5 text-sm hover:bg-slate-50">
              {inWishlist(product.id) ? "♥ In Wishlist" : "♡ Add to Wishlist"}
            </button>
            <button onClick={share} className="flex-1 rounded-xl border border-slate-200 py-2.5 text-sm hover:bg-slate-50">🔗 Share</button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-10">
        <div className="flex gap-6 border-b border-slate-200 text-sm font-medium">
          {[["desc", "Description"], ["specs", "Specifications"], ["reviews", `Reviews (${reviews.length})`]].map(([k, l]) => (
            <button key={k} onClick={() => setTab(k as typeof tab)} className={`-mb-px border-b-2 pb-2 ${tab === k ? "border-indigo-600 text-indigo-600" : "border-transparent text-slate-500"}`}>{l}</button>
          ))}
        </div>

        <div className="py-5">
          {tab === "desc" && <p className="text-sm leading-relaxed text-slate-600">{product.description || "No description available."}</p>}
          {tab === "specs" && (
            <table className="w-full max-w-lg text-sm">
              <tbody>
                {(product.specs || []).length === 0 && <tr><td className="text-slate-400">No specifications listed.</td></tr>}
                {(product.specs || []).map((s, i) => (
                  <tr key={i} className="border-b border-slate-100">
                    <td className="py-2 font-medium text-slate-600">{s.label}</td>
                    <td className="py-2 text-slate-800">{s.value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {tab === "reviews" && (
            <div className="space-y-4">
              {/* Write review */}
              <div className="rounded-2xl border border-slate-200 bg-white p-4">
                <h4 className="font-semibold">Write a Review</h4>
                <div className="mt-2 flex gap-1 text-2xl text-amber-400">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button key={s} onClick={() => setRating(s)}>{s <= rating ? "★" : "☆"}</button>
                  ))}
                </div>
                <textarea value={comment} onChange={(e) => setComment(e.target.value)} rows={3} placeholder="Share your experience..." className="mt-2 w-full rounded-lg border border-slate-200 p-2 text-sm outline-none focus:border-indigo-400" />
                <button onClick={submitReview} className="mt-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">Submit Review</button>
                {!user && <p className="mt-1 text-xs text-slate-400">Please <Link href="/login" className="text-indigo-600">log in</Link> to review.</p>}
              </div>
              {reviews.length === 0 && <p className="text-sm text-slate-400">No reviews yet. Be the first!</p>}
              {reviews.map((r) => (
                <div key={r.id} className="rounded-2xl border border-slate-200 bg-white p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-slate-800">{r.userName}</span>
                    <Stars rating={r.rating} />
                  </div>
                  <p className="mt-1 text-sm text-slate-600">{r.comment}</p>
                  <p className="mt-1 text-xs text-slate-400">{new Date(r.createdAt).toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {related.length > 0 && (
        <div className="mt-8">
          <h2 className="mb-4 text-xl font-bold">Related Products</h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {related.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        </div>
      )}
    </div>
  );
}
