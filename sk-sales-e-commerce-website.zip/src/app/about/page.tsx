export default function AboutPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="rounded-2xl bg-gradient-to-br from-indigo-600 to-sky-500 p-8 text-white">
        <h1 className="text-3xl font-extrabold">About SK Sales</h1>
        <p className="mt-2 max-w-xl text-indigo-100">Your trusted online shopping store, bringing quality products to every corner of Nepal.</p>
      </div>

      <div className="mt-6 space-y-4 text-slate-600">
        <p>SK Sales is a modern e-commerce platform built for customers across Nepal. We offer a wide range of products — from electronics and mobile accessories to fashion, home essentials, and beauty care — all at competitive prices.</p>
        <p>Our mission is to make online shopping simple, secure, and accessible for everyone. With flexible payment options including eSewa, bank transfer, and cash on delivery, plus fast nationwide delivery, we&apos;re here to serve you better.</p>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        {[
          { n: "1000+", l: "Happy Customers" },
          { n: "500+", l: "Products" },
          { n: "7", l: "Provinces Served" },
        ].map((s) => (
          <div key={s.l} className="rounded-2xl border border-slate-200 bg-white p-6 text-center">
            <p className="text-3xl font-extrabold text-indigo-600">{s.n}</p>
            <p className="mt-1 text-sm text-slate-500">{s.l}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-6">
          <h2 className="font-bold">Our Mission</h2>
          <p className="mt-2 text-sm text-slate-500">To empower shoppers in Nepal with a safe, affordable, and convenient online shopping experience.</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-6">
          <h2 className="font-bold">Our Values</h2>
          <p className="mt-2 text-sm text-slate-500">Quality products, honest pricing, reliable delivery, and friendly local customer support.</p>
        </div>
      </div>

      <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-6 text-center">
        <h2 className="font-bold">Get in Touch</h2>
        <p className="mt-2 text-sm text-slate-600">📞 9767948789 · ✉️ bksuprim634@gmail.com</p>
      </div>
    </div>
  );
}
