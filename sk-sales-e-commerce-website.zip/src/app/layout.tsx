import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { StoreProvider } from "@/components/store";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import BottomNav from "@/components/BottomNav";

export const metadata: Metadata = {
  title: "SK Sales — Your Trusted Online Shopping Store in Nepal",
  description:
    "Shop electronics, fashion, home essentials and more at SK Sales. Fast delivery across Nepal. Pay with eSewa, Bank Transfer or Cash on Delivery.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-50 text-slate-900 antialiased">
        <StoreProvider>
          <Header />
          <main className="min-h-[60vh] pb-16 md:pb-0">{children}</main>
          <Footer />
          <BottomNav />
        </StoreProvider>
      </body>
    </html>
  );
}
