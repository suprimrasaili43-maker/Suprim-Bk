import Link from "next/link";

export default function FailedPage() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-16 text-center">
      <div className="text-6xl">❌</div>
      <h1 className="mt-4 text-2xl font-bold text-rose-600">Payment Failed</h1>
      <p className="mt-2 text-slate-600">Your payment could not be completed. Your order is saved as pending — you can retry payment from your orders.</p>
      <div className="mt-8 flex justify-center gap-3">
        <Link href="/account/orders" className="rounded-full bg-indigo-600 px-6 py-3 text-sm font-semibold text-white">View Orders</Link>
        <Link href="/cart" className="rounded-full border border-slate-200 px-6 py-3 text-sm font-semibold">Back to Cart</Link>
      </div>
    </div>
  );
}
