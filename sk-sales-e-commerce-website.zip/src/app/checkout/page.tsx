"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { useStore } from "@/components/store";
import { formatNPR, NEPAL_PROVINCES } from "@/lib/utils";

type PubSettings = {
  deliveryCharge: number;
  freeDeliveryThreshold: number;
  taxPercent: number;
  esewaEnabled: boolean;
  bankEnabled: boolean;
  codEnabled: boolean;
  codNote: string;
};

function CheckoutInner() {
  const params = useSearchParams();
  const router = useRouter();
  const { cart, cartSubtotal, user, clearCart, toast } = useStore();
  const [step, setStep] = useState(1);
  const [settings, setSettings] = useState<PubSettings | null>(null);
  const [placing, setPlacing] = useState(false);
  const [discount, setDiscount] = useState(0);
  const couponCode = params.get("coupon") || "";

  const [info, setInfo] = useState({ name: "", email: "", phone: "" });
  const [addr, setAddr] = useState({ province: "Bagmati", district: "", city: "", area: "", fullAddress: "", postalCode: "" });
  const [delivery, setDelivery] = useState("Standard Delivery");
  const [payment, setPayment] = useState("COD");
  const [note, setNote] = useState("");

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((d) => {
      setSettings(d.settings);
      setPayment(d.settings.codEnabled ? "COD" : d.settings.esewaEnabled ? "eSewa" : "Bank");
    });
  }, []);

  useEffect(() => {
    if (user) setInfo({ name: user.name, email: user.email, phone: user.phone || "" });
  }, [user]);

  useEffect(() => {
    if (couponCode) {
      fetch("/api/coupons/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: couponCode, subtotal: cartSubtotal }),
      }).then((r) => r.json()).then((d) => { if (d.valid) setDiscount(d.discount); });
    }
  }, [couponCode, cartSubtotal]);

  if (cart.length === 0 && !placing) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <h1 className="text-2xl font-bold">Your cart is empty</h1>
        <Link href="/shop" className="mt-4 inline-block rounded-full bg-indigo-600 px-6 py-3 text-sm font-semibold text-white">Go Shopping</Link>
      </div>
    );
  }

  const s = settings;
  const expressFee = delivery === "Express Delivery" ? 200 : 0;
  const baseDelivery = cartSubtotal - discount >= (s?.freeDeliveryThreshold ?? 5000) ? 0 : s?.deliveryCharge ?? 100;
  const deliveryCharge = baseDelivery + expressFee;
  const tax = Math.round(((cartSubtotal - discount) * (s?.taxPercent ?? 0)) / 100);
  const total = cartSubtotal - discount + deliveryCharge + tax;

  const steps = ["Customer Info", "Delivery Address", "Delivery Method", "Payment", "Confirm"];

  const canNext = () => {
    if (step === 1) return info.name && info.phone && info.email;
    if (step === 2) return addr.province && addr.city && addr.fullAddress;
    return true;
  };

  const placeOrder = async () => {
    setPlacing(true);
    const res = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        items: cart.map((c) => ({ id: c.id, quantity: c.quantity, variant: c.variant })),
        customerName: info.name,
        customerEmail: info.email,
        phone: info.phone,
        address: { ...addr, phone: info.phone },
        paymentMethod: payment,
        deliveryMethod: delivery,
        couponCode: couponCode || undefined,
        note,
      }),
    });
    const data = await res.json();
    if (!data.ok) {
      toast(data.error || "Failed to place order", "error");
      setPlacing(false);
      return;
    }
    const orderId = data.order.id;
    clearCart();

    if (payment === "eSewa") {
      // Initiate eSewa payment (structure). Auto-submit form to gateway.
      const initRes = await fetch("/api/payments/esewa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId }),
      });
      const init = await initRes.json();
      if (init.action && init.configured) {
        const form = document.createElement("form");
        form.method = "POST";
        form.action = init.action;
        Object.entries(init.fields).forEach(([k, v]) => {
          const i = document.createElement("input");
          i.type = "hidden"; i.name = k; i.value = String(v);
          form.appendChild(i);
        });
        document.body.appendChild(form);
        form.submit();
        return;
      }
      // Not configured -> go to success page with eSewa instructions (demo)
      router.push(`/checkout/success?orderId=${orderId}&method=eSewa`);
      return;
    }
    router.push(`/checkout/success?orderId=${orderId}&method=${payment}`);
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <h1 className="mb-4 text-2xl font-bold">Checkout</h1>

      {/* Steps indicator */}
      <div className="mb-6 flex items-center gap-1 overflow-x-auto no-scrollbar">
        {steps.map((label, i) => (
          <div key={label} className="flex flex-1 items-center">
            <div className={`flex items-center gap-2 whitespace-nowrap ${step === i + 1 ? "text-indigo-600" : step > i + 1 ? "text-emerald-600" : "text-slate-400"}`}>
              <span className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold ${step === i + 1 ? "bg-indigo-600 text-white" : step > i + 1 ? "bg-emerald-500 text-white" : "bg-slate-200"}`}>
                {step > i + 1 ? "✓" : i + 1}
              </span>
              <span className="hidden text-xs font-medium sm:block">{label}</span>
            </div>
            {i < steps.length - 1 && <div className="mx-1 h-0.5 flex-1 bg-slate-200" />}
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            {step === 1 && (
              <div className="space-y-3">
                <h2 className="font-bold">Customer Information</h2>
                <input value={info.name} onChange={(e) => setInfo({ ...info, name: e.target.value })} placeholder="Full Name *" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
                <input value={info.email} onChange={(e) => setInfo({ ...info, email: e.target.value })} placeholder="Email *" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
                <input value={info.phone} onChange={(e) => setInfo({ ...info, phone: e.target.value })} placeholder="Phone Number *" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
                {!user && <p className="text-xs text-slate-400">Have an account? <Link href="/login" className="text-indigo-600">Login</Link> for faster checkout.</p>}
              </div>
            )}
            {step === 2 && (
              <div className="space-y-3">
                <h2 className="font-bold">Delivery Address</h2>
                <select value={addr.province} onChange={(e) => setAddr({ ...addr, province: e.target.value })} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm">
                  {NEPAL_PROVINCES.map((p) => <option key={p}>{p}</option>)}
                </select>
                <div className="grid grid-cols-2 gap-3">
                  <input value={addr.district} onChange={(e) => setAddr({ ...addr, district: e.target.value })} placeholder="District" className="rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
                  <input value={addr.city} onChange={(e) => setAddr({ ...addr, city: e.target.value })} placeholder="Municipality / City *" className="rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
                </div>
                <input value={addr.area} onChange={(e) => setAddr({ ...addr, area: e.target.value })} placeholder="Area / Tole" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
                <textarea value={addr.fullAddress} onChange={(e) => setAddr({ ...addr, fullAddress: e.target.value })} placeholder="Full Address (house no., landmark) *" rows={2} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
                <input value={addr.postalCode} onChange={(e) => setAddr({ ...addr, postalCode: e.target.value })} placeholder="Postal Code" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
              </div>
            )}
            {step === 3 && (
              <div className="space-y-3">
                <h2 className="font-bold">Delivery Method</h2>
                {[
                  { id: "Standard Delivery", label: "Standard Delivery", desc: "2-5 business days", fee: baseDelivery },
                  { id: "Express Delivery", label: "Express Delivery", desc: "1-2 business days", fee: baseDelivery + 200 },
                ].map((d) => (
                  <label key={d.id} className={`flex cursor-pointer items-center justify-between rounded-xl border p-3 ${delivery === d.id ? "border-indigo-600 bg-indigo-50" : "border-slate-200"}`}>
                    <div className="flex items-center gap-3">
                      <input type="radio" checked={delivery === d.id} onChange={() => setDelivery(d.id)} />
                      <div><p className="text-sm font-medium">{d.label}</p><p className="text-xs text-slate-500">{d.desc}</p></div>
                    </div>
                    <span className="text-sm font-semibold">{d.fee === 0 ? "Free" : formatNPR(d.fee)}</span>
                  </label>
                ))}
              </div>
            )}
            {step === 4 && (
              <div className="space-y-3">
                <h2 className="font-bold">Payment Method</h2>
                {s?.codEnabled && (
                  <label className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3 ${payment === "COD" ? "border-indigo-600 bg-indigo-50" : "border-slate-200"}`}>
                    <input type="radio" checked={payment === "COD"} onChange={() => setPayment("COD")} className="mt-1" />
                    <div><p className="text-sm font-medium">💵 Cash on Delivery</p><p className="text-xs text-slate-500">{s.codNote}</p></div>
                  </label>
                )}
                {s?.esewaEnabled && (
                  <label className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3 ${payment === "eSewa" ? "border-indigo-600 bg-indigo-50" : "border-slate-200"}`}>
                    <input type="radio" checked={payment === "eSewa"} onChange={() => setPayment("eSewa")} className="mt-1" />
                    <div><p className="text-sm font-medium">🟢 eSewa</p><p className="text-xs text-slate-500">Pay securely via eSewa digital wallet.</p></div>
                  </label>
                )}
                {s?.bankEnabled && (
                  <label className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3 ${payment === "Bank" ? "border-indigo-600 bg-indigo-50" : "border-slate-200"}`}>
                    <input type="radio" checked={payment === "Bank"} onChange={() => setPayment("Bank")} className="mt-1" />
                    <div><p className="text-sm font-medium">🏦 Bank Transfer</p><p className="text-xs text-slate-500">Transfer to our bank account and upload the receipt after ordering.</p></div>
                  </label>
                )}
                <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Order note (optional)" rows={2} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
              </div>
            )}
            {step === 5 && (
              <div className="space-y-4">
                <h2 className="font-bold">Review Your Order</h2>
                <div className="rounded-xl bg-slate-50 p-3 text-sm">
                  <p className="font-medium">{info.name} · {info.phone}</p>
                  <p className="text-slate-500">{info.email}</p>
                  <p className="mt-1 text-slate-600">{addr.fullAddress}, {addr.area}, {addr.city}, {addr.district}, {addr.province} {addr.postalCode}</p>
                  <p className="mt-1"><span className="text-slate-500">Delivery:</span> {delivery}</p>
                  <p><span className="text-slate-500">Payment:</span> {payment}</p>
                </div>
                <div className="space-y-2">
                  {cart.map((c) => (
                    <div key={`${c.id}-${c.variant}`} className="flex items-center justify-between text-sm">
                      <span className="flex items-center gap-2"><span className="text-xl">{c.emoji}</span>{c.name} × {c.quantity}{c.variant ? ` (${c.variant})` : ""}</span>
                      <span className="font-medium">{formatNPR(c.price * c.quantity)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="mt-4 flex justify-between">
            {step > 1 ? <button onClick={() => setStep(step - 1)} className="rounded-lg border border-slate-200 px-5 py-2.5 text-sm font-medium">← Back</button> : <span />}
            {step < 5 ? (
              <button disabled={!canNext()} onClick={() => setStep(step + 1)} className="rounded-lg bg-indigo-600 px-6 py-2.5 text-sm font-semibold text-white disabled:opacity-50">Continue →</button>
            ) : (
              <button disabled={placing} onClick={placeOrder} className="rounded-lg bg-emerald-600 px-6 py-2.5 text-sm font-semibold text-white disabled:opacity-60">
                {placing ? "Placing order..." : "Place Order"}
              </button>
            )}
          </div>
        </div>

        {/* Summary */}
        <div className="h-fit rounded-2xl border border-slate-200 bg-white p-5">
          <h2 className="mb-3 font-bold">Order Summary</h2>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span>Subtotal ({cart.length})</span><span>{formatNPR(cartSubtotal)}</span></div>
            {discount > 0 && <div className="flex justify-between text-emerald-600"><span>Discount</span><span>− {formatNPR(discount)}</span></div>}
            <div className="flex justify-between"><span>Delivery</span><span>{deliveryCharge === 0 ? "Free" : formatNPR(deliveryCharge)}</span></div>
            {tax > 0 && <div className="flex justify-between"><span>Tax</span><span>{formatNPR(tax)}</span></div>}
            <div className="mt-2 flex justify-between border-t pt-2 text-base font-bold"><span>Total</span><span className="text-indigo-600">{formatNPR(total)}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CheckoutPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center text-slate-400">Loading...</div>}>
      <CheckoutInner />
    </Suspense>
  );
}
