"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { useStore } from "@/components/store";
import { formatNPR } from "@/lib/utils";

type Bank = { bankName: string; bankAccountName: string; bankAccountNumber: string; bankBranch: string; bankQrUrl: string };

function SuccessInner() {
  const params = useSearchParams();
  const { toast } = useStore();
  const orderId = params.get("orderId");
  const method = params.get("method");
  const [order, setOrder] = useState<{ orderNumber: string; total: string; paymentMethod: string } | null>(null);
  const [bank, setBank] = useState<Bank | null>(null);
  const [receiptUrl, setReceiptUrl] = useState("");
  const [txn, setTxn] = useState("");
  const [uploaded, setUploaded] = useState(false);

  useEffect(() => {
    if (orderId) fetch(`/api/orders/${orderId}`).then((r) => r.json()).then((d) => d.order && setOrder(d.order));
    if (method === "Bank") fetch("/api/settings").then((r) => r.json()).then((d) => setBank(d.settings));
  }, [orderId, method]);

  const uploadReceipt = async () => {
    const res = await fetch(`/api/orders/${orderId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "receipt", receiptUrl, transactionId: txn }),
    });
    const d = await res.json();
    if (d.ok) { setUploaded(true); toast("Receipt submitted for verification"); }
    else toast(d.error || "Failed", "error");
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-12 text-center">
      <div className="text-6xl">✅</div>
      <h1 className="mt-4 text-2xl font-bold text-emerald-600">Order Placed Successfully!</h1>
      <p className="mt-2 text-slate-600">Thank you for shopping with SK Sales.</p>
      {order && (
        <div className="mx-auto mt-6 max-w-md rounded-2xl border border-slate-200 bg-white p-5 text-left text-sm">
          <div className="flex justify-between"><span className="text-slate-500">Order Number</span><span className="font-bold">{order.orderNumber}</span></div>
          <div className="mt-1 flex justify-between"><span className="text-slate-500">Total</span><span className="font-bold">{formatNPR(order.total)}</span></div>
          <div className="mt-1 flex justify-between"><span className="text-slate-500">Payment</span><span className="font-medium">{order.paymentMethod}</span></div>
        </div>
      )}

      {method === "COD" && (
        <p className="mx-auto mt-4 max-w-md rounded-xl bg-amber-50 p-3 text-sm text-amber-700">💵 Please keep the exact amount ready. Payment will be collected on delivery.</p>
      )}

      {method === "eSewa" && (
        <p className="mx-auto mt-4 max-w-md rounded-xl bg-green-50 p-3 text-sm text-green-700">🟢 Your eSewa payment is being verified. Once confirmed by our team, your order will be processed.</p>
      )}

      {method === "Bank" && bank && (
        <div className="mx-auto mt-6 max-w-md rounded-2xl border border-slate-200 bg-white p-5 text-left">
          <h3 className="font-bold">🏦 Bank Transfer Details</h3>
          <div className="mt-2 space-y-1 text-sm text-slate-600">
            <p><b>Bank:</b> {bank.bankName}</p>
            <p><b>Account Name:</b> {bank.bankAccountName}</p>
            <p><b>Account Number:</b> {bank.bankAccountNumber}</p>
            <p><b>Branch:</b> {bank.bankBranch}</p>
          </div>
          {!uploaded ? (
            <div className="mt-4 space-y-2">
              <p className="text-sm font-medium">Upload payment proof:</p>
              <input value={txn} onChange={(e) => setTxn(e.target.value)} placeholder="Transaction ID / Reference" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
              <input value={receiptUrl} onChange={(e) => setReceiptUrl(e.target.value)} placeholder="Receipt image URL (paste link)" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
              <button onClick={uploadReceipt} className="w-full rounded-lg bg-indigo-600 py-2 text-sm font-semibold text-white">Submit Payment Proof</button>
            </div>
          ) : (
            <p className="mt-3 rounded-lg bg-emerald-50 p-2 text-sm text-emerald-700">✔ Receipt submitted. We&apos;ll verify and confirm your order shortly.</p>
          )}
        </div>
      )}

      <div className="mt-8 flex justify-center gap-3">
        <Link href={orderId ? `/account/orders/${orderId}` : "/account/orders"} className="rounded-full bg-indigo-600 px-6 py-3 text-sm font-semibold text-white">Track Order</Link>
        <Link href="/shop" className="rounded-full border border-slate-200 px-6 py-3 text-sm font-semibold">Continue Shopping</Link>
      </div>
    </div>
  );
}

export default function SuccessPage() {
  return <Suspense fallback={<div className="p-12 text-center text-slate-400">Loading...</div>}><SuccessInner /></Suspense>;
}
