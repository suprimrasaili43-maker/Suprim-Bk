"use client";

import { useState } from "react";
import { useStore } from "@/components/store";

export default function ContactPage() {
  const { toast } = useStore();
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", message: "" });
  const [sent, setSent] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const d = await res.json();
    if (d.ok) { setSent(true); toast("Message sent! We'll get back to you soon."); setForm({ name: "", email: "", phone: "", subject: "", message: "" }); }
    else toast(d.error || "Failed", "error");
  };

  const faqs = [
    { q: "How long does delivery take?", a: "Standard delivery takes 2-5 business days within Nepal. Express delivery is 1-2 days for major cities." },
    { q: "What payment methods do you accept?", a: "We accept eSewa, Bank Transfer, and Cash on Delivery (COD)." },
    { q: "Can I return a product?", a: "Yes, eligible products can be returned within the return window after delivery. Visit your orders to request a return." },
    { q: "Is Cash on Delivery available everywhere?", a: "COD is available in most locations across Nepal. Availability may vary by area." },
    { q: "How do I track my order?", a: "Log in to your account and go to My Orders to see live order status and tracking." },
  ];

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="text-2xl font-bold">Contact Us</h1>
      <p className="mt-1 text-slate-500">We&apos;d love to hear from you. Reach out anytime!</p>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <h2 className="font-bold">SK Sales</h2>
            <div className="mt-3 space-y-2 text-sm text-slate-600">
              <p>📞 Phone: <a href="tel:9767948789" className="font-medium text-indigo-600">9767948789</a></p>
              <p>✉️ Email: <a href="mailto:bksuprim634@gmail.com" className="font-medium text-indigo-600">bksuprim634@gmail.com</a></p>
              <p>📍 Kathmandu, Bagmati Province, Nepal</p>
              <p>🕒 Sun–Fri, 9 AM – 7 PM</p>
            </div>
          </div>

          {sent && <p className="rounded-xl bg-emerald-50 p-3 text-sm text-emerald-700">✔ Thank you! Your message has been received.</p>}
          <form onSubmit={submit} className="space-y-3 rounded-2xl border border-slate-200 bg-white p-5">
            <h2 className="font-bold">Send us a Message</h2>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Name *" required className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
            <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} type="email" placeholder="Email *" required className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
            <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="Phone" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
            <input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="Subject" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
            <textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} rows={4} placeholder="Message *" required className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
            <button className="w-full rounded-lg bg-indigo-600 py-2.5 text-sm font-semibold text-white">Submit</button>
          </form>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <h2 className="font-bold">Frequently Asked Questions</h2>
          <div className="mt-3 divide-y divide-slate-100">
            {faqs.map((f, i) => (
              <details key={i} className="group py-3">
                <summary className="cursor-pointer list-none text-sm font-medium">➤ {f.q}</summary>
                <p className="mt-2 text-sm text-slate-500">{f.a}</p>
              </details>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
