import { db } from "@/db";
import { users, orders } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const rows = await db
    .select({ id: users.id, name: users.name, email: users.email, phone: users.phone, createdAt: users.createdAt })
    .from(users)
    .where(eq(users.role, "customer"))
    .orderBy(desc(users.createdAt));
  const orderStats = await db
    .select({
      userId: orders.userId,
      count: sql<number>`count(*)`,
      spent: sql<number>`coalesce(sum(case when ${orders.status} <> 'Cancelled' then ${orders.total} else 0 end),0)`,
    })
    .from(orders)
    .groupBy(orders.userId);
  const map = Object.fromEntries(orderStats.map((s) => [s.userId, s]));
  return Response.json({
    customers: rows.map((c) => ({
      ...c,
      orders: Number(map[c.id]?.count || 0),
      spent: Number(map[c.id]?.spent || 0),
    })),
  });
}
