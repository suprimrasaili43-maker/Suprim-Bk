import { db } from "@/db";
import { reviews, products } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const rows = await db
    .select({
      id: reviews.id,
      productId: reviews.productId,
      userName: reviews.userName,
      rating: reviews.rating,
      comment: reviews.comment,
      approved: reviews.approved,
      createdAt: reviews.createdAt,
      productName: products.name,
    })
    .from(reviews)
    .leftJoin(products, eq(reviews.productId, products.id))
    .orderBy(desc(reviews.createdAt));
  return Response.json({ reviews: rows });
}

export async function PATCH(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const { id, approved } = await req.json();
  await db.update(reviews).set({ approved }).where(eq(reviews.id, Number(id)));
  return Response.json({ ok: true });
}

export async function DELETE(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const { id } = await req.json();
  await db.delete(reviews).where(eq(reviews.id, Number(id)));
  return Response.json({ ok: true });
}
