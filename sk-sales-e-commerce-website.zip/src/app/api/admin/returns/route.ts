import { db } from "@/db";
import { returns, orders } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { notifyUser } from "@/lib/notify";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const rows = await db
    .select({
      id: returns.id,
      orderId: returns.orderId,
      userId: returns.userId,
      reason: returns.reason,
      status: returns.status,
      type: returns.type,
      createdAt: returns.createdAt,
      orderNumber: orders.orderNumber,
    })
    .from(returns)
    .leftJoin(orders, eq(returns.orderId, orders.id))
    .orderBy(desc(returns.createdAt));
  return Response.json({ returns: rows });
}

export async function PATCH(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const { id, status } = await req.json();
  const [r] = await db.select().from(returns).where(eq(returns.id, Number(id))).limit(1);
  if (!r) return Response.json({ error: "Not found" }, { status: 404 });
  await db.update(returns).set({ status, updatedAt: new Date() }).where(eq(returns.id, Number(id)));
  if (status === "Refunded") {
    await db.update(orders).set({ paymentStatus: "Refunded", status: "Cancelled" }).where(eq(orders.id, r.orderId));
  }
  if (r.userId) {
    await notifyUser(r.userId, {
      type: "return_update",
      title: `Return ${status}`,
      message: `Your return request is now: ${status}.`,
      link: `/account/orders/${r.orderId}`,
    });
  }
  return Response.json({ ok: true });
}
