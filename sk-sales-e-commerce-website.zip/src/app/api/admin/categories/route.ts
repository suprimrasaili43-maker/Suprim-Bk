import { db } from "@/db";
import { categories } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { slugify } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const b = await req.json();
  if (!b.name) return Response.json({ error: "Name required." }, { status: 400 });
  const [c] = await db
    .insert(categories)
    .values({
      name: b.name,
      slug: slugify(b.name) + "-" + Date.now().toString().slice(-4),
      parentId: b.parentId ? Number(b.parentId) : null,
      emoji: b.emoji || "📁",
      description: b.description,
    })
    .returning();
  return Response.json({ ok: true, category: c });
}

export async function PATCH(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const b = await req.json();
  await db
    .update(categories)
    .set({ name: b.name, emoji: b.emoji, description: b.description, parentId: b.parentId ? Number(b.parentId) : null })
    .where(eq(categories.id, Number(b.id)));
  return Response.json({ ok: true });
}

export async function DELETE(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const { id } = await req.json();
  await db.delete(categories).where(eq(categories.id, Number(id)));
  return Response.json({ ok: true });
}
