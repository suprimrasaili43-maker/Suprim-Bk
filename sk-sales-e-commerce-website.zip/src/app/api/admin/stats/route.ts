import { db } from "@/db";
import { orders, products, users, returns } from "@/db/schema";
import { sql, eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });

  const allOrders = await db.select().from(orders);
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  const paidOrders = allOrders.filter((o) => o.status !== "Cancelled");
  const totalSales = paidOrders.reduce((s, o) => s + Number(o.total), 0);
  const todaySales = paidOrders
    .filter((o) => new Date(o.createdAt) >= todayStart)
    .reduce((s, o) => s + Number(o.total), 0);
  const monthlySales = paidOrders
    .filter((o) => new Date(o.createdAt) >= monthStart)
    .reduce((s, o) => s + Number(o.total), 0);

  const statusCount = (st: string) => allOrders.filter((o) => o.status === st).length;

  const allProducts = await db.select().from(products);
  const lowStock = allProducts.filter((p) => p.stock > 0 && p.stock <= (p.lowStockThreshold ?? 5)).length;
  const outOfStock = allProducts.filter((p) => p.stock <= 0).length;

  const [{ c: totalCustomers }] = await db
    .select({ c: sql<number>`count(*)` })
    .from(users)
    .where(eq(users.role, "customer"));

  const pendingPayments = allOrders.filter((o) => o.paymentStatus === "Pending Verification").length;
  const [{ c: pendingReturns }] = await db
    .select({ c: sql<number>`count(*)` })
    .from(returns)
    .where(eq(returns.status, "Return Requested"));

  // Sales over last 7 days
  const salesByDay: { date: string; sales: number; orders: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(todayStart);
    d.setDate(d.getDate() - i);
    const next = new Date(d);
    next.setDate(next.getDate() + 1);
    const dayOrders = paidOrders.filter(
      (o) => new Date(o.createdAt) >= d && new Date(o.createdAt) < next,
    );
    salesByDay.push({
      date: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      sales: dayOrders.reduce((s, o) => s + Number(o.total), 0),
      orders: dayOrders.length,
    });
  }

  // Best sellers
  const bestSellers = [...allProducts]
    .sort((a, b) => (b.soldCount ?? 0) - (a.soldCount ?? 0))
    .slice(0, 5)
    .map((p) => ({ name: p.name, sold: p.soldCount ?? 0 }));

  // Order status distribution
  const statuses = ["Pending", "Confirmed", "Processing", "Packed", "Shipped", "Out for Delivery", "Delivered", "Cancelled"];
  const statusDist = statuses.map((s) => ({ name: s, value: statusCount(s) })).filter((s) => s.value > 0);

  // Payment method usage
  const methods = ["COD", "eSewa", "Bank"];
  const paymentDist = methods
    .map((m) => ({ name: m, value: allOrders.filter((o) => o.paymentMethod === m).length }))
    .filter((m) => m.value > 0);

  return Response.json({
    totalSales,
    todaySales,
    monthlySales,
    totalOrders: allOrders.length,
    pendingOrders: statusCount("Pending"),
    processingOrders: statusCount("Processing"),
    deliveredOrders: statusCount("Delivered"),
    cancelledOrders: statusCount("Cancelled"),
    totalCustomers: Number(totalCustomers),
    totalProducts: allProducts.length,
    lowStock,
    outOfStock,
    pendingPayments,
    pendingReturns: Number(pendingReturns),
    salesByDay,
    bestSellers,
    statusDist,
    paymentDist,
  });
}
