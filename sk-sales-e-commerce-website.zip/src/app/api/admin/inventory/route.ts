import { db } from "@/db";
import { products } from "@/db/schema";
import { asc } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const rows = await db
    .select({
      id: products.id,
      name: products.name,
      sku: products.sku,
      stock: products.stock,
      lowStockThreshold: products.lowStockThreshold,
      soldCount: products.soldCount,
      price: products.price,
      emoji: products.emoji,
    })
    .from(products)
    .orderBy(asc(products.stock));
  return Response.json({ inventory: rows });
}
