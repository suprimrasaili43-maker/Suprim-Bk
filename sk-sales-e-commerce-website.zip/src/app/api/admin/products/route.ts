import { db } from "@/db";
import { products } from "@/db/schema";
import { desc } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { slugify } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const rows = await db.select().from(products).orderBy(desc(products.createdAt));
  return Response.json({ products: rows });
}

export async function POST(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const b = await req.json();
  if (!b.name || !b.price) return Response.json({ error: "Name and price required." }, { status: 400 });
  const original = Number(b.originalPrice || b.price);
  const price = Number(b.price);
  const disc = original > price ? Math.round(((original - price) / original) * 100) : 0;
  const [p] = await db
    .insert(products)
    .values({
      name: b.name,
      slug: slugify(b.name) + "-" + Date.now().toString().slice(-5),
      description: b.description,
      sku: b.sku || "SK-" + Date.now().toString().slice(-6),
      brand: b.brand,
      categoryId: b.categoryId ? Number(b.categoryId) : null,
      price: String(price),
      originalPrice: String(original),
      discountPercent: disc,
      stock: Number(b.stock || 0),
      lowStockThreshold: Number(b.lowStockThreshold || 5),
      emoji: b.emoji || "📦",
      gradient: b.gradient || "from-indigo-400 to-sky-400",
      specs: b.specs || [],
      variants: b.variants || [],
      featured: !!b.featured,
      isNew: !!b.isNew,
      bestSeller: !!b.bestSeller,
      hidden: !!b.hidden,
    })
    .returning();
  return Response.json({ ok: true, product: p });
}
