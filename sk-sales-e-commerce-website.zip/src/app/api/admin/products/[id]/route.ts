import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const { id } = await params;
  const b = await req.json();
  const update: Record<string, unknown> = { updatedAt: new Date() };
  const fields = ["name", "description", "sku", "brand", "emoji", "gradient", "specs", "variants"];
  for (const f of fields) if (b[f] !== undefined) update[f] = b[f];
  if (b.categoryId !== undefined) update.categoryId = b.categoryId ? Number(b.categoryId) : null;
  if (b.stock !== undefined) update.stock = Number(b.stock);
  if (b.lowStockThreshold !== undefined) update.lowStockThreshold = Number(b.lowStockThreshold);
  if (b.featured !== undefined) update.featured = !!b.featured;
  if (b.isNew !== undefined) update.isNew = !!b.isNew;
  if (b.bestSeller !== undefined) update.bestSeller = !!b.bestSeller;
  if (b.hidden !== undefined) update.hidden = !!b.hidden;
  if (b.price !== undefined || b.originalPrice !== undefined) {
    const [cur] = await db.select().from(products).where(eq(products.id, Number(id))).limit(1);
    const price = Number(b.price ?? cur.price);
    const original = Number(b.originalPrice ?? cur.originalPrice ?? price);
    update.price = String(price);
    update.originalPrice = String(original);
    update.discountPercent = original > price ? Math.round(((original - price) / original) * 100) : 0;
  }
  await db.update(products).set(update).where(eq(products.id, Number(id)));
  return Response.json({ ok: true });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const { id } = await params;
  await db.delete(products).where(eq(products.id, Number(id)));
  return Response.json({ ok: true });
}
