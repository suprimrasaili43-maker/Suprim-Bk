import { db } from "@/db";
import { products, categories, reviews, coupons, orders, orderItems, returns } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

// Deletes all demo catalog + order data so the admin can start fresh.
export async function POST() {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  await db.delete(orderItems);
  await db.delete(returns);
  await db.delete(orders);
  await db.delete(reviews);
  await db.delete(products);
  await db.delete(categories);
  await db.delete(coupons);
  return Response.json({ ok: true });
}
