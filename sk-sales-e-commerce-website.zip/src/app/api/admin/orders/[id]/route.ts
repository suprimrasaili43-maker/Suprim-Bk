import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { notifyUser } from "@/lib/notify";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const { id } = await params;
  const [order] = await db.select().from(orders).where(eq(orders.id, Number(id))).limit(1);
  if (!order) return Response.json({ error: "Not found" }, { status: 404 });
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  return Response.json({ order, items });
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const { id } = await params;
  const body = await req.json();
  const [order] = await db.select().from(orders).where(eq(orders.id, Number(id))).limit(1);
  if (!order) return Response.json({ error: "Not found" }, { status: 404 });

  const update: Record<string, unknown> = { updatedAt: new Date() };
  if (body.status) update.status = body.status;
  if (body.paymentStatus) update.paymentStatus = body.paymentStatus;
  if (body.deliveryMethod) update.deliveryMethod = body.deliveryMethod;

  await db.update(orders).set(update).where(eq(orders.id, order.id));

  if (order.userId) {
    if (body.status && body.status !== order.status) {
      await notifyUser(order.userId, {
        type: "order_update",
        title: `Order ${order.orderNumber} ${body.status}`,
        message: `Your order status is now: ${body.status}.`,
        link: `/account/orders/${order.id}`,
      });
    }
    if (body.paymentStatus === "Paid" && order.paymentStatus !== "Paid") {
      await notifyUser(order.userId, {
        type: "payment_confirmed",
        title: "Payment confirmed",
        message: `Payment for order ${order.orderNumber} has been confirmed.`,
        link: `/account/orders/${order.id}`,
      });
    }
  }
  return Response.json({ ok: true });
}
