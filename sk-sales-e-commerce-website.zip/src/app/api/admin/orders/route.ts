import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { desc, eq, or, ilike, and, SQL } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q");
  const status = searchParams.get("status");
  const conds: SQL[] = [];
  if (q) {
    conds.push(
      or(ilike(orders.orderNumber, `%${q}%`), ilike(orders.customerName, `%${q}%`), ilike(orders.phone, `%${q}%`))!,
    );
  }
  if (status && status !== "all") conds.push(eq(orders.status, status));
  const rows = await db
    .select()
    .from(orders)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(desc(orders.createdAt))
    .limit(200);
  const withItems = await Promise.all(
    rows.map(async (o) => ({
      ...o,
      items: await db.select().from(orderItems).where(eq(orderItems.orderId, o.id)),
    })),
  );
  return Response.json({ orders: withItems });
}
