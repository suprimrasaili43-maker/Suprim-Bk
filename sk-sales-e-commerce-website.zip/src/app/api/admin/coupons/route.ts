import { db } from "@/db";
import { coupons } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const rows = await db.select().from(coupons).orderBy(desc(coupons.createdAt));
  return Response.json({ coupons: rows });
}

export async function POST(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const b = await req.json();
  if (!b.code || !b.value) return Response.json({ error: "Code and value required." }, { status: 400 });
  try {
    const [c] = await db
      .insert(coupons)
      .values({
        code: b.code.toUpperCase(),
        type: b.type || "percent",
        value: String(b.value),
        minOrder: String(b.minOrder || 0),
        maxDiscount: b.maxDiscount ? String(b.maxDiscount) : null,
        expiresAt: b.expiresAt ? new Date(b.expiresAt) : null,
        usageLimit: b.usageLimit ? Number(b.usageLimit) : null,
        active: b.active !== false,
      })
      .returning();
    return Response.json({ ok: true, coupon: c });
  } catch {
    return Response.json({ error: "Coupon code already exists." }, { status: 400 });
  }
}

export async function PATCH(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const b = await req.json();
  await db.update(coupons).set({ active: b.active }).where(eq(coupons.id, Number(b.id)));
  return Response.json({ ok: true });
}

export async function DELETE(req: Request) {
  const admin = await requireAdmin();
  if (!admin) return Response.json({ error: "Unauthorized" }, { status: 403 });
  const { id } = await req.json();
  await db.delete(coupons).where(eq(coupons.id, Number(id)));
  return Response.json({ ok: true });
}
