import { db } from "@/db";
import { messages } from "@/db/schema";
import { notifyAdmin } from "@/lib/notify";

export async function POST(req: Request) {
  try {
    const { name, email, phone, subject, message } = await req.json();
    if (!name || !email || !message) {
      return Response.json({ error: "Name, email and message are required." }, { status: 400 });
    }
    await db.insert(messages).values({ name, email, phone, subject, message });
    await notifyAdmin({
      type: "contact",
      title: "New contact message",
      message: `${name}: ${subject || "(no subject)"}`,
      link: "/admin",
    });
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
