import { db } from "@/db";
import { users, addresses } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getSession, verifyPassword, hashPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await getSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const [user] = await db.select().from(users).where(eq(users.id, session.id)).limit(1);
  const addrs = await db.select().from(addresses).where(eq(addresses.userId, session.id));
  return Response.json({
    user: { id: user.id, name: user.name, email: user.email, phone: user.phone },
    addresses: addrs,
  });
}

export async function PATCH(req: Request) {
  const session = await getSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json();

  if (body.action === "changePassword") {
    const [user] = await db.select().from(users).where(eq(users.id, session.id)).limit(1);
    if (!(await verifyPassword(body.currentPassword, user.passwordHash))) {
      return Response.json({ error: "Current password is incorrect." }, { status: 400 });
    }
    if (!body.newPassword || body.newPassword.length < 6) {
      return Response.json({ error: "New password must be at least 6 characters." }, { status: 400 });
    }
    await db.update(users).set({ passwordHash: await hashPassword(body.newPassword) }).where(eq(users.id, session.id));
    return Response.json({ ok: true });
  }

  // update profile
  await db
    .update(users)
    .set({ name: body.name, phone: body.phone, updatedAt: new Date() })
    .where(eq(users.id, session.id));
  return Response.json({ ok: true });
}

// Address management
export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const [addr] = await db
    .insert(addresses)
    .values({
      userId: session.id,
      label: body.label || "Home",
      province: body.province,
      district: body.district,
      city: body.city,
      area: body.area,
      fullAddress: body.fullAddress,
      postalCode: body.postalCode,
      phone: body.phone,
      isDefault: body.isDefault || false,
    })
    .returning();
  return Response.json({ ok: true, address: addr });
}

export async function DELETE(req: Request) {
  const session = await getSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await req.json();
  await db.delete(addresses).where(and(eq(addresses.id, id), eq(addresses.userId, session.id)));
  return Response.json({ ok: true });
}
