import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notifyAdmin, notifyUser } from "@/lib/notify";

export const dynamic = "force-dynamic";

/*
 * eSewa success callback. In production, decode the base64 `data` param returned
 * by eSewa, verify the signature and status === "COMPLETE", then mark the order paid.
 * This structure marks payment as verified after the gateway redirect.
 */
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const orderId = Number(searchParams.get("orderId"));
  const data = searchParams.get("data"); // base64 payload from eSewa

  const base = process.env.NEXT_PUBLIC_BASE_URL || new URL(req.url).origin;
  const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order) return Response.redirect(`${base}/checkout/failed`);

  let verified = false;
  let transactionId = "";
  try {
    if (data) {
      const decoded = JSON.parse(Buffer.from(data, "base64").toString("utf-8"));
      transactionId = decoded.transaction_code || decoded.transaction_uuid || "";
      verified = decoded.status === "COMPLETE";
    } else {
      // Sandbox / demo path without real signature verification available.
      verified = true;
      transactionId = `ESEWA-${Date.now()}`;
    }
  } catch {
    verified = false;
  }

  if (verified) {
    await db
      .update(orders)
      .set({ paymentStatus: "Paid", transactionId, status: "Confirmed", updatedAt: new Date() })
      .where(eq(orders.id, orderId));
    await notifyAdmin({
      type: "payment_received",
      title: "eSewa payment received",
      message: `Order ${order.orderNumber} paid via eSewa.`,
      link: `/admin/orders/${order.id}`,
    });
    if (order.userId) {
      await notifyUser(order.userId, {
        type: "payment_confirmed",
        title: "Payment confirmed",
        message: `Your eSewa payment for ${order.orderNumber} was successful.`,
        link: `/account/orders/${order.id}`,
      });
    }
    return Response.redirect(`${base}/checkout/success?orderId=${orderId}`);
  }
  return Response.redirect(`${base}/checkout/failed?orderId=${orderId}`);
}
