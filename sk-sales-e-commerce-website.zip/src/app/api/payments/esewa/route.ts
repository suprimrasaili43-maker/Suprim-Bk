import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSettings } from "@/lib/settings";
import crypto from "crypto";

export const dynamic = "force-dynamic";

/*
 * eSewa ePay v2 integration STRUCTURE.
 * Configure the following environment variables in production:
 *   ESEWA_MERCHANT_ID  -> your eSewa merchant/product code
 *   ESEWA_SECRET_KEY   -> your eSewa secret key (used to sign the payload)
 *   NEXT_PUBLIC_BASE_URL -> your site base URL for success/failure redirects
 * Never expose the secret key to the browser. This route runs server-side only.
 */

// Returns the signed form fields the browser posts to eSewa.
export async function POST(req: Request) {
  const { orderId } = await req.json();
  const [order] = await db.select().from(orders).where(eq(orders.id, Number(orderId))).limit(1);
  if (!order) return Response.json({ error: "Order not found" }, { status: 404 });

  const settings = await getSettings();
  const merchantId = process.env.ESEWA_MERCHANT_ID || settings.esewaMerchantId || "EPAYTEST";
  const secret = process.env.ESEWA_SECRET_KEY || "8gBm/:&EnhH.1/q"; // eSewa public sandbox key
  const base = process.env.NEXT_PUBLIC_BASE_URL || new URL(req.url).origin;

  const amount = Number(order.total).toFixed(0);
  const transactionUuid = `${order.orderNumber}-${Date.now()}`;
  const signedFieldNames = "total_amount,transaction_uuid,product_code";
  const message = `total_amount=${amount},transaction_uuid=${transactionUuid},product_code=${merchantId}`;
  const signature = crypto.createHmac("sha256", secret).update(message).digest("base64");

  return Response.json({
    // Sandbox gateway URL. Switch to https://epay.esewa.com.np/api/epay/main/v2/form in production.
    action: "https://rc-epay.esewa.com.np/api/epay/main/v2/form",
    fields: {
      amount,
      tax_amount: "0",
      total_amount: amount,
      transaction_uuid: transactionUuid,
      product_code: merchantId,
      product_service_charge: "0",
      product_delivery_charge: "0",
      success_url: `${base}/api/payments/esewa/verify?orderId=${order.id}`,
      failure_url: `${base}/checkout/failed?orderId=${order.id}`,
      signed_field_names: signedFieldNames,
      signature,
    },
    configured: !!(process.env.ESEWA_MERCHANT_ID && process.env.ESEWA_SECRET_KEY),
  });
}
