import { seedDatabase, isSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    if (await isSeeded()) {
      return Response.json({ ok: false, message: "Already seeded" });
    }
    const res = await seedDatabase();
    return Response.json(res);
  } catch (e) {
    return Response.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
