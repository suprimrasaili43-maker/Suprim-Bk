import { db } from "@/db";
import { coupons } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const { code, subtotal } = await req.json();
    const rows = await db
      .select()
      .from(coupons)
      .where(eq(coupons.code, (code || "").toUpperCase()))
      .limit(1);
    const coupon = rows[0];
    if (!coupon || !coupon.active) {
      return Response.json({ valid: false, error: "Invalid coupon code." }, { status: 400 });
    }
    if (coupon.expiresAt && new Date(coupon.expiresAt) < new Date()) {
      return Response.json({ valid: false, error: "Coupon has expired." }, { status: 400 });
    }
    if (coupon.usageLimit && (coupon.usedCount ?? 0) >= coupon.usageLimit) {
      return Response.json({ valid: false, error: "Coupon usage limit reached." }, { status: 400 });
    }
    const sub = Number(subtotal || 0);
    if (Number(coupon.minOrder) > sub) {
      return Response.json(
        { valid: false, error: `Minimum order of Rs. ${coupon.minOrder} required.` },
        { status: 400 },
      );
    }
    let discount = 0;
    if (coupon.type === "percent") {
      discount = (sub * Number(coupon.value)) / 100;
      if (coupon.maxDiscount) discount = Math.min(discount, Number(coupon.maxDiscount));
    } else {
      discount = Number(coupon.value);
    }
    discount = Math.min(discount, sub);
    return Response.json({
      valid: true,
      code: coupon.code,
      discount: Math.round(discount),
      type: coupon.type,
      value: Number(coupon.value),
    });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
