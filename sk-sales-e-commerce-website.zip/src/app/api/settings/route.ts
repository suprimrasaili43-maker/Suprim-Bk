import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

// Public-safe settings for storefront (no secret credentials)
export async function GET() {
  const s = await getSettings();
  return Response.json({
    settings: {
      storeName: s.storeName,
      storeDescription: s.storeDescription,
      phone: s.phone,
      email: s.email,
      address: s.address,
      deliveryCharge: s.deliveryCharge,
      freeDeliveryThreshold: s.freeDeliveryThreshold,
      taxPercent: s.taxPercent,
      deliveryEstimate: s.deliveryEstimate,
      esewaEnabled: s.esewaEnabled,
      bankEnabled: s.bankEnabled,
      codEnabled: s.codEnabled,
      codNote: s.codNote,
      bankName: s.bankName,
      bankAccountName: s.bankAccountName,
      bankAccountNumber: s.bankAccountNumber,
      bankBranch: s.bankBranch,
      bankQrUrl: s.bankQrUrl,
    },
  });
}
