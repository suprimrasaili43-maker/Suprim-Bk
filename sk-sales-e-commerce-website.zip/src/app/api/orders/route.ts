import { db } from "@/db";
import { orders, orderItems, products, coupons, notifications } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { genOrderNumber } from "@/lib/utils";
import { notifyAdmin, notifyUser } from "@/lib/notify";

export const dynamic = "force-dynamic";

type CartItem = { id: number; quantity: number; variant?: string };

export async function GET() {
  const session = await getSession();
  if (!session) return Response.json({ orders: [] });
  const rows = await db
    .select()
    .from(orders)
    .where(eq(orders.userId, session.id))
    .orderBy(desc(orders.createdAt));
  const withItems = await Promise.all(
    rows.map(async (o) => {
      const items = await db.select().from(orderItems).where(eq(orderItems.orderId, o.id));
      return { ...o, items };
    }),
  );
  return Response.json({ orders: withItems });
}

export async function POST(req: Request) {
  try {
    const session = await getSession();
    const body = await req.json();
    const {
      items,
      customerName,
      customerEmail,
      phone,
      address,
      paymentMethod,
      deliveryMethod,
      couponCode,
      note,
    }: {
      items: CartItem[];
      customerName: string;
      customerEmail: string;
      phone: string;
      address: Record<string, string>;
      paymentMethod: string;
      deliveryMethod: string;
      couponCode?: string;
      note?: string;
    } = body;

    if (!items?.length) return Response.json({ error: "Cart is empty." }, { status: 400 });
    if (!customerName || !phone || !address?.fullAddress) {
      return Response.json({ error: "Customer name, phone and address are required." }, { status: 400 });
    }

    const settings = await getSettings();

    // Validate payment method availability
    if (paymentMethod === "COD" && !settings.codEnabled)
      return Response.json({ error: "Cash on Delivery is currently unavailable." }, { status: 400 });
    if (paymentMethod === "eSewa" && !settings.esewaEnabled)
      return Response.json({ error: "eSewa payment is currently unavailable." }, { status: 400 });
    if (paymentMethod === "Bank" && !settings.bankEnabled)
      return Response.json({ error: "Bank transfer is currently unavailable." }, { status: 400 });

    // Load products and validate stock
    let subtotal = 0;
    const resolved: {
      product: typeof products.$inferSelect;
      qty: number;
      variant?: string;
    }[] = [];
    for (const it of items) {
      const rows = await db.select().from(products).where(eq(products.id, it.id)).limit(1);
      const p = rows[0];
      if (!p || p.hidden) return Response.json({ error: `Product unavailable.` }, { status: 400 });
      if (p.stock < it.quantity)
        return Response.json({ error: `${p.name} is out of stock.` }, { status: 400 });
      subtotal += Number(p.price) * it.quantity;
      resolved.push({ product: p, qty: it.quantity, variant: it.variant });
    }

    // Coupon
    let discount = 0;
    let appliedCode: string | null = null;
    if (couponCode) {
      const cRows = await db.select().from(coupons).where(eq(coupons.code, couponCode.toUpperCase())).limit(1);
      const c = cRows[0];
      if (c && c.active && Number(c.minOrder) <= subtotal) {
        if (c.type === "percent") {
          discount = (subtotal * Number(c.value)) / 100;
          if (c.maxDiscount) discount = Math.min(discount, Number(c.maxDiscount));
        } else discount = Number(c.value);
        discount = Math.min(discount, subtotal);
        appliedCode = c.code;
        await db.update(coupons).set({ usedCount: (c.usedCount ?? 0) + 1 }).where(eq(coupons.id, c.id));
      }
    }

    // Delivery + tax
    const deliveryCharge =
      subtotal - discount >= settings.freeDeliveryThreshold ? 0 : settings.deliveryCharge;
    const tax = Math.round(((subtotal - discount) * settings.taxPercent) / 100);
    const total = subtotal - discount + deliveryCharge + tax;

    const paymentStatus = paymentMethod === "COD" ? "Unpaid" : "Pending Verification";

    const [order] = await db
      .insert(orders)
      .values({
        orderNumber: genOrderNumber(),
        userId: session?.id ?? null,
        customerName,
        customerEmail,
        phone,
        status: "Pending",
        paymentMethod,
        paymentStatus,
        subtotal: String(subtotal),
        deliveryCharge: String(deliveryCharge),
        tax: String(tax),
        discount: String(discount),
        total: String(total),
        couponCode: appliedCode,
        deliveryMethod: deliveryMethod || "Standard Delivery",
        address,
        note,
      })
      .returning();

    await db.insert(orderItems).values(
      resolved.map((r) => ({
        orderId: order.id,
        productId: r.product.id,
        name: r.product.name,
        price: r.product.price,
        quantity: r.qty,
        variant: r.variant,
        emoji: r.product.emoji,
        gradient: r.product.gradient,
      })),
    );

    // Decrease stock + soldCount
    for (const r of resolved) {
      await db
        .update(products)
        .set({
          stock: r.product.stock - r.qty,
          soldCount: (r.product.soldCount ?? 0) + r.qty,
        })
        .where(eq(products.id, r.product.id));
      if (r.product.stock - r.qty <= (r.product.lowStockThreshold ?? 5)) {
        await notifyAdmin({
          type: r.product.stock - r.qty <= 0 ? "out_of_stock" : "low_stock",
          title: r.product.stock - r.qty <= 0 ? "Out of stock" : "Low stock alert",
          message: `${r.product.name} now has ${r.product.stock - r.qty} units left.`,
          link: "/admin/inventory",
        });
      }
    }

    // Notifications
    await notifyAdmin({
      type: "new_order",
      title: `New ${paymentMethod} order ${order.orderNumber}`,
      message: `${customerName} placed an order of Rs. ${total}.`,
      link: `/admin/orders/${order.id}`,
    });
    if (paymentMethod === "Bank") {
      await notifyAdmin({
        type: "bank_pending",
        title: "Bank payment awaiting verification",
        message: `Order ${order.orderNumber} is paid via bank transfer. Verify the receipt.`,
        link: `/admin/orders/${order.id}`,
      });
    }
    if (session) {
      await notifyUser(session.id, {
        type: "order_placed",
        title: "Order placed successfully",
        message: `Your order ${order.orderNumber} has been placed. Total Rs. ${total}.`,
        link: `/account/orders/${order.id}`,
      });
    }

    return Response.json({ ok: true, order });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
