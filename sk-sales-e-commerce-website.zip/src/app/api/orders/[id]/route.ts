import { db } from "@/db";
import { orders, orderItems, returns } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { notifyAdmin, notifyUser } from "@/lib/notify";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await getSession();
  const rows = await db.select().from(orders).where(eq(orders.id, Number(id))).limit(1);
  const order = rows[0];
  if (!order) return Response.json({ error: "Not found" }, { status: 404 });
  if (session?.role !== "admin" && order.userId !== session?.id) {
    return Response.json({ error: "Unauthorized" }, { status: 403 });
  }
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  return Response.json({ order, items });
}

// Customer actions: cancel, request return, upload receipt
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await getSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const rows = await db.select().from(orders).where(eq(orders.id, Number(id))).limit(1);
  const order = rows[0];
  if (!order || order.userId !== session.id)
    return Response.json({ error: "Unauthorized" }, { status: 403 });

  const { action, reason, receiptUrl, transactionId } = await req.json();

  if (action === "cancel") {
    if (["Shipped", "Out for Delivery", "Delivered", "Cancelled"].includes(order.status)) {
      return Response.json({ error: "This order can no longer be cancelled." }, { status: 400 });
    }
    await db.update(orders).set({ status: "Cancelled", updatedAt: new Date() }).where(eq(orders.id, order.id));
    await notifyAdmin({
      type: "order_cancelled",
      title: "Order cancelled by customer",
      message: `Order ${order.orderNumber} was cancelled.`,
      link: `/admin/orders/${order.id}`,
    });
    return Response.json({ ok: true });
  }

  if (action === "return") {
    if (order.status !== "Delivered") {
      return Response.json({ error: "Only delivered orders can be returned." }, { status: 400 });
    }
    await db.insert(returns).values({
      orderId: order.id,
      userId: session.id,
      reason,
      status: "Return Requested",
      type: "return",
    });
    await notifyAdmin({
      type: "return_request",
      title: "Return requested",
      message: `Return requested for order ${order.orderNumber}.`,
      link: `/admin/returns`,
    });
    return Response.json({ ok: true });
  }

  if (action === "receipt") {
    await db
      .update(orders)
      .set({ receiptUrl, transactionId, paymentStatus: "Pending Verification", updatedAt: new Date() })
      .where(eq(orders.id, order.id));
    await notifyAdmin({
      type: "bank_pending",
      title: "Payment receipt uploaded",
      message: `Receipt uploaded for order ${order.orderNumber}. Please verify.`,
      link: `/admin/orders/${order.id}`,
    });
    return Response.json({ ok: true });
  }

  return Response.json({ error: "Unknown action" }, { status: 400 });
}
