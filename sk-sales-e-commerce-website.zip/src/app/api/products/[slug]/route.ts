import { db } from "@/db";
import { products, reviews, categories } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ slug: string }> },
) {
  try {
    const { slug } = await params;
    const rows = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
    const product = rows[0];
    if (!product) return Response.json({ error: "Not found" }, { status: 404 });

    const cat = product.categoryId
      ? (await db.select().from(categories).where(eq(categories.id, product.categoryId)).limit(1))[0]
      : null;

    const productReviews = await db
      .select()
      .from(reviews)
      .where(and(eq(reviews.productId, product.id), eq(reviews.approved, true)))
      .orderBy(desc(reviews.createdAt));

    const related = await db
      .select()
      .from(products)
      .where(and(eq(products.categoryId, product.categoryId ?? 0), eq(products.hidden, false)))
      .limit(5);

    return Response.json({
      product,
      category: cat,
      reviews: productReviews,
      related: related.filter((r) => r.id !== product.id).slice(0, 4),
    });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
