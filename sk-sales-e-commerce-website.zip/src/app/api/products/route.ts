import { db } from "@/db";
import { products, categories } from "@/db/schema";
import { and, eq, gte, lte, ilike, or, desc, asc, sql, SQL } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q");
    const category = searchParams.get("category"); // slug
    const brand = searchParams.get("brand");
    const minPrice = searchParams.get("minPrice");
    const maxPrice = searchParams.get("maxPrice");
    const minRating = searchParams.get("minRating");
    const inStock = searchParams.get("inStock");
    const sort = searchParams.get("sort") || "newest";
    const flag = searchParams.get("flag"); // featured|new|bestSeller
    const limit = Math.min(parseInt(searchParams.get("limit") || "100"), 200);

    const conds: SQL[] = [eq(products.hidden, false)];

    if (q) {
      conds.push(
        or(
          ilike(products.name, `%${q}%`),
          ilike(products.brand, `%${q}%`),
          ilike(products.sku, `%${q}%`),
          ilike(products.description, `%${q}%`),
        )!,
      );
    }
    if (category) {
      const cat = await db
        .select()
        .from(categories)
        .where(eq(categories.slug, category))
        .limit(1);
      if (cat[0]) conds.push(eq(products.categoryId, cat[0].id));
    }
    if (brand) conds.push(eq(products.brand, brand));
    if (minPrice) conds.push(gte(products.price, minPrice));
    if (maxPrice) conds.push(lte(products.price, maxPrice));
    if (minRating) conds.push(gte(products.rating, minRating));
    if (inStock === "true") conds.push(gte(products.stock, 1));
    if (flag === "featured") conds.push(eq(products.featured, true));
    if (flag === "new") conds.push(eq(products.isNew, true));
    if (flag === "bestSeller") conds.push(eq(products.bestSeller, true));

    let orderBy;
    switch (sort) {
      case "priceLow":
        orderBy = asc(products.price);
        break;
      case "priceHigh":
        orderBy = desc(products.price);
        break;
      case "rating":
        orderBy = desc(products.rating);
        break;
      case "popularity":
        orderBy = desc(products.soldCount);
        break;
      default:
        orderBy = desc(products.createdAt);
    }

    const rows = await db
      .select()
      .from(products)
      .where(and(...conds))
      .orderBy(orderBy)
      .limit(limit);

    return Response.json({ products: rows });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
