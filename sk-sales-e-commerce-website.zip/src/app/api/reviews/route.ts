import { db } from "@/db";
import { reviews, products } from "@/db/schema";
import { eq, and, avg, count } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { notifyAdmin } from "@/lib/notify";

export async function POST(req: Request) {
  try {
    const session = await getSession();
    if (!session) return Response.json({ error: "Please log in to review." }, { status: 401 });
    const { productId, rating, comment } = await req.json();
    if (!productId || !rating || rating < 1 || rating > 5) {
      return Response.json({ error: "Valid product and rating (1-5) required." }, { status: 400 });
    }
    await db.insert(reviews).values({
      productId,
      userId: session.id,
      userName: session.name,
      rating,
      comment,
      approved: true,
    });

    // recompute aggregate
    const [agg] = await db
      .select({ a: avg(reviews.rating), c: count() })
      .from(reviews)
      .where(and(eq(reviews.productId, productId), eq(reviews.approved, true)));
    await db
      .update(products)
      .set({ rating: String(Number(agg.a ?? 0).toFixed(2)), reviewCount: Number(agg.c) })
      .where(eq(products.id, productId));

    await notifyAdmin({
      type: "new_review",
      title: "New product review",
      message: `${session.name} left a ${rating}-star review.`,
      link: "/admin/reviews",
    });
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
