import { db } from "@/db";
import { notifications } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const session = await getSession();
  if (!session) return Response.json({ notifications: [], unread: 0 });
  const { searchParams } = new URL(req.url);
  const scope = searchParams.get("scope"); // admin | user

  const isAdminScope = scope === "admin" && session.role === "admin";
  const where = isAdminScope
    ? eq(notifications.forAdmin, true)
    : and(eq(notifications.userId, session.id), eq(notifications.forAdmin, false));

  const rows = await db
    .select()
    .from(notifications)
    .where(where)
    .orderBy(desc(notifications.createdAt))
    .limit(50);
  const unread = rows.filter((n) => !n.read).length;
  return Response.json({ notifications: rows, unread });
}

export async function PATCH(req: Request) {
  const session = await getSession();
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const { scope } = await req.json();
  const isAdminScope = scope === "admin" && session.role === "admin";
  const where = isAdminScope
    ? eq(notifications.forAdmin, true)
    : and(eq(notifications.userId, session.id), eq(notifications.forAdmin, false));
  await db.update(notifications).set({ read: true }).where(where);
  return Response.json({ ok: true });
}
