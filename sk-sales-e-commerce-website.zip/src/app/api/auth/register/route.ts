import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, createSession } from "@/lib/auth";
import { notifyAdmin } from "@/lib/notify";

export async function POST(req: Request) {
  try {
    const { name, email, phone, password } = await req.json();
    if (!name || !email || !password || password.length < 6) {
      return Response.json(
        { error: "Name, email and a password (min 6 chars) are required." },
        { status: 400 },
      );
    }
    const existing = await db
      .select()
      .from(users)
      .where(eq(users.email, email.toLowerCase()))
      .limit(1);
    if (existing[0]) {
      return Response.json({ error: "Email already registered." }, { status: 409 });
    }
    const passwordHash = await hashPassword(password);
    const [user] = await db
      .insert(users)
      .values({
        name,
        email: email.toLowerCase(),
        phone,
        passwordHash,
        role: "customer",
      })
      .returning();

    await createSession({ id: user.id, email: user.email, name: user.name, role: user.role });
    await notifyAdmin({
      type: "new_customer",
      title: "New customer registered",
      message: `${name} (${email}) just created an account.`,
      link: "/admin/customers",
    });
    return Response.json({ ok: true, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
