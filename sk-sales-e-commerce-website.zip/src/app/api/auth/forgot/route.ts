import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { randomBytes } from "crypto";

export async function POST(req: Request) {
  try {
    const { email } = await req.json();
    const rows = await db
      .select()
      .from(users)
      .where(eq(users.email, (email || "").toLowerCase()))
      .limit(1);
    if (!rows[0]) {
      // Do not reveal existence
      return Response.json({ ok: true, message: "If the email exists, a reset token was generated." });
    }
    const token = randomBytes(24).toString("hex");
    await db
      .update(users)
      .set({ resetToken: token, resetTokenExpiry: new Date(Date.now() + 1000 * 60 * 30) })
      .where(eq(users.id, rows[0].id));
    // In production this would be emailed. For demo, return the token/link.
    return Response.json({
      ok: true,
      message: "Reset link generated. In production this is emailed to you.",
      resetToken: token,
    });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
