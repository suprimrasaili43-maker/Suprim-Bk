import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const { token, password } = await req.json();
    if (!token || !password || password.length < 6) {
      return Response.json({ error: "Token and new password (min 6) required." }, { status: 400 });
    }
    const rows = await db.select().from(users).where(eq(users.resetToken, token)).limit(1);
    const user = rows[0];
    if (!user || !user.resetTokenExpiry || user.resetTokenExpiry < new Date()) {
      return Response.json({ error: "Invalid or expired reset token." }, { status: 400 });
    }
    await db
      .update(users)
      .set({ passwordHash: await hashPassword(password), resetToken: null, resetTokenExpiry: null })
      .where(eq(users.id, user.id));
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
