import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const cats = await db.select().from(categories).orderBy(categories.name);
    const counts = await db
      .select({ categoryId: products.categoryId, c: sql<number>`count(*)` })
      .from(products)
      .where(eq(products.hidden, false))
      .groupBy(products.categoryId);
    const countMap = Object.fromEntries(counts.map((c) => [c.categoryId, Number(c.c)]));
    return Response.json({
      categories: cats.map((c) => ({ ...c, productCount: countMap[c.id] || 0 })),
    });
  } catch (e) {
    return Response.json({ error: String(e) }, { status: 500 });
  }
}
