"use client";

import { Suspense, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";

function ResetInner() {
  const params = useSearchParams();
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");
  const token = params.get("token") || "";

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    const res = await fetch("/api/auth/reset", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, password }),
    });
    const data = await res.json();
    if (data.ok) {
      setMsg("Password reset! Redirecting to login...");
      setTimeout(() => router.push("/login"), 1500);
    } else setError(data.error || "Failed to reset");
  };

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-12">
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h1 className="text-2xl font-bold">Reset Password</h1>
        {msg && <p className="mt-3 rounded-lg bg-emerald-50 p-2 text-sm text-emerald-700">{msg}</p>}
        {error && <p className="mt-3 rounded-lg bg-rose-50 p-2 text-sm text-rose-600">{error}</p>}
        <form onSubmit={submit} className="mt-4 space-y-3">
          <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="New password (min 6 chars)" required className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-indigo-400" />
          <button className="w-full rounded-lg bg-indigo-600 py-2.5 text-sm font-semibold text-white">Reset Password</button>
        </form>
        <p className="mt-4 text-center text-sm text-slate-500"><Link href="/login" className="font-medium text-indigo-600">Back to Login</Link></p>
      </div>
    </div>
  );
}

export default function ResetPage() {
  return <Suspense fallback={<div className="p-12 text-center text-slate-400">Loading...</div>}><ResetInner /></Suspense>;
}
