"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useStore } from "@/components/store";
import { ProductCard, Stars, type ProductLike } from "@/components/ui";

type Cat = { id: number; name: string; slug: string; emoji?: string | null; productCount?: number };

function Section({ title, link, children }: { title: string; link?: string; children: React.ReactNode }) {
  return (
    <section className="mx-auto max-w-7xl px-4 py-6">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-900 sm:text-2xl">{title}</h2>
        {link && <Link href={link} className="text-sm font-medium text-indigo-600 hover:underline">View all →</Link>}
      </div>
      {children}
    </section>
  );
}

function Grid({ products }: { products: ProductLike[] }) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
      {products.map((p) => (
        <ProductCard key={p.id} p={p} />
      ))}
    </div>
  );
}

export default function HomePage() {
  const { recentlyViewed } = useStore();
  const [featured, setFeatured] = useState<ProductLike[]>([]);
  const [newArrivals, setNewArrivals] = useState<ProductLike[]>([]);
  const [bestSellers, setBestSellers] = useState<ProductLike[]>([]);
  const [deals, setDeals] = useState<ProductLike[]>([]);
  const [cats, setCats] = useState<Cat[]>([]);

  useEffect(() => {
    fetch("/api/products?flag=featured&limit=5").then((r) => r.json()).then((d) => setFeatured(d.products || []));
    fetch("/api/products?flag=new&limit=5").then((r) => r.json()).then((d) => setNewArrivals(d.products || []));
    fetch("/api/products?flag=bestSeller&limit=5").then((r) => r.json()).then((d) => setBestSellers(d.products || []));
    fetch("/api/products?sort=priceLow&limit=20").then((r) => r.json()).then((d) => {
      const withDisc = (d.products || []).filter((p: ProductLike) => (p.discountPercent || 0) >= 25).slice(0, 5);
      setDeals(withDisc);
    });
    fetch("/api/categories").then((r) => r.json()).then((d) => setCats(d.categories || []));
  }, []);

  const reviews = [
    { name: "Anita K.", text: "Fast delivery and genuine products. Highly recommend SK Sales!", rating: 5 },
    { name: "Bibek T.", text: "Great prices and the COD option is super convenient.", rating: 5 },
    { name: "Sunita R.", text: "Ordered earbuds, arrived next day in Kathmandu. Very happy!", rating: 4 },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-indigo-600 via-indigo-500 to-sky-500 text-white">
        <div className="mx-auto grid max-w-7xl items-center gap-6 px-4 py-10 md:grid-cols-2 md:py-16">
          <div className="animate-fade-up">
            <span className="rounded-full bg-white/20 px-3 py-1 text-xs font-semibold">🇳🇵 Nepal&apos;s Trusted Online Store</span>
            <h1 className="mt-4 text-3xl font-extrabold leading-tight sm:text-4xl md:text-5xl">
              Shop Smart, <br /> Save More at <span className="text-amber-300">SK Sales</span>
            </h1>
            <p className="mt-3 max-w-md text-sm text-indigo-100 sm:text-base">
              Discover quality electronics, fashion, and home essentials at unbeatable prices. Fast delivery across Nepal with eSewa, Bank &amp; COD payment.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/shop" className="rounded-full bg-white px-6 py-3 text-sm font-semibold text-indigo-600 shadow hover:bg-indigo-50">Shop Now</Link>
              <Link href="/deals" className="rounded-full border border-white/60 px-6 py-3 text-sm font-semibold text-white hover:bg-white/10">View Deals</Link>
            </div>
          </div>
          <div className="hidden justify-center md:flex">
            <div className="grid grid-cols-2 gap-4">
              {["🎧", "⌚", "📱", "🔊"].map((e, i) => (
                <div key={i} className="flex h-32 w-32 items-center justify-center rounded-2xl bg-white/15 text-6xl backdrop-blur">{e}</div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Trust bar */}
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-4 px-4 py-4 text-center text-xs sm:grid-cols-4 sm:text-sm">
          <div>🚚 <b>Fast Delivery</b><br /><span className="text-slate-500">Across Nepal</span></div>
          <div>💵 <b>Easy Payment</b><br /><span className="text-slate-500">eSewa / Bank / COD</span></div>
          <div>✅ <b>Genuine Products</b><br /><span className="text-slate-500">Quality assured</span></div>
          <div>📞 <b>24/7 Support</b><br /><span className="text-slate-500">9767948789</span></div>
        </div>
      </div>

      {/* Categories */}
      <Section title="Shop by Category" link="/categories">
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
          {cats.map((c) => (
            <Link key={c.id} href={`/shop?category=${c.slug}`} className="flex flex-col items-center gap-2 rounded-2xl border border-slate-200 bg-white p-4 transition hover:border-indigo-400 hover:shadow">
              <span className="text-3xl">{c.emoji}</span>
              <span className="text-center text-xs font-medium text-slate-700">{c.name}</span>
            </Link>
          ))}
        </div>
      </Section>

      {/* Special Offers banner */}
      <section className="mx-auto max-w-7xl px-4 py-4">
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="rounded-2xl bg-gradient-to-r from-rose-500 to-pink-500 p-6 text-white">
            <p className="text-xs font-semibold uppercase">Special Offer</p>
            <p className="mt-1 text-2xl font-bold">Up to 40% OFF</p>
            <p className="text-sm text-rose-100">On selected electronics</p>
          </div>
          <div className="rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 p-6 text-white">
            <p className="text-xs font-semibold uppercase">Use Code</p>
            <p className="mt-1 text-2xl font-bold">WELCOME10</p>
            <p className="text-sm text-emerald-100">Get 10% off your first order</p>
          </div>
          <div className="rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 p-6 text-white">
            <p className="text-xs font-semibold uppercase">Free Delivery</p>
            <p className="mt-1 text-2xl font-bold">Over Rs. 5,000</p>
            <p className="text-sm text-amber-100">Shop more, save on shipping</p>
          </div>
        </div>
      </section>

      {featured.length > 0 && <Section title="Featured Products" link="/shop?flag=featured"><Grid products={featured} /></Section>}
      {deals.length > 0 && <Section title="🔥 Special Offers & Deals" link="/deals"><Grid products={deals} /></Section>}
      {newArrivals.length > 0 && <Section title="New Arrivals" link="/shop?flag=new"><Grid products={newArrivals} /></Section>}
      {bestSellers.length > 0 && <Section title="Best Sellers" link="/shop?flag=bestSeller"><Grid products={bestSellers} /></Section>}

      {recentlyViewed.length > 0 && (
        <Section title="Recently Viewed">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {recentlyViewed.map((p) => (
              <ProductCard key={p.id} p={{ ...p, price: p.price, originalPrice: p.originalPrice, stock: 10 } as ProductLike} />
            ))}
          </div>
        </Section>
      )}

      {/* Why choose */}
      <Section title="Why Choose SK Sales?">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: "🛡️", t: "Secure Shopping", d: "Encrypted checkout and safe, verified payments." },
            { icon: "🚚", t: "Nationwide Delivery", d: "We deliver to all 7 provinces of Nepal." },
            { icon: "↩️", t: "Easy Returns", d: "Hassle-free returns on eligible orders." },
            { icon: "💬", t: "Local Support", d: "Nepali customer support via phone & email." },
          ].map((f) => (
            <div key={f.t} className="rounded-2xl border border-slate-200 bg-white p-5">
              <div className="text-3xl">{f.icon}</div>
              <h3 className="mt-2 font-semibold text-slate-900">{f.t}</h3>
              <p className="mt-1 text-sm text-slate-500">{f.d}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Reviews */}
      <Section title="What Our Customers Say">
        <div className="grid gap-4 sm:grid-cols-3">
          {reviews.map((r) => (
            <div key={r.name} className="rounded-2xl border border-slate-200 bg-white p-5">
              <Stars rating={r.rating} />
              <p className="mt-2 text-sm text-slate-600">&ldquo;{r.text}&rdquo;</p>
              <p className="mt-3 text-sm font-semibold text-slate-900">— {r.name}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Newsletter */}
      <section className="mx-auto max-w-7xl px-4 py-8">
        <div className="rounded-2xl bg-slate-900 p-8 text-center text-white">
          <h3 className="text-xl font-bold">Stay Updated with SK Sales</h3>
          <p className="mt-1 text-sm text-slate-400">Subscribe for the latest deals and new arrivals.</p>
          <div className="mx-auto mt-4 flex max-w-md gap-2">
            <input placeholder="Enter your email" className="flex-1 rounded-full px-4 py-2 text-sm text-slate-900 outline-none" />
            <button className="rounded-full bg-indigo-600 px-5 py-2 text-sm font-semibold">Subscribe</button>
          </div>
        </div>
      </section>
    </div>
  );
}
