"use client";

import { useEffect, useState, useCallback } from "react";
import { useStore } from "@/components/store";

type Cat = { id: number; name: string; emoji?: string; description?: string; productCount?: number };

export default function AdminCategories() {
  const { toast } = useStore();
  const [cats, setCats] = useState<Cat[]>([]);
  const [form, setForm] = useState({ id: 0, name: "", emoji: "📁", description: "" });
  const [editing, setEditing] = useState(false);

  const load = useCallback(() => {
    fetch("/api/categories").then((r) => r.json()).then((d) => setCats(d.categories || []));
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.name) { toast("Name required", "error"); return; }
    const method = editing ? "PATCH" : "POST";
    const res = await fetch("/api/admin/categories", { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    if ((await res.json()).ok) { toast("Saved"); setForm({ id: 0, name: "", emoji: "📁", description: "" }); setEditing(false); load(); }
  };

  const del = async (id: number) => {
    if (!confirm("Delete category? Products will be uncategorized.")) return;
    await fetch("/api/admin/categories", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    toast("Deleted", "info"); load();
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Categories</h1>
      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 md:col-span-1">
          <h2 className="mb-3 font-semibold">{editing ? "Edit Category" : "Add Category"}</h2>
          <div className="space-y-2">
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Category name" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
            <input value={form.emoji} onChange={(e) => setForm({ ...form, emoji: e.target.value })} placeholder="Emoji" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
            <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Description" rows={2} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
            <div className="flex gap-2">
              <button onClick={save} className="flex-1 rounded-lg bg-indigo-600 py-2 text-sm font-semibold text-white">{editing ? "Update" : "Add"}</button>
              {editing && <button onClick={() => { setEditing(false); setForm({ id: 0, name: "", emoji: "📁", description: "" }); }} className="rounded-lg border border-slate-200 px-3 py-2 text-sm">Cancel</button>}
            </div>
          </div>
        </div>
        <div className="space-y-2 md:col-span-2">
          {cats.map((c) => (
            <div key={c.id} className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-3">
              <div className="flex items-center gap-3"><span className="text-2xl">{c.emoji}</span><div><p className="font-medium">{c.name}</p><p className="text-xs text-slate-400">{c.productCount || 0} products · {c.description}</p></div></div>
              <div className="flex gap-1">
                <button onClick={() => { setForm({ id: c.id, name: c.name, emoji: c.emoji || "📁", description: c.description || "" }); setEditing(true); }} className="rounded bg-slate-100 px-3 py-1.5 text-xs">Edit</button>
                <button onClick={() => del(c.id)} className="rounded bg-rose-100 px-3 py-1.5 text-xs text-rose-600">Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
