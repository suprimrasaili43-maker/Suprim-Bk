"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useStore } from "@/components/store";
import { formatNPR, statusColor } from "@/lib/utils";

type Order = { id: number; orderNumber: string; customerName: string; total: string; paymentMethod: string; paymentStatus: string; receiptUrl?: string; transactionId?: string; createdAt: string };

export default function AdminPayments() {
  const { toast } = useStore();
  const [orders, setOrders] = useState<Order[]>([]);

  const load = useCallback(() => {
    fetch("/api/admin/orders").then((r) => r.json()).then((d) => setOrders(d.orders || []));
  }, []);
  useEffect(() => { load(); }, [load]);

  const setPayment = async (id: number, paymentStatus: string) => {
    await fetch(`/api/admin/orders/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ paymentStatus, ...(paymentStatus === "Paid" ? { status: "Confirmed" } : {}) }) });
    toast("Payment updated"); load();
  };

  const pending = orders.filter((o) => o.paymentStatus === "Pending Verification");
  const others = orders.filter((o) => o.paymentStatus !== "Pending Verification");

  const Row = ({ o }: { o: Order }) => (
    <div className="rounded-2xl border border-slate-200 bg-white p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <Link href={`/admin/orders/${o.id}`} className="font-medium text-indigo-600">{o.orderNumber}</Link>
          <p className="text-xs text-slate-400">{o.customerName} · {o.paymentMethod} · {new Date(o.createdAt).toLocaleDateString()}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-bold">{formatNPR(o.total)}</span>
          <span className={`rounded-full px-2 py-0.5 text-xs ${statusColor(o.paymentStatus)}`}>{o.paymentStatus}</span>
        </div>
      </div>
      {o.transactionId && <p className="mt-1 text-xs text-slate-500">Txn: {o.transactionId}</p>}
      {o.receiptUrl && <a href={o.receiptUrl} target="_blank" rel="noreferrer" className="text-xs text-indigo-600 underline">View receipt →</a>}
      {o.paymentStatus === "Pending Verification" && (
        <div className="mt-2 flex gap-2">
          <button onClick={() => setPayment(o.id, "Paid")} className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white">✔ Verify & Confirm</button>
          <button onClick={() => setPayment(o.id, "Failed")} className="rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-semibold text-white">✘ Reject</button>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Payments</h1>
      <div>
        <h2 className="mb-2 font-semibold text-amber-600">⏳ Awaiting Verification ({pending.length})</h2>
        <div className="space-y-2">
          {pending.map((o) => <Row key={o.id} o={o} />)}
          {pending.length === 0 && <div className="rounded-2xl border border-dashed p-6 text-center text-slate-400">No payments awaiting verification.</div>}
        </div>
      </div>
      <div>
        <h2 className="mb-2 font-semibold">All Payments</h2>
        <div className="space-y-2">{others.map((o) => <Row key={o.id} o={o} />)}</div>
      </div>
    </div>
  );
}
