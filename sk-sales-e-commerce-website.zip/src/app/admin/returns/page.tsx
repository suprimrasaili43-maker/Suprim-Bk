"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useStore } from "@/components/store";
import { statusColor, RETURN_STATUSES } from "@/lib/utils";

type Ret = { id: number; orderId: number; orderNumber?: string; reason?: string; status: string; type: string; createdAt: string };

export default function AdminReturns() {
  const { toast } = useStore();
  const [returns, setReturns] = useState<Ret[]>([]);

  const load = useCallback(() => {
    fetch("/api/admin/returns").then((r) => r.json()).then((d) => setReturns(d.returns || []));
  }, []);
  useEffect(() => { load(); }, [load]);

  const update = async (id: number, status: string) => {
    await fetch("/api/admin/returns", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, status }) });
    toast("Updated"); load();
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Returns & Refunds</h1>
      <div className="space-y-2">
        {returns.map((r) => (
          <div key={r.id} className="rounded-2xl border border-slate-200 bg-white p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <Link href={`/admin/orders/${r.orderId}`} className="font-medium text-indigo-600">{r.orderNumber}</Link>
                <p className="text-xs text-slate-400">{new Date(r.createdAt).toLocaleDateString()} · {r.type}</p>
              </div>
              <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${statusColor(r.status)}`}>{r.status}</span>
            </div>
            <p className="mt-2 text-sm text-slate-600"><b>Reason:</b> {r.reason || "—"}</p>
            <div className="mt-2 flex items-center gap-2">
              <select value={r.status} onChange={(e) => update(r.id, e.target.value)} className="rounded-lg border border-slate-200 px-3 py-1.5 text-sm">
                {RETURN_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
        ))}
        {returns.length === 0 && <div className="rounded-2xl border border-dashed p-8 text-center text-slate-400">No return requests.</div>}
      </div>
    </div>
  );
}
