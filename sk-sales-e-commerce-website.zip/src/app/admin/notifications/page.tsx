"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

type Notif = { id: number; type?: string; title: string; message: string; read: boolean; link?: string; createdAt: string };

export default function AdminNotifications() {
  const [notifs, setNotifs] = useState<Notif[]>([]);

  useEffect(() => {
    fetch("/api/notifications?scope=admin").then((r) => r.json()).then((d) => setNotifs(d.notifications || []));
    fetch("/api/notifications", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ scope: "admin" }) });
  }, []);

  const icon = (t?: string) => {
    if (t?.includes("order")) return "📦";
    if (t?.includes("payment") || t?.includes("bank")) return "💳";
    if (t?.includes("return") || t?.includes("refund")) return "↩️";
    if (t?.includes("customer")) return "👤";
    if (t?.includes("stock")) return "⚠️";
    if (t?.includes("review")) return "⭐";
    return "🔔";
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Notifications</h1>
      <div className="space-y-2">
        {notifs.map((n) => (
          <Link key={n.id} href={n.link || "#"} className={`flex gap-3 rounded-xl border p-3 ${n.read ? "border-slate-200 bg-white" : "border-indigo-200 bg-indigo-50"}`}>
            <span className="text-2xl">{icon(n.type)}</span>
            <div>
              <p className="text-sm font-medium">{n.title}</p>
              <p className="text-xs text-slate-500">{n.message}</p>
              <p className="mt-1 text-[10px] text-slate-400">{new Date(n.createdAt).toLocaleString()}</p>
            </div>
          </Link>
        ))}
        {notifs.length === 0 && <div className="rounded-2xl border border-dashed p-8 text-center text-slate-400">No notifications.</div>}
      </div>
    </div>
  );
}
