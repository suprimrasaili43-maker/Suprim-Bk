"use client";

import { useEffect, useState, useCallback } from "react";
import { useStore } from "@/components/store";
import { formatNPR } from "@/lib/utils";

type Coupon = { id: number; code: string; type: string; value: string; minOrder: string; maxDiscount?: string; expiresAt?: string; usageLimit?: number; usedCount?: number; active: boolean };

export default function AdminCoupons() {
  const { toast } = useStore();
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [form, setForm] = useState({ code: "", type: "percent", value: "", minOrder: "0", maxDiscount: "", usageLimit: "", expiresAt: "" });

  const load = useCallback(() => {
    fetch("/api/admin/coupons").then((r) => r.json()).then((d) => setCoupons(d.coupons || []));
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.code || !form.value) { toast("Code and value required", "error"); return; }
    const res = await fetch("/api/admin/coupons", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const d = await res.json();
    if (d.ok) { toast("Coupon created"); setForm({ code: "", type: "percent", value: "", minOrder: "0", maxDiscount: "", usageLimit: "", expiresAt: "" }); load(); }
    else toast(d.error || "Failed", "error");
  };

  const toggle = async (c: Coupon) => {
    await fetch("/api/admin/coupons", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: c.id, active: !c.active }) });
    load();
  };
  const del = async (id: number) => {
    await fetch("/api/admin/coupons", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    toast("Deleted", "info"); load();
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Coupons & Discounts</h1>
      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <h2 className="mb-3 font-semibold">Create Coupon</h2>
          <div className="space-y-2">
            <input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} placeholder="CODE" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm uppercase" />
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm">
              <option value="percent">Percentage (%)</option>
              <option value="fixed">Fixed Amount (Rs.)</option>
            </select>
            <input value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} type="number" placeholder={form.type === "percent" ? "Discount %" : "Discount Rs."} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
            <input value={form.minOrder} onChange={(e) => setForm({ ...form, minOrder: e.target.value })} type="number" placeholder="Min order Rs." className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
            {form.type === "percent" && <input value={form.maxDiscount} onChange={(e) => setForm({ ...form, maxDiscount: e.target.value })} type="number" placeholder="Max discount Rs. (optional)" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />}
            <input value={form.usageLimit} onChange={(e) => setForm({ ...form, usageLimit: e.target.value })} type="number" placeholder="Usage limit (optional)" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
            <input value={form.expiresAt} onChange={(e) => setForm({ ...form, expiresAt: e.target.value })} type="date" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
            <button onClick={save} className="w-full rounded-lg bg-indigo-600 py-2 text-sm font-semibold text-white">Create</button>
          </div>
        </div>
        <div className="space-y-2 md:col-span-2">
          {coupons.map((c) => (
            <div key={c.id} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-slate-200 bg-white p-4">
              <div>
                <p className="font-bold">{c.code} <span className={`ml-2 rounded-full px-2 py-0.5 text-[10px] ${c.active ? "bg-emerald-100 text-emerald-700" : "bg-slate-200 text-slate-500"}`}>{c.active ? "Active" : "Inactive"}</span></p>
                <p className="text-xs text-slate-500">{c.type === "percent" ? `${c.value}% off` : `${formatNPR(c.value)} off`} · Min {formatNPR(c.minOrder)} · Used {c.usedCount || 0}{c.usageLimit ? `/${c.usageLimit}` : ""}</p>
              </div>
              <div className="flex gap-1">
                <button onClick={() => toggle(c)} className="rounded bg-slate-100 px-3 py-1.5 text-xs">{c.active ? "Disable" : "Enable"}</button>
                <button onClick={() => del(c.id)} className="rounded bg-rose-100 px-3 py-1.5 text-xs text-rose-600">Delete</button>
              </div>
            </div>
          ))}
          {coupons.length === 0 && <div className="rounded-2xl border border-dashed p-8 text-center text-slate-400">No coupons yet.</div>}
        </div>
      </div>
    </div>
  );
}
