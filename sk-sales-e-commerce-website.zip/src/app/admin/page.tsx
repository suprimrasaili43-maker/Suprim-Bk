"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";
import { formatNPR } from "@/lib/utils";

type Stats = {
  totalSales: number; todaySales: number; monthlySales: number; totalOrders: number;
  pendingOrders: number; processingOrders: number; deliveredOrders: number; cancelledOrders: number;
  totalCustomers: number; totalProducts: number; lowStock: number; outOfStock: number;
  pendingPayments: number; pendingReturns: number;
  salesByDay: { date: string; sales: number; orders: number }[];
  bestSellers: { name: string; sold: number }[];
  statusDist: { name: string; value: number }[];
  paymentDist: { name: string; value: number }[];
};

const COLORS = ["#6366f1", "#22c55e", "#f59e0b", "#ef4444", "#06b6d4", "#a855f7", "#ec4899", "#64748b"];

function Card({ label, value, icon, color, href }: { label: string; value: string | number; icon: string; color: string; href?: string }) {
  const inner = (
    <div className="rounded-2xl border border-slate-200 bg-white p-4">
      <div className="flex items-center justify-between">
        <span className={`flex h-10 w-10 items-center justify-center rounded-xl text-lg ${color}`}>{icon}</span>
      </div>
      <p className="mt-3 text-2xl font-bold text-slate-900">{value}</p>
      <p className="text-xs text-slate-500">{label}</p>
    </div>
  );
  return href ? <Link href={href}>{inner}</Link> : inner;
}

export default function AdminOverview() {
  const [s, setS] = useState<Stats | null>(null);

  useEffect(() => {
    fetch("/api/admin/stats").then((r) => r.json()).then(setS);
  }, []);

  if (!s) return <p className="text-slate-400">Loading dashboard...</p>;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">Dashboard Overview</h1>
        <p className="text-sm text-slate-500">Welcome back! Here&apos;s what&apos;s happening at SK Sales.</p>
      </div>

      {/* Alerts */}
      {(s.pendingPayments > 0 || s.pendingReturns > 0 || s.outOfStock > 0 || s.pendingOrders > 0) && (
        <div className="flex flex-wrap gap-2">
          {s.pendingOrders > 0 && <Link href="/admin/orders?status=Pending" className="rounded-full bg-amber-100 px-3 py-1.5 text-xs font-medium text-amber-700">🆕 {s.pendingOrders} pending orders</Link>}
          {s.pendingPayments > 0 && <Link href="/admin/payments" className="rounded-full bg-sky-100 px-3 py-1.5 text-xs font-medium text-sky-700">💳 {s.pendingPayments} payments to verify</Link>}
          {s.pendingReturns > 0 && <Link href="/admin/returns" className="rounded-full bg-purple-100 px-3 py-1.5 text-xs font-medium text-purple-700">↩️ {s.pendingReturns} return requests</Link>}
          {s.outOfStock > 0 && <Link href="/admin/inventory" className="rounded-full bg-rose-100 px-3 py-1.5 text-xs font-medium text-rose-700">📦 {s.outOfStock} out of stock</Link>}
        </div>
      )}

      {/* Sales cards */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Card label="Total Sales" value={formatNPR(s.totalSales)} icon="💰" color="bg-emerald-100" />
        <Card label="Today's Sales" value={formatNPR(s.todaySales)} icon="📅" color="bg-indigo-100" />
        <Card label="Monthly Sales" value={formatNPR(s.monthlySales)} icon="📆" color="bg-sky-100" />
        <Card label="Total Orders" value={s.totalOrders} icon="🛒" color="bg-amber-100" href="/admin/orders" />
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-6">
        <Card label="Pending" value={s.pendingOrders} icon="⏳" color="bg-amber-100" href="/admin/orders?status=Pending" />
        <Card label="Processing" value={s.processingOrders} icon="⚙️" color="bg-sky-100" href="/admin/orders?status=Processing" />
        <Card label="Delivered" value={s.deliveredOrders} icon="✅" color="bg-emerald-100" href="/admin/orders?status=Delivered" />
        <Card label="Cancelled" value={s.cancelledOrders} icon="❌" color="bg-rose-100" href="/admin/orders?status=Cancelled" />
        <Card label="Customers" value={s.totalCustomers} icon="👥" color="bg-purple-100" href="/admin/customers" />
        <Card label="Products" value={s.totalProducts} icon="🛍️" color="bg-indigo-100" href="/admin/products" />
      </div>

      {/* Charts */}
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 lg:col-span-2">
          <h3 className="mb-3 font-semibold">Sales Over Time (7 days)</h3>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={s.salesByDay}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="date" fontSize={11} />
              <YAxis fontSize={11} />
              <Tooltip formatter={(v) => formatNPR(Number(v))} />
              <Line type="monotone" dataKey="sales" stroke="#6366f1" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <h3 className="mb-3 font-semibold">Order Status</h3>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={s.statusDist} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={(e) => e.name}>
                {s.statusDist.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 lg:col-span-2">
          <h3 className="mb-3 font-semibold">Orders Over Time</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={s.salesByDay}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="date" fontSize={11} />
              <YAxis fontSize={11} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="orders" fill="#22c55e" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <h3 className="mb-3 font-semibold">Payment Methods</h3>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={s.paymentDist} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={45} outerRadius={80} label={(e) => e.name}>
                {s.paymentDist.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <h3 className="mb-3 font-semibold">Best-Selling Products</h3>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={s.bestSellers} layout="vertical" margin={{ left: 20 }}>
            <XAxis type="number" fontSize={11} allowDecimals={false} />
            <YAxis type="category" dataKey="name" width={140} fontSize={10} />
            <Tooltip />
            <Bar dataKey="sold" fill="#6366f1" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
