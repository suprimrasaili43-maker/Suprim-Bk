"use client";

import { useEffect, useState, useCallback } from "react";
import { useStore } from "@/components/store";
import { Stars } from "@/components/ui";

type Review = { id: number; productName?: string; userName?: string; rating: number; comment?: string; approved: boolean; createdAt: string };

export default function AdminReviews() {
  const { toast } = useStore();
  const [reviews, setReviews] = useState<Review[]>([]);

  const load = useCallback(() => {
    fetch("/api/admin/reviews").then((r) => r.json()).then((d) => setReviews(d.reviews || []));
  }, []);
  useEffect(() => { load(); }, [load]);

  const toggle = async (r: Review) => {
    await fetch("/api/admin/reviews", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: r.id, approved: !r.approved }) });
    load();
  };
  const del = async (id: number) => {
    await fetch("/api/admin/reviews", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    toast("Deleted", "info"); load();
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Reviews ({reviews.length})</h1>
      <div className="space-y-2">
        {reviews.map((r) => (
          <div key={r.id} className="rounded-2xl border border-slate-200 bg-white p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="flex items-center gap-2"><span className="font-medium">{r.userName}</span><Stars rating={r.rating} /></div>
                <p className="text-xs text-slate-400">on {r.productName} · {new Date(r.createdAt).toLocaleDateString()}</p>
              </div>
              <span className={`rounded-full px-2 py-0.5 text-[10px] ${r.approved ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}>{r.approved ? "Visible" : "Hidden"}</span>
            </div>
            <p className="mt-2 text-sm text-slate-600">{r.comment}</p>
            <div className="mt-2 flex gap-1">
              <button onClick={() => toggle(r)} className="rounded bg-slate-100 px-3 py-1.5 text-xs">{r.approved ? "Hide" : "Approve"}</button>
              <button onClick={() => del(r.id)} className="rounded bg-rose-100 px-3 py-1.5 text-xs text-rose-600">Delete</button>
            </div>
          </div>
        ))}
        {reviews.length === 0 && <div className="rounded-2xl border border-dashed p-8 text-center text-slate-400">No reviews yet.</div>}
      </div>
    </div>
  );
}
