"use client";

import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell } from "recharts";
import { formatNPR } from "@/lib/utils";

type Stats = {
  totalSales: number; monthlySales: number; todaySales: number; totalOrders: number; totalCustomers: number;
  salesByDay: { date: string; sales: number; orders: number }[];
  bestSellers: { name: string; sold: number }[];
  paymentDist: { name: string; value: number }[];
  statusDist: { name: string; value: number }[];
};

const COLORS = ["#6366f1", "#22c55e", "#f59e0b", "#ef4444", "#06b6d4", "#a855f7"];

export default function AdminReports() {
  const [s, setS] = useState<Stats | null>(null);
  useEffect(() => { fetch("/api/admin/stats").then((r) => r.json()).then(setS); }, []);
  if (!s) return <p className="text-slate-400">Loading reports...</p>;

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold">Reports & Analytics</h1>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4"><p className="text-xs text-slate-500">Total Revenue</p><p className="text-xl font-bold">{formatNPR(s.totalSales)}</p></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4"><p className="text-xs text-slate-500">This Month</p><p className="text-xl font-bold">{formatNPR(s.monthlySales)}</p></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4"><p className="text-xs text-slate-500">Total Orders</p><p className="text-xl font-bold">{s.totalOrders}</p></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4"><p className="text-xs text-slate-500">Customers</p><p className="text-xl font-bold">{s.totalCustomers}</p></div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <h3 className="mb-3 font-semibold">Revenue (Last 7 Days)</h3>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={s.salesByDay}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="date" fontSize={11} /><YAxis fontSize={11} />
            <Tooltip formatter={(v) => formatNPR(Number(v))} />
            <Bar dataKey="sales" fill="#6366f1" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <h3 className="mb-3 font-semibold">Best Sellers</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={s.bestSellers} layout="vertical" margin={{ left: 20 }}>
              <XAxis type="number" fontSize={11} allowDecimals={false} />
              <YAxis type="category" dataKey="name" width={130} fontSize={10} />
              <Tooltip /><Bar dataKey="sold" fill="#22c55e" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <h3 className="mb-3 font-semibold">Payment Method Usage</h3>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={s.paymentDist} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={(e) => `${e.name}: ${e.value}`}>
                {s.paymentDist.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
