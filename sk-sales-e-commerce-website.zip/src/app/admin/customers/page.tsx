"use client";

import { useEffect, useState } from "react";
import { formatNPR } from "@/lib/utils";

type Customer = { id: number; name: string; email: string; phone?: string; createdAt: string; orders: number; spent: number };

export default function AdminCustomers() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    fetch("/api/admin/customers").then((r) => r.json()).then((d) => setCustomers(d.customers || []));
  }, []);

  const filtered = customers.filter((c) => (c.name + c.email + (c.phone || "")).toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Customers ({customers.length})</h1>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search customers..." className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
        <table className="w-full min-w-[600px] text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-left text-xs uppercase text-slate-500">
            <tr><th className="p-3">Customer</th><th className="p-3">Contact</th><th className="p-3">Orders</th><th className="p-3">Total Spent</th><th className="p-3">Joined</th></tr>
          </thead>
          <tbody>
            {filtered.map((c) => (
              <tr key={c.id} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="p-3"><div className="flex items-center gap-2"><span className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-100 text-sm font-bold text-indigo-600">{c.name[0]}</span>{c.name}</div></td>
                <td className="p-3 text-slate-500"><p>{c.email}</p><p className="text-xs">{c.phone}</p></td>
                <td className="p-3">{c.orders}</td>
                <td className="p-3 font-semibold">{formatNPR(c.spent)}</td>
                <td className="p-3 text-slate-400">{new Date(c.createdAt).toLocaleDateString()}</td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={5} className="p-8 text-center text-slate-400">No customers found.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
