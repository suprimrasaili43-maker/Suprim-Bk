"use client";

import { useEffect, useState } from "react";
import { useStore } from "@/components/store";
import type { StoreSettings } from "@/lib/settings";

function Field({ label, value, onChange, type = "text" }: { label: string; value: string | number; onChange: (v: string) => void; type?: string }) {
  return (
    <div>
      <label className="text-xs text-slate-500">{label}</label>
      <input type={type} value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
    </div>
  );
}

function Switch({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-sm">
      {label}
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
    </label>
  );
}

export default function AdminSettings() {
  const { toast } = useStore();
  const [s, setS] = useState<StoreSettings | null>(null);
  const [tab, setTab] = useState<"store" | "payment" | "delivery" | "notif" | "security">("store");
  const [pw, setPw] = useState({ currentPassword: "", newPassword: "" });

  useEffect(() => {
    fetch("/api/admin/settings").then((r) => r.json()).then((d) => setS(d.settings));
  }, []);

  if (!s) return <p className="text-slate-400">Loading settings...</p>;

  const set = <K extends keyof StoreSettings>(k: K, v: StoreSettings[K]) => setS({ ...s, [k]: v });

  const save = async () => {
    const res = await fetch("/api/admin/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(s) });
    if ((await res.json()).ok) toast("Settings saved");
    else toast("Failed", "error");
  };

  const changePw = async () => {
    const res = await fetch("/api/profile", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "changePassword", ...pw }) });
    const d = await res.json();
    if (d.ok) { toast("Admin password changed"); setPw({ currentPassword: "", newPassword: "" }); }
    else toast(d.error || "Failed", "error");
  };

  const resetDemo = async () => {
    if (!confirm("This deletes ALL products, categories, orders, reviews and coupons. Continue?")) return;
    const res = await fetch("/api/admin/reset-demo", { method: "POST" });
    if ((await res.json()).ok) toast("Demo data cleared. Add your real products now.");
    else toast("Failed", "error");
  };

  const tabs = [["store", "Store"], ["payment", "Payment"], ["delivery", "Delivery"], ["notif", "Notifications"], ["security", "Security"]] as const;

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Settings</h1>
      <div className="flex flex-wrap gap-2">
        {tabs.map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`rounded-lg px-3 py-1.5 text-sm ${tab === k ? "bg-indigo-600 text-white" : "border border-slate-200 bg-white"}`}>{l}</button>
        ))}
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-5">
        {tab === "store" && (
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Store Name" value={s.storeName} onChange={(v) => set("storeName", v)} />
            <Field label="Store Description" value={s.storeDescription} onChange={(v) => set("storeDescription", v)} />
            <Field label="Phone" value={s.phone} onChange={(v) => set("phone", v)} />
            <Field label="Email" value={s.email} onChange={(v) => set("email", v)} />
            <div className="sm:col-span-2"><Field label="Address" value={s.address} onChange={(v) => set("address", v)} /></div>
          </div>
        )}
        {tab === "payment" && (
          <div className="space-y-4">
            <div>
              <h3 className="mb-2 font-semibold">🟢 eSewa</h3>
              <div className="space-y-2">
                <Switch label="Enable eSewa" checked={s.esewaEnabled} onChange={(v) => set("esewaEnabled", v)} />
                <Field label="eSewa Merchant / Product Code" value={s.esewaMerchantId} onChange={(v) => set("esewaMerchantId", v)} />
                <p className="rounded-lg bg-amber-50 p-2 text-xs text-amber-700">🔒 The eSewa secret key is configured via the <b>ESEWA_SECRET_KEY</b> environment variable on the server and is never exposed to the frontend. Merchant code can also be set via <b>ESEWA_MERCHANT_ID</b>.</p>
              </div>
            </div>
            <div>
              <h3 className="mb-2 font-semibold">🏦 Bank Transfer</h3>
              <div className="grid gap-2 sm:grid-cols-2">
                <Switch label="Enable Bank Transfer" checked={s.bankEnabled} onChange={(v) => set("bankEnabled", v)} />
                <Field label="Bank Name" value={s.bankName} onChange={(v) => set("bankName", v)} />
                <Field label="Account Holder Name" value={s.bankAccountName} onChange={(v) => set("bankAccountName", v)} />
                <Field label="Account Number" value={s.bankAccountNumber} onChange={(v) => set("bankAccountNumber", v)} />
                <Field label="Branch" value={s.bankBranch} onChange={(v) => set("bankBranch", v)} />
                <Field label="QR Code Image URL" value={s.bankQrUrl} onChange={(v) => set("bankQrUrl", v)} />
              </div>
            </div>
            <div>
              <h3 className="mb-2 font-semibold">💵 Cash on Delivery</h3>
              <div className="space-y-2">
                <Switch label="Enable COD" checked={s.codEnabled} onChange={(v) => set("codEnabled", v)} />
                <Field label="COD Note" value={s.codNote} onChange={(v) => set("codNote", v)} />
              </div>
            </div>
          </div>
        )}
        {tab === "delivery" && (
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Delivery Charge (Rs.)" type="number" value={s.deliveryCharge} onChange={(v) => set("deliveryCharge", Number(v))} />
            <Field label="Free Delivery Threshold (Rs.)" type="number" value={s.freeDeliveryThreshold} onChange={(v) => set("freeDeliveryThreshold", Number(v))} />
            <Field label="Tax Percent (%)" type="number" value={s.taxPercent} onChange={(v) => set("taxPercent", Number(v))} />
            <Field label="Delivery Estimate" value={s.deliveryEstimate} onChange={(v) => set("deliveryEstimate", v)} />
          </div>
        )}
        {tab === "notif" && (
          <div className="space-y-2">
            <Switch label="Order Notifications" checked={s.notifyOrders} onChange={(v) => set("notifyOrders", v)} />
            <Switch label="Payment Notifications" checked={s.notifyPayments} onChange={(v) => set("notifyPayments", v)} />
            <Switch label="Stock Alerts" checked={s.notifyStock} onChange={(v) => set("notifyStock", v)} />
          </div>
        )}
        {tab === "security" && (
          <div className="space-y-4">
            <div>
              <h3 className="mb-2 font-semibold">Change Admin Password</h3>
              <div className="space-y-2">
                <input type="password" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} placeholder="Current password" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
                <input type="password" value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} placeholder="New password (min 6)" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
                <button onClick={changePw} className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white">Update Password</button>
              </div>
              <p className="mt-2 rounded-lg bg-slate-50 p-2 text-xs text-slate-500">Sessions use secure HTTP-only cookies with JWT (7-day expiry). Set the <b>AUTH_SECRET</b> env var in production. Admin routes are protected by role-based authorization.</p>
            </div>
            <div>
              <h3 className="mb-2 font-semibold text-rose-600">Danger Zone</h3>
              <button onClick={resetDemo} className="rounded-lg border border-rose-300 px-4 py-2 text-sm text-rose-600 hover:bg-rose-50">Delete All Demo Data</button>
              <p className="mt-1 text-xs text-slate-400">Removes demo products, categories, orders, reviews and coupons so you can add your real inventory.</p>
            </div>
          </div>
        )}
      </div>

      {tab !== "security" && <button onClick={save} className="rounded-lg bg-indigo-600 px-6 py-2.5 text-sm font-semibold text-white">Save Settings</button>}
    </div>
  );
}
