"use client";

import { useEffect, useState, useCallback } from "react";
import { useStore } from "@/components/store";
import { formatNPR } from "@/lib/utils";

type Product = {
  id: number; name: string; sku?: string; brand?: string; categoryId?: number; price: string; originalPrice?: string;
  stock: number; lowStockThreshold?: number; emoji?: string; gradient?: string; featured?: boolean; isNew?: boolean; bestSeller?: boolean; hidden?: boolean;
  description?: string;
};
type Cat = { id: number; name: string };

const GRADIENTS = ["from-indigo-400 to-sky-400", "from-emerald-400 to-teal-400", "from-rose-400 to-pink-400", "from-amber-400 to-orange-400", "from-violet-400 to-purple-400", "from-cyan-400 to-blue-400"];

const EMPTY = { name: "", sku: "", brand: "", categoryId: "", price: "", originalPrice: "", stock: "0", lowStockThreshold: "5", emoji: "📦", gradient: GRADIENTS[0], description: "", featured: false, isNew: false, bestSeller: false, hidden: false };

export default function AdminProducts() {
  const { toast } = useStore();
  const [products, setProducts] = useState<Product[]>([]);
  const [cats, setCats] = useState<Cat[]>([]);
  const [show, setShow] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<typeof EMPTY>(EMPTY);
  const [q, setQ] = useState("");

  const load = useCallback(() => {
    fetch("/api/admin/products").then((r) => r.json()).then((d) => setProducts(d.products || []));
    fetch("/api/categories").then((r) => r.json()).then((d) => setCats(d.categories || []));
  }, []);
  useEffect(() => { load(); }, [load]);

  const openNew = () => { setForm(EMPTY); setEditId(null); setShow(true); };
  const openEdit = (p: Product) => {
    setForm({
      name: p.name, sku: p.sku || "", brand: p.brand || "", categoryId: p.categoryId ? String(p.categoryId) : "",
      price: p.price, originalPrice: p.originalPrice || "", stock: String(p.stock), lowStockThreshold: String(p.lowStockThreshold || 5),
      emoji: p.emoji || "📦", gradient: p.gradient || GRADIENTS[0], description: p.description || "",
      featured: !!p.featured, isNew: !!p.isNew, bestSeller: !!p.bestSeller, hidden: !!p.hidden,
    });
    setEditId(p.id); setShow(true);
  };

  const save = async () => {
    if (!form.name || !form.price) { toast("Name and price required", "error"); return; }
    const url = editId ? `/api/admin/products/${editId}` : "/api/admin/products";
    const method = editId ? "PATCH" : "POST";
    const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    if ((await res.json()).ok) { toast(editId ? "Product updated" : "Product added"); setShow(false); load(); }
    else toast("Failed", "error");
  };

  const del = async (id: number) => {
    if (!confirm("Delete this product?")) return;
    await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
    toast("Deleted", "info"); load();
  };

  const toggleHide = async (p: Product) => {
    await fetch(`/api/admin/products/${p.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ hidden: !p.hidden }) });
    load();
  };

  const filtered = products.filter((p) => p.name.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Products ({products.length})</h1>
        <button onClick={openNew} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">+ Add Product</button>
      </div>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products..." className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />

      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
        <table className="w-full min-w-[700px] text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-left text-xs uppercase text-slate-500">
            <tr><th className="p-3">Product</th><th className="p-3">SKU</th><th className="p-3">Price</th><th className="p-3">Stock</th><th className="p-3">Tags</th><th className="p-3">Actions</th></tr>
          </thead>
          <tbody>
            {filtered.map((p) => (
              <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="p-3"><div className="flex items-center gap-2"><span className={`flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br ${p.gradient}`}>{p.emoji}</span><span className="font-medium">{p.name}</span></div></td>
                <td className="p-3 text-slate-500">{p.sku}</td>
                <td className="p-3 font-semibold">{formatNPR(p.price)}</td>
                <td className="p-3"><span className={p.stock <= 0 ? "text-rose-600" : p.stock <= (p.lowStockThreshold || 5) ? "text-amber-600" : ""}>{p.stock}</span></td>
                <td className="p-3"><div className="flex flex-wrap gap-1">{p.featured && <span className="rounded bg-indigo-100 px-1.5 text-[10px] text-indigo-700">Featured</span>}{p.isNew && <span className="rounded bg-emerald-100 px-1.5 text-[10px] text-emerald-700">New</span>}{p.bestSeller && <span className="rounded bg-amber-100 px-1.5 text-[10px] text-amber-700">Best</span>}{p.hidden && <span className="rounded bg-slate-200 px-1.5 text-[10px]">Hidden</span>}</div></td>
                <td className="p-3"><div className="flex gap-1"><button onClick={() => openEdit(p)} className="rounded bg-slate-100 px-2 py-1 text-xs">Edit</button><button onClick={() => toggleHide(p)} className="rounded bg-slate-100 px-2 py-1 text-xs">{p.hidden ? "Show" : "Hide"}</button><button onClick={() => del(p.id)} className="rounded bg-rose-100 px-2 py-1 text-xs text-rose-600">Del</button></div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {show && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={() => setShow(false)}>
          <div className="absolute inset-0 bg-black/50" />
          <div className="relative max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-5" onClick={(e) => e.stopPropagation()}>
            <h2 className="mb-3 text-lg font-bold">{editId ? "Edit Product" : "Add Product"}</h2>
            <div className="space-y-3">
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Product Name *" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Description" rows={3} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
              <div className="grid grid-cols-2 gap-2">
                <input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} placeholder="SKU" className="rounded-lg border border-slate-200 px-3 py-2 text-sm" />
                <input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} placeholder="Brand" className="rounded-lg border border-slate-200 px-3 py-2 text-sm" />
                <input value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="Selling Price *" type="number" className="rounded-lg border border-slate-200 px-3 py-2 text-sm" />
                <input value={form.originalPrice} onChange={(e) => setForm({ ...form, originalPrice: e.target.value })} placeholder="Original Price" type="number" className="rounded-lg border border-slate-200 px-3 py-2 text-sm" />
                <input value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} placeholder="Stock" type="number" className="rounded-lg border border-slate-200 px-3 py-2 text-sm" />
                <input value={form.lowStockThreshold} onChange={(e) => setForm({ ...form, lowStockThreshold: e.target.value })} placeholder="Low Stock Alert" type="number" className="rounded-lg border border-slate-200 px-3 py-2 text-sm" />
                <select value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })} className="rounded-lg border border-slate-200 px-3 py-2 text-sm">
                  <option value="">No Category</option>
                  {cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
                <input value={form.emoji} onChange={(e) => setForm({ ...form, emoji: e.target.value })} placeholder="Emoji icon" className="rounded-lg border border-slate-200 px-3 py-2 text-sm" />
              </div>
              <div>
                <p className="mb-1 text-xs text-slate-500">Image color theme</p>
                <div className="flex gap-2">
                  {GRADIENTS.map((g) => (
                    <button key={g} onClick={() => setForm({ ...form, gradient: g })} className={`h-8 w-8 rounded-lg bg-gradient-to-br ${g} ${form.gradient === g ? "ring-2 ring-offset-2 ring-indigo-500" : ""}`} />
                  ))}
                </div>
              </div>
              <div className="flex flex-wrap gap-3 text-sm">
                <label className="flex items-center gap-1"><input type="checkbox" checked={form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} /> Featured</label>
                <label className="flex items-center gap-1"><input type="checkbox" checked={form.isNew} onChange={(e) => setForm({ ...form, isNew: e.target.checked })} /> New</label>
                <label className="flex items-center gap-1"><input type="checkbox" checked={form.bestSeller} onChange={(e) => setForm({ ...form, bestSeller: e.target.checked })} /> Best Seller</label>
                <label className="flex items-center gap-1"><input type="checkbox" checked={form.hidden} onChange={(e) => setForm({ ...form, hidden: e.target.checked })} /> Hidden</label>
              </div>
            </div>
            <div className="mt-4 flex gap-2">
              <button onClick={save} className="flex-1 rounded-lg bg-indigo-600 py-2 text-sm font-semibold text-white">Save</button>
              <button onClick={() => setShow(false)} className="rounded-lg border border-slate-200 px-4 py-2 text-sm">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
