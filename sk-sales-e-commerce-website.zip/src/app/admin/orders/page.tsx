"use client";

import { Suspense, useEffect, useState, useCallback } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { formatNPR, statusColor, ORDER_STATUSES } from "@/lib/utils";

type Item = { id: number; name: string; quantity: number; emoji?: string };
type Order = { id: number; orderNumber: string; customerName: string; phone: string; total: string; status: string; paymentMethod: string; paymentStatus: string; createdAt: string; items: Item[] };

function OrdersInner() {
  const params = useSearchParams();
  const [orders, setOrders] = useState<Order[]>([]);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState(params.get("status") || "all");
  const [loading, setLoading] = useState(true);

  const load = useCallback(() => {
    setLoading(true);
    const sp = new URLSearchParams();
    if (q) sp.set("q", q);
    if (status !== "all") sp.set("status", status);
    fetch(`/api/admin/orders?${sp.toString()}`).then((r) => r.json()).then((d) => { setOrders(d.orders || []); setLoading(false); });
  }, [q, status]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Orders</h1>
      <div className="flex flex-wrap gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search order #, name, phone" className="flex-1 rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-indigo-400" />
        <select value={status} onChange={(e) => setStatus(e.target.value)} className="rounded-lg border border-slate-200 px-3 py-2 text-sm">
          <option value="all">All Status</option>
          {ORDER_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {loading ? <p className="text-slate-400">Loading...</p> : (
        <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
          <table className="w-full min-w-[700px] text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-left text-xs uppercase text-slate-500">
              <tr><th className="p-3">Order</th><th className="p-3">Customer</th><th className="p-3">Items</th><th className="p-3">Total</th><th className="p-3">Payment</th><th className="p-3">Status</th><th className="p-3"></th></tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="p-3"><p className="font-medium">{o.orderNumber}</p><p className="text-xs text-slate-400">{new Date(o.createdAt).toLocaleDateString()}</p></td>
                  <td className="p-3"><p>{o.customerName}</p><p className="text-xs text-slate-400">{o.phone}</p></td>
                  <td className="p-3 text-slate-500">{o.items.reduce((a, i) => a + i.quantity, 0)} items</td>
                  <td className="p-3 font-semibold">{formatNPR(o.total)}</td>
                  <td className="p-3"><span className="text-xs">{o.paymentMethod}</span><br /><span className={`rounded-full px-2 py-0.5 text-[10px] ${statusColor(o.paymentStatus)}`}>{o.paymentStatus}</span></td>
                  <td className="p-3"><span className={`rounded-full px-2 py-0.5 text-xs font-medium ${statusColor(o.status)}`}>{o.status}</span></td>
                  <td className="p-3"><Link href={`/admin/orders/${o.id}`} className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white">Manage</Link></td>
                </tr>
              ))}
              {orders.length === 0 && <tr><td colSpan={7} className="p-8 text-center text-slate-400">No orders found.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function AdminOrdersPage() {
  return <Suspense fallback={<p className="text-slate-400">Loading...</p>}><OrdersInner /></Suspense>;
}
