"use client";

import { use, useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useStore } from "@/components/store";
import { formatNPR, statusColor, ORDER_STATUSES } from "@/lib/utils";

type Item = { id: number; name: string; price: string; quantity: number; variant?: string; emoji?: string };
type Order = {
  id: number; orderNumber: string; customerName: string; customerEmail: string; phone: string; status: string;
  paymentMethod: string; paymentStatus: string; subtotal: string; deliveryCharge: string; tax: string; discount: string;
  total: string; deliveryMethod: string; createdAt: string; address: Record<string, string>; note?: string;
  receiptUrl?: string; transactionId?: string;
};

export default function AdminOrderDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { toast } = useStore();
  const [order, setOrder] = useState<Order | null>(null);
  const [items, setItems] = useState<Item[]>([]);

  const load = useCallback(() => {
    fetch(`/api/admin/orders/${id}`).then((r) => r.json()).then((d) => { setOrder(d.order); setItems(d.items || []); });
  }, [id]);
  useEffect(() => { load(); }, [load]);

  if (!order) return <p className="text-slate-400">Loading...</p>;

  const update = async (body: Record<string, unknown>) => {
    const res = await fetch(`/api/admin/orders/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    if ((await res.json()).ok) { toast("Order updated"); load(); }
    else toast("Failed", "error");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Link href="/admin/orders" className="text-sm text-indigo-600">← All orders</Link>
        <Link href={`/invoice/${order.id}`} className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-sm">🧾 Invoice</Link>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div><h1 className="text-lg font-bold">{order.orderNumber}</h1><p className="text-xs text-slate-400">{new Date(order.createdAt).toLocaleString()}</p></div>
              <span className={`rounded-full px-3 py-1 text-sm font-medium ${statusColor(order.status)}`}>{order.status}</span>
            </div>
            <div className="mt-4">
              {items.map((it) => (
                <div key={it.id} className="flex items-center justify-between border-b border-slate-100 py-2 text-sm">
                  <span className="flex items-center gap-2"><span className="text-xl">{it.emoji}</span>{it.name} ×{it.quantity}{it.variant ? ` (${it.variant})` : ""}</span>
                  <span className="font-medium">{formatNPR(Number(it.price) * it.quantity)}</span>
                </div>
              ))}
              <div className="mt-2 space-y-1 text-sm">
                <div className="flex justify-between"><span>Subtotal</span><span>{formatNPR(order.subtotal)}</span></div>
                {Number(order.discount) > 0 && <div className="flex justify-between text-emerald-600"><span>Discount</span><span>− {formatNPR(order.discount)}</span></div>}
                <div className="flex justify-between"><span>Delivery</span><span>{formatNPR(order.deliveryCharge)}</span></div>
                {Number(order.tax) > 0 && <div className="flex justify-between"><span>Tax</span><span>{formatNPR(order.tax)}</span></div>}
                <div className="flex justify-between border-t pt-1 font-bold"><span>Total</span><span className="text-indigo-600">{formatNPR(order.total)}</span></div>
              </div>
            </div>
          </div>

          {order.note && <div className="rounded-2xl border border-slate-200 bg-white p-4 text-sm"><b>Order Note:</b> {order.note}</div>}

          {order.paymentMethod === "Bank" && (
            <div className="rounded-2xl border border-slate-200 bg-white p-4 text-sm">
              <h3 className="font-semibold">Bank Payment Proof</h3>
              {order.transactionId && <p className="mt-1">Transaction ID: <b>{order.transactionId}</b></p>}
              {order.receiptUrl ? (
                <a href={order.receiptUrl} target="_blank" rel="noreferrer" className="mt-1 inline-block text-indigo-600 underline">View uploaded receipt →</a>
              ) : <p className="mt-1 text-slate-400">No receipt uploaded yet.</p>}
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 text-sm">
            <h3 className="mb-2 font-semibold">Customer</h3>
            <p>{order.customerName}</p>
            <p className="text-slate-500">{order.customerEmail}</p>
            <p className="text-slate-500">{order.phone}</p>
            <div className="mt-2 flex gap-2">
              <a href={`tel:${order.phone}`} className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs">📞 Call</a>
              <a href={`mailto:${order.customerEmail}`} className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs">✉️ Email</a>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 text-sm">
            <h3 className="mb-2 font-semibold">Shipping Address</h3>
            <p className="text-slate-600">{order.address?.fullAddress}, {order.address?.area}, {order.address?.city}, {order.address?.district}, {order.address?.province} {order.address?.postalCode}</p>
            <p className="mt-1 text-slate-500">Method: {order.deliveryMethod}</p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4">
            <h3 className="mb-2 font-semibold">Update Order Status</h3>
            <select value={order.status} onChange={(e) => update({ status: e.target.value })} className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm">
              {ORDER_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>

            <h3 className="mb-2 mt-4 font-semibold">Payment Status</h3>
            <div className="flex items-center gap-2">
              <span className={`rounded-full px-2 py-0.5 text-xs ${statusColor(order.paymentStatus)}`}>{order.paymentStatus}</span>
            </div>
            <div className="mt-2 flex flex-wrap gap-2">
              <button onClick={() => update({ paymentStatus: "Paid" })} className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white">✔ Mark Paid</button>
              <button onClick={() => update({ paymentStatus: "Failed" })} className="rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-semibold text-white">✘ Reject</button>
              <button onClick={() => update({ paymentStatus: "Unpaid" })} className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs">Reset</button>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <button onClick={() => update({ status: "Confirmed" })} className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white">Confirm Order</button>
              <button onClick={() => update({ status: "Cancelled" })} className="rounded-lg border border-rose-300 px-3 py-1.5 text-xs text-rose-600">Cancel Order</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
