"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useStore } from "@/components/store";

const NAV = [
  { href: "/admin", label: "Overview", icon: "📊" },
  { href: "/admin/orders", label: "Orders", icon: "📦" },
  { href: "/admin/products", label: "Products", icon: "🛍️" },
  { href: "/admin/categories", label: "Categories", icon: "📁" },
  { href: "/admin/customers", label: "Customers", icon: "👥" },
  { href: "/admin/inventory", label: "Inventory", icon: "📋" },
  { href: "/admin/coupons", label: "Coupons", icon: "🎟️" },
  { href: "/admin/reviews", label: "Reviews", icon: "⭐" },
  { href: "/admin/returns", label: "Returns/Refunds", icon: "↩️" },
  { href: "/admin/notifications", label: "Notifications", icon: "🔔" },
  { href: "/admin/reports", label: "Reports", icon: "📈" },
  { href: "/admin/settings", label: "Settings", icon: "⚙️" },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, authLoading, logout } = useStore();
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    if (!authLoading && (!user || user.role !== "admin")) router.push("/login");
  }, [authLoading, user, router]);

  useEffect(() => {
    if (user?.role === "admin") {
      fetch("/api/notifications?scope=admin").then((r) => r.json()).then((d) => setUnread(d.unread || 0));
    }
  }, [user, pathname]);

  if (authLoading || !user || user.role !== "admin")
    return <div className="p-16 text-center text-slate-400">Loading admin panel...</div>;

  const Sidebar = (
    <div className="flex h-full flex-col">
      <Link href="/admin" className="flex items-center gap-2 border-b border-slate-800 p-4">
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-600 text-lg font-black text-white">SK</span>
        <div><p className="text-sm font-extrabold text-white">SK Sales</p><p className="text-[10px] text-slate-400">Admin Panel</p></div>
      </Link>
      <nav className="flex-1 overflow-y-auto p-2">
        {NAV.map((n) => {
          const active = pathname === n.href || (n.href !== "/admin" && pathname?.startsWith(n.href));
          return (
            <Link key={n.href} href={n.href} onClick={() => setOpen(false)} className={`relative mb-0.5 flex items-center gap-3 rounded-lg px-3 py-2 text-sm ${active ? "bg-indigo-600 text-white" : "text-slate-300 hover:bg-slate-800"}`}>
              <span>{n.icon}</span>{n.label}
              {n.href === "/admin/notifications" && unread > 0 && (
                <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">{unread}</span>
              )}
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-slate-800 p-2">
        <Link href="/" className="mb-1 flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-slate-300 hover:bg-slate-800">🏠 View Store</Link>
        <button onClick={() => { logout(); router.push("/"); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-rose-400 hover:bg-slate-800">🚪 Logout</button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-100">
      {/* Desktop sidebar */}
      <aside className="fixed left-0 top-0 hidden h-full w-60 bg-slate-900 lg:block">{Sidebar}</aside>

      {/* Mobile top bar */}
      <div className="sticky top-0 z-40 flex items-center justify-between bg-slate-900 p-3 text-white lg:hidden">
        <button onClick={() => setOpen(true)} className="text-2xl">☰</button>
        <span className="font-bold">SK Sales Admin</span>
        <Link href="/admin/notifications" className="relative text-xl">🔔{unread > 0 && <span className="absolute -right-2 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[9px] font-bold">{unread}</span>}</Link>
      </div>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden" onClick={() => setOpen(false)}>
          <div className="absolute inset-0 bg-black/50" />
          <div className="absolute left-0 top-0 h-full w-60 animate-slide-in bg-slate-900" onClick={(e) => e.stopPropagation()}>{Sidebar}</div>
        </div>
      )}

      <main className="lg:ml-60">
        <div className="p-4 md:p-6">{children}</div>
      </main>
    </div>
  );
}
