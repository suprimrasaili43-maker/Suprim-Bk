"use client";

import { useEffect, useState, useCallback } from "react";
import { useStore } from "@/components/store";

type Inv = { id: number; name: string; sku?: string; stock: number; lowStockThreshold?: number; soldCount?: number; price: string; emoji?: string };

export default function AdminInventory() {
  const { toast } = useStore();
  const [inv, setInv] = useState<Inv[]>([]);
  const [filter, setFilter] = useState<"all" | "low" | "out">("all");

  const load = useCallback(() => {
    fetch("/api/admin/inventory").then((r) => r.json()).then((d) => setInv(d.inventory || []));
  }, []);
  useEffect(() => { load(); }, [load]);

  const updateStock = async (id: number, stock: number) => {
    await fetch(`/api/admin/products/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ stock }) });
    toast("Stock updated"); load();
  };

  const filtered = inv.filter((p) => {
    if (filter === "out") return p.stock <= 0;
    if (filter === "low") return p.stock > 0 && p.stock <= (p.lowStockThreshold || 5);
    return true;
  });

  const outCount = inv.filter((p) => p.stock <= 0).length;
  const lowCount = inv.filter((p) => p.stock > 0 && p.stock <= (p.lowStockThreshold || 5)).length;

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Inventory Management</h1>
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center"><p className="text-2xl font-bold">{inv.length}</p><p className="text-xs text-slate-500">Total Products</p></div>
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-center"><p className="text-2xl font-bold text-amber-600">{lowCount}</p><p className="text-xs text-amber-600">Low Stock</p></div>
        <div className="rounded-2xl border border-rose-200 bg-rose-50 p-4 text-center"><p className="text-2xl font-bold text-rose-600">{outCount}</p><p className="text-xs text-rose-600">Out of Stock</p></div>
      </div>

      <div className="flex gap-2">
        {(["all", "low", "out"] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={`rounded-lg px-3 py-1.5 text-sm ${filter === f ? "bg-indigo-600 text-white" : "border border-slate-200 bg-white"}`}>
            {f === "all" ? "All" : f === "low" ? "Low Stock" : "Out of Stock"}
          </button>
        ))}
      </div>

      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
        <table className="w-full min-w-[600px] text-sm">
          <thead className="border-b border-slate-200 bg-slate-50 text-left text-xs uppercase text-slate-500">
            <tr><th className="p-3">Product</th><th className="p-3">SKU</th><th className="p-3">Sold</th><th className="p-3">Current Stock</th><th className="p-3">Update</th></tr>
          </thead>
          <tbody>
            {filtered.map((p) => (
              <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="p-3"><span className="mr-2">{p.emoji}</span>{p.name}</td>
                <td className="p-3 text-slate-500">{p.sku}</td>
                <td className="p-3">{p.soldCount || 0}</td>
                <td className="p-3"><span className={p.stock <= 0 ? "font-bold text-rose-600" : p.stock <= (p.lowStockThreshold || 5) ? "font-bold text-amber-600" : "font-medium"}>{p.stock}</span></td>
                <td className="p-3">
                  <div className="flex items-center gap-1">
                    <input type="number" defaultValue={p.stock} id={`stk-${p.id}`} className="w-20 rounded border border-slate-200 px-2 py-1 text-sm" />
                    <button onClick={() => { const el = document.getElementById(`stk-${p.id}`) as HTMLInputElement; updateStock(p.id, Number(el.value)); }} className="rounded bg-indigo-600 px-2 py-1 text-xs text-white">Set</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
