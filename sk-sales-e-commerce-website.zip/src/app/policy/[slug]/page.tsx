import { notFound } from "next/navigation";

const CONTENT: Record<string, { title: string; body: string[] }> = {
  privacy: {
    title: "Privacy Policy",
    body: [
      "At SK Sales, we respect your privacy and are committed to protecting your personal data.",
      "We collect information such as your name, email, phone number, and delivery address only to process your orders and improve your shopping experience.",
      "We never sell your personal information to third parties. Payment credentials are processed securely and are never stored in plain text.",
      "You may request deletion of your account data at any time by contacting us at bksuprim634@gmail.com.",
    ],
  },
  terms: {
    title: "Terms & Conditions",
    body: [
      "By using SK Sales, you agree to these terms and conditions.",
      "All prices are listed in Nepalese Rupees (NPR) and are subject to change without notice.",
      "Orders are confirmed only after payment verification (for online payments) or order confirmation (for COD).",
      "SK Sales reserves the right to cancel any order in case of pricing errors, stock unavailability, or suspected fraud.",
      "For any disputes, please contact our support team at 9767948789.",
    ],
  },
  returns: {
    title: "Return Policy",
    body: [
      "We want you to be fully satisfied with your purchase from SK Sales.",
      "Eligible products can be returned within 7 days of delivery in their original condition and packaging.",
      "To request a return, go to My Orders in your account and select the delivered order.",
      "Refunds are processed after the returned item is received and inspected. Refund timelines depend on your payment method.",
      "Certain items such as personal care products may not be eligible for return due to hygiene reasons.",
    ],
  },
};

export default async function PolicyPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const content = CONTENT[slug];
  if (!content) notFound();

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-2xl font-bold">{content.title}</h1>
      <div className="mt-4 space-y-3 text-sm leading-relaxed text-slate-600">
        {content.body.map((p, i) => (
          <p key={i}>{p}</p>
        ))}
      </div>
      <p className="mt-8 text-xs text-slate-400">Last updated: {new Date().toLocaleDateString()} · Questions? Contact bksuprim634@gmail.com</p>
    </div>
  );
}
