"use client";

import { Suspense, useEffect, useState, useCallback } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { ProductCard, type ProductLike } from "@/components/ui";

type Cat = { id: number; name: string; slug: string; emoji?: string | null };

function ShopInner() {
  const params = useSearchParams();
  const router = useRouter();
  const [products, setProducts] = useState<ProductLike[]>([]);
  const [cats, setCats] = useState<Cat[]>([]);
  const [brands, setBrands] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  const q = params.get("q") || "";
  const category = params.get("category") || "";
  const flag = params.get("flag") || "";
  const [sort, setSort] = useState(params.get("sort") || "newest");
  const [brand, setBrand] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [minRating, setMinRating] = useState("");
  const [inStock, setInStock] = useState(false);

  useEffect(() => {
    fetch("/api/categories").then((r) => r.json()).then((d) => setCats(d.categories || []));
    fetch("/api/products?limit=200").then((r) => r.json()).then((d) => {
      const bs = Array.from(new Set((d.products || []).map((p: ProductLike & { brand?: string }) => p.brand).filter(Boolean))) as string[];
      setBrands(bs);
    });
  }, []);

  const fetchProducts = useCallback(() => {
    setLoading(true);
    const sp = new URLSearchParams();
    if (q) sp.set("q", q);
    if (category) sp.set("category", category);
    if (flag) sp.set("flag", flag);
    if (sort) sp.set("sort", sort);
    if (brand) sp.set("brand", brand);
    if (maxPrice) sp.set("maxPrice", maxPrice);
    if (minRating) sp.set("minRating", minRating);
    if (inStock) sp.set("inStock", "true");
    fetch(`/api/products?${sp.toString()}`)
      .then((r) => r.json())
      .then((d) => setProducts(d.products || []))
      .finally(() => setLoading(false));
  }, [q, category, flag, sort, brand, maxPrice, minRating, inStock]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const setCategory = (slug: string) => {
    const sp = new URLSearchParams(params.toString());
    if (slug) sp.set("category", slug);
    else sp.delete("category");
    router.push(`/shop?${sp.toString()}`);
  };

  const title = q ? `Search: "${q}"` : category ? cats.find((c) => c.slug === category)?.name || "Shop" : flag ? "Products" : "All Products";

  const Filters = (
    <div className="space-y-5 text-sm">
      <div>
        <h4 className="mb-2 font-semibold">Categories</h4>
        <button onClick={() => setCategory("")} className={`block w-full rounded px-2 py-1 text-left ${!category ? "bg-indigo-50 text-indigo-700" : "hover:bg-slate-50"}`}>All</button>
        {cats.map((c) => (
          <button key={c.id} onClick={() => setCategory(c.slug)} className={`block w-full rounded px-2 py-1 text-left ${category === c.slug ? "bg-indigo-50 text-indigo-700" : "hover:bg-slate-50"}`}>
            {c.emoji} {c.name}
          </button>
        ))}
      </div>
      <div>
        <h4 className="mb-2 font-semibold">Brand</h4>
        <select value={brand} onChange={(e) => setBrand(e.target.value)} className="w-full rounded-lg border border-slate-200 px-2 py-1.5">
          <option value="">All Brands</option>
          {brands.map((b) => <option key={b} value={b}>{b}</option>)}
        </select>
      </div>
      <div>
        <h4 className="mb-2 font-semibold">Max Price: {maxPrice ? `Rs. ${maxPrice}` : "Any"}</h4>
        <input type="range" min={500} max={7000} step={500} value={maxPrice || 7000} onChange={(e) => setMaxPrice(e.target.value)} className="w-full" />
      </div>
      <div>
        <h4 className="mb-2 font-semibold">Rating</h4>
        <select value={minRating} onChange={(e) => setMinRating(e.target.value)} className="w-full rounded-lg border border-slate-200 px-2 py-1.5">
          <option value="">Any Rating</option>
          <option value="4">4★ &amp; up</option>
          <option value="3">3★ &amp; up</option>
        </select>
      </div>
      <label className="flex items-center gap-2">
        <input type="checkbox" checked={inStock} onChange={(e) => setInStock(e.target.checked)} /> In stock only
      </label>
      <button onClick={() => { setBrand(""); setMaxPrice(""); setMinRating(""); setInStock(false); }} className="w-full rounded-lg border border-slate-200 py-1.5 text-slate-600">Clear Filters</button>
    </div>
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-bold sm:text-2xl">{title}</h1>
        <div className="flex items-center gap-2">
          <button onClick={() => setShowFilters(true)} className="rounded-lg border border-slate-200 px-3 py-1.5 text-sm lg:hidden">Filters</button>
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="rounded-lg border border-slate-200 px-2 py-1.5 text-sm">
            <option value="newest">Newest</option>
            <option value="priceLow">Price: Low to High</option>
            <option value="priceHigh">Price: High to Low</option>
            <option value="rating">Top Rated</option>
            <option value="popularity">Popularity</option>
          </select>
        </div>
      </div>

      <div className="flex gap-6">
        <aside className="hidden w-56 shrink-0 lg:block">
          <div className="sticky top-40 rounded-2xl border border-slate-200 bg-white p-4">{Filters}</div>
        </aside>

        <div className="flex-1">
          {loading ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {Array.from({ length: 8 }).map((_, i) => <div key={i} className="aspect-[3/4] animate-pulse rounded-2xl bg-slate-200" />)}
            </div>
          ) : products.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-300 p-12 text-center text-slate-500">No products found. Try adjusting filters.</div>
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {products.map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          )}
        </div>
      </div>

      {showFilters && (
        <div className="fixed inset-0 z-[60] lg:hidden" onClick={() => setShowFilters(false)}>
          <div className="absolute inset-0 bg-black/40" />
          <div className="absolute right-0 top-0 h-full w-72 max-w-[85vw] animate-slide-in overflow-y-auto bg-white p-4" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-bold">Filters</h3>
              <button onClick={() => setShowFilters(false)} className="text-2xl">×</button>
            </div>
            {Filters}
          </div>
        </div>
      )}
    </div>
  );
}

export default function ShopPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center text-slate-400">Loading...</div>}>
      <ShopInner />
    </Suspense>
  );
}
