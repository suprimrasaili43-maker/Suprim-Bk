"use client";

import { useEffect, useState } from "react";
import { ProductCard, type ProductLike } from "@/components/ui";

export default function DealsPage() {
  const [products, setProducts] = useState<ProductLike[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/products?limit=200")
      .then((r) => r.json())
      .then((d) => {
        const deals = (d.products || [])
          .filter((p: ProductLike) => (p.discountPercent || 0) > 0)
          .sort((a: ProductLike, b: ProductLike) => (b.discountPercent || 0) - (a.discountPercent || 0));
        setProducts(deals);
      })
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <div className="mb-6 rounded-2xl bg-gradient-to-r from-rose-500 to-pink-500 p-6 text-white">
        <h1 className="text-2xl font-extrabold">🔥 Hot Deals & Discounts</h1>
        <p className="mt-1 text-rose-100">Grab these limited-time offers before they&apos;re gone!</p>
      </div>
      {loading ? (
        <p className="text-center text-slate-400">Loading deals...</p>
      ) : products.length === 0 ? (
        <p className="text-center text-slate-400">No deals right now. Check back soon!</p>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {products.map((p) => <ProductCard key={p.id} p={p} />)}
        </div>
      )}
    </div>
  );
}
