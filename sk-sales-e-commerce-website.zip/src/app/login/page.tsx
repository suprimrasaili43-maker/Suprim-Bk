"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useStore } from "@/components/store";

export default function LoginPage() {
  const router = useRouter();
  const { refreshUser, toast } = useStore();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    setLoading(false);
    if (data.ok) {
      await refreshUser();
      toast("Welcome back!");
      router.push(data.user.role === "admin" ? "/admin" : "/account");
    } else setError(data.error || "Login failed");
  };

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-12">
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h1 className="text-2xl font-bold">Welcome Back</h1>
        <p className="mt-1 text-sm text-slate-500">Login to your SK Sales account.</p>
        {error && <p className="mt-3 rounded-lg bg-rose-50 p-2 text-sm text-rose-600">{error}</p>}
        <form onSubmit={submit} className="mt-4 space-y-3">
          <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="Email" required className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-indigo-400" />
          <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="Password" required className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-indigo-400" />
          <div className="text-right"><Link href="/forgot" className="text-xs text-indigo-600">Forgot password?</Link></div>
          <button disabled={loading} className="w-full rounded-lg bg-indigo-600 py-2.5 text-sm font-semibold text-white disabled:opacity-60">{loading ? "Logging in..." : "Login"}</button>
        </form>
        <p className="mt-4 text-center text-sm text-slate-500">No account? <Link href="/register" className="font-medium text-indigo-600">Register</Link></p>
        <div className="mt-4 rounded-lg bg-slate-50 p-3 text-xs text-slate-500">
          <p className="font-semibold">Demo accounts:</p>
          <p>Customer: ram@example.com / Customer@123</p>
          <p>Admin: use the credentials from your setup (default admin@sksales.com / Admin@123)</p>
        </div>
      </div>
    </div>
  );
}
