"use client";

import { use, useEffect, useState } from "react";
import { formatNPR } from "@/lib/utils";

type Item = { id: number; name: string; price: string; quantity: number; variant?: string };
type Order = {
  orderNumber: string; customerName: string; customerEmail: string; phone: string; createdAt: string;
  paymentMethod: string; paymentStatus: string; subtotal: string; deliveryCharge: string; tax: string; discount: string; total: string;
  address: Record<string, string>;
};

export default function InvoicePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [order, setOrder] = useState<Order | null>(null);
  const [items, setItems] = useState<Item[]>([]);

  useEffect(() => {
    fetch(`/api/orders/${id}`).then((r) => r.json()).then((d) => { setOrder(d.order); setItems(d.items || []); });
  }, [id]);

  if (!order) return <div className="p-16 text-center text-slate-400">Loading invoice...</div>;

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="mb-4 flex justify-between print:hidden">
        <button onClick={() => history.back()} className="text-sm text-indigo-600">← Back</button>
        <button onClick={() => window.print()} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">🖨 Print / Download</button>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-8">
        <div className="flex items-start justify-between border-b border-slate-200 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600 text-lg font-black text-white">SK</span>
              <span className="text-xl font-extrabold">SK Sales</span>
            </div>
            <p className="mt-1 text-xs text-slate-500">Your trusted online shopping store.</p>
            <p className="text-xs text-slate-500">📞 9767948789 · ✉️ bksuprim634@gmail.com</p>
          </div>
          <div className="text-right">
            <h1 className="text-2xl font-bold">INVOICE</h1>
            <p className="text-sm text-slate-600">{order.orderNumber}</p>
            <p className="text-xs text-slate-400">{new Date(order.createdAt).toLocaleDateString()}</p>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="font-semibold text-slate-500">Bill To:</p>
            <p className="font-medium">{order.customerName}</p>
            <p className="text-slate-600">{order.customerEmail}</p>
            <p className="text-slate-600">{order.phone}</p>
          </div>
          <div>
            <p className="font-semibold text-slate-500">Ship To:</p>
            <p className="text-slate-600">{order.address?.fullAddress}, {order.address?.area}</p>
            <p className="text-slate-600">{order.address?.city}, {order.address?.district}, {order.address?.province}</p>
          </div>
        </div>

        <table className="mt-6 w-full text-sm">
          <thead>
            <tr className="border-b-2 border-slate-200 text-left text-xs uppercase text-slate-500">
              <th className="py-2">Item</th><th className="py-2 text-center">Qty</th><th className="py-2 text-right">Unit Price</th><th className="py-2 text-right">Amount</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it) => (
              <tr key={it.id} className="border-b border-slate-100">
                <td className="py-2">{it.name}{it.variant ? ` (${it.variant})` : ""}</td>
                <td className="py-2 text-center">{it.quantity}</td>
                <td className="py-2 text-right">{formatNPR(it.price)}</td>
                <td className="py-2 text-right">{formatNPR(Number(it.price) * it.quantity)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="ml-auto mt-4 max-w-xs space-y-1 text-sm">
          <div className="flex justify-between"><span>Subtotal</span><span>{formatNPR(order.subtotal)}</span></div>
          {Number(order.discount) > 0 && <div className="flex justify-between text-emerald-600"><span>Discount</span><span>− {formatNPR(order.discount)}</span></div>}
          <div className="flex justify-between"><span>Delivery</span><span>{Number(order.deliveryCharge) === 0 ? "Free" : formatNPR(order.deliveryCharge)}</span></div>
          {Number(order.tax) > 0 && <div className="flex justify-between"><span>Tax</span><span>{formatNPR(order.tax)}</span></div>}
          <div className="flex justify-between border-t border-slate-200 pt-1 text-base font-bold"><span>Total</span><span>{formatNPR(order.total)}</span></div>
        </div>

        <div className="mt-4 flex justify-between border-t border-slate-200 pt-4 text-sm">
          <span>Payment: <b>{order.paymentMethod}</b></span>
          <span>Status: <b>{order.paymentStatus}</b></span>
        </div>
        <p className="mt-6 text-center text-xs text-slate-400">Thank you for shopping with SK Sales!</p>
      </div>
    </div>
  );
}
