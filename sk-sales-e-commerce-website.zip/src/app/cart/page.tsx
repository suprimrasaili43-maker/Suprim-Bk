"use client";

import Link from "next/link";
import { useState } from "react";
import { useStore } from "@/components/store";
import { formatNPR } from "@/lib/utils";

export default function CartPage() {
  const { cart, updateQty, removeFromCart, cartSubtotal, toast } = useStore();
  const [code, setCode] = useState("");
  const [discount, setDiscount] = useState(0);
  const [appliedCode, setAppliedCode] = useState("");

  const deliveryCharge = cartSubtotal - discount >= 5000 || cart.length === 0 ? 0 : 100;
  const total = cartSubtotal - discount + deliveryCharge;

  const applyCoupon = async () => {
    const res = await fetch("/api/coupons/validate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, subtotal: cartSubtotal }),
    });
    const data = await res.json();
    if (data.valid) {
      setDiscount(data.discount);
      setAppliedCode(data.code);
      toast(`Coupon applied! You saved ${formatNPR(data.discount)}`);
    } else {
      toast(data.error || "Invalid coupon", "error");
      setDiscount(0);
      setAppliedCode("");
    }
  };

  if (cart.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <div className="text-6xl">🛒</div>
        <h1 className="mt-4 text-2xl font-bold">Your cart is empty</h1>
        <p className="mt-2 text-slate-500">Looks like you haven&apos;t added anything yet.</p>
        <Link href="/shop" className="mt-6 inline-block rounded-full bg-indigo-600 px-6 py-3 text-sm font-semibold text-white">Continue Shopping</Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      <h1 className="mb-4 text-2xl font-bold">Shopping Cart ({cart.length})</h1>
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-3 lg:col-span-2">
          {cart.map((item) => (
            <div key={`${item.id}-${item.variant}`} className="flex gap-3 rounded-2xl border border-slate-200 bg-white p-3">
              <Link href={`/product/${item.slug}`} className={`flex h-20 w-20 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${item.gradient || "from-indigo-400 to-sky-400"}`}>
                <span className="text-3xl">{item.emoji || "📦"}</span>
              </Link>
              <div className="flex flex-1 flex-col">
                <div className="flex items-start justify-between gap-2">
                  <Link href={`/product/${item.slug}`} className="line-clamp-2 text-sm font-medium hover:text-indigo-600">{item.name}</Link>
                  <button onClick={() => removeFromCart(item.id, item.variant)} className="text-slate-400 hover:text-rose-500">🗑</button>
                </div>
                {item.variant && <p className="text-xs text-slate-400">{item.variant}</p>}
                <div className="mt-auto flex items-center justify-between">
                  <div className="flex items-center rounded-lg border border-slate-200">
                    <button onClick={() => updateQty(item.id, item.quantity - 1, item.variant)} className="px-2.5 py-1">−</button>
                    <span className="w-8 text-center text-sm">{item.quantity}</span>
                    <button onClick={() => updateQty(item.id, item.quantity + 1, item.variant)} className="px-2.5 py-1">+</button>
                  </div>
                  <span className="font-bold text-slate-900">{formatNPR(item.price * item.quantity)}</span>
                </div>
              </div>
            </div>
          ))}
          <Link href="/shop" className="inline-block text-sm font-medium text-indigo-600">← Continue Shopping</Link>
        </div>

        <div className="h-fit rounded-2xl border border-slate-200 bg-white p-5">
          <h2 className="mb-3 font-bold">Order Summary</h2>
          <div className="flex gap-2">
            <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Coupon code" className="flex-1 rounded-lg border border-slate-200 px-3 py-2 text-sm uppercase outline-none focus:border-indigo-400" />
            <button onClick={applyCoupon} className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white">Apply</button>
          </div>
          <p className="mt-1 text-xs text-slate-400">Try: WELCOME10, SAVE500, DASHAIN15</p>

          <div className="mt-4 space-y-2 text-sm">
            <div className="flex justify-between"><span>Subtotal</span><span>{formatNPR(cartSubtotal)}</span></div>
            {discount > 0 && <div className="flex justify-between text-emerald-600"><span>Discount ({appliedCode})</span><span>− {formatNPR(discount)}</span></div>}
            <div className="flex justify-between"><span>Delivery</span><span>{deliveryCharge === 0 ? "Free" : formatNPR(deliveryCharge)}</span></div>
            <div className="mt-2 flex justify-between border-t pt-2 text-base font-bold"><span>Total</span><span className="text-indigo-600">{formatNPR(total)}</span></div>
          </div>

          <Link
            href={appliedCode ? `/checkout?coupon=${appliedCode}` : "/checkout"}
            className="mt-4 block rounded-xl bg-indigo-600 py-3 text-center text-sm font-semibold text-white hover:bg-indigo-700"
          >
            Proceed to Checkout
          </Link>
          <div className="mt-3 flex justify-center gap-2 text-xs text-slate-400">
            <span>eSewa</span>·<span>Bank</span>·<span>COD</span>
          </div>
        </div>
      </div>
    </div>
  );
}
