"use client";

import { useState } from "react";
import Link from "next/link";

export default function ForgotPage() {
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState("");
  const [token, setToken] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/auth/forgot", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    const data = await res.json();
    setMsg(data.message || "Check your email.");
    if (data.resetToken) setToken(data.resetToken);
  };

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-12">
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h1 className="text-2xl font-bold">Forgot Password</h1>
        <p className="mt-1 text-sm text-slate-500">Enter your email to receive a reset link.</p>
        {msg && <p className="mt-3 rounded-lg bg-emerald-50 p-2 text-sm text-emerald-700">{msg}</p>}
        {token && (
          <p className="mt-2 rounded-lg bg-amber-50 p-2 text-xs text-amber-700">Demo reset link: <Link className="font-semibold underline" href={`/reset?token=${token}`}>Reset your password →</Link></p>
        )}
        <form onSubmit={submit} className="mt-4 space-y-3">
          <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="Email" required className="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-indigo-400" />
          <button className="w-full rounded-lg bg-indigo-600 py-2.5 text-sm font-semibold text-white">Send Reset Link</button>
        </form>
        <p className="mt-4 text-center text-sm text-slate-500"><Link href="/login" className="font-medium text-indigo-600">Back to Login</Link></p>
      </div>
    </div>
  );
}
