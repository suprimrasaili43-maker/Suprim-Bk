"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type Cat = { id: number; name: string; slug: string; emoji?: string | null; description?: string | null; productCount?: number };

export default function CategoriesPage() {
  const [cats, setCats] = useState<Cat[]>([]);

  useEffect(() => {
    fetch("/api/categories").then((r) => r.json()).then((d) => setCats(d.categories || []));
  }, []);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="text-2xl font-bold">Shop by Category</h1>
      <p className="mt-1 text-slate-500">Browse our full range of product categories.</p>
      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {cats.map((c) => (
          <Link key={c.id} href={`/shop?category=${c.slug}`} className="group rounded-2xl border border-slate-200 bg-white p-6 text-center transition hover:border-indigo-400 hover:shadow-lg">
            <span className="text-5xl transition group-hover:scale-110">{c.emoji}</span>
            <h3 className="mt-3 font-semibold text-slate-800">{c.name}</h3>
            <p className="text-xs text-slate-400">{c.productCount || 0} products</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
