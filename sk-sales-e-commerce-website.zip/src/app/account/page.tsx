"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useStore } from "@/components/store";
import { formatNPR, statusColor } from "@/lib/utils";

type Order = { id: number; orderNumber: string; total: string; status: string; createdAt: string };

export default function AccountDashboard() {
  const { user, wishCount } = useStore();
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    fetch("/api/orders").then((r) => r.json()).then((d) => setOrders(d.orders || []));
  }, []);

  const totalSpent = orders.filter((o) => o.status !== "Cancelled").reduce((s, o) => s + Number(o.total), 0);

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-gradient-to-r from-indigo-600 to-sky-500 p-5 text-white">
        <p className="text-sm text-indigo-100">Welcome back,</p>
        <p className="text-xl font-bold">{user?.name}</p>
      </div>
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center"><p className="text-2xl font-bold">{orders.length}</p><p className="text-xs text-slate-500">Orders</p></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center"><p className="text-2xl font-bold">{wishCount}</p><p className="text-xs text-slate-500">Wishlist</p></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center"><p className="text-lg font-bold">{formatNPR(totalSpent)}</p><p className="text-xs text-slate-500">Total Spent</p></div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-5">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-bold">Recent Orders</h2>
          <Link href="/account/orders" className="text-sm text-indigo-600">View all</Link>
        </div>
        {orders.length === 0 ? (
          <p className="text-sm text-slate-400">No orders yet. <Link href="/shop" className="text-indigo-600">Start shopping</Link></p>
        ) : (
          <div className="space-y-2">
            {orders.slice(0, 5).map((o) => (
              <Link key={o.id} href={`/account/orders/${o.id}`} className="flex items-center justify-between rounded-lg border border-slate-100 p-3 text-sm hover:bg-slate-50">
                <div><p className="font-medium">{o.orderNumber}</p><p className="text-xs text-slate-400">{new Date(o.createdAt).toLocaleDateString()}</p></div>
                <div className="text-right"><p className="font-semibold">{formatNPR(o.total)}</p><span className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${statusColor(o.status)}`}>{o.status}</span></div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
