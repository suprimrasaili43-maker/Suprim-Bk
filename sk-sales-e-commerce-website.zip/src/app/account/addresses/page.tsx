"use client";

import { useEffect, useState, useCallback } from "react";
import { useStore } from "@/components/store";
import { NEPAL_PROVINCES } from "@/lib/utils";

type Address = { id: number; label: string; province: string; district: string; city: string; area: string; fullAddress: string; postalCode: string; phone: string };

export default function AddressesPage() {
  const { toast } = useStore();
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [show, setShow] = useState(false);
  const [form, setForm] = useState({ label: "Home", province: "Bagmati", district: "", city: "", area: "", fullAddress: "", postalCode: "", phone: "" });

  const load = useCallback(() => {
    fetch("/api/profile").then((r) => r.json()).then((d) => setAddresses(d.addresses || []));
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.city || !form.fullAddress) { toast("City and address required", "error"); return; }
    const res = await fetch("/api/profile", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    if ((await res.json()).ok) { toast("Address saved"); setShow(false); load(); }
  };

  const del = async (id: number) => {
    await fetch("/api/profile", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    toast("Address removed", "info");
    load();
  };

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-lg font-bold">Saved Addresses</h2>
        <button onClick={() => setShow(!show)} className="rounded-lg bg-indigo-600 px-4 py-1.5 text-sm font-semibold text-white">+ Add Address</button>
      </div>

      {show && (
        <div className="mb-4 space-y-2 rounded-2xl border border-slate-200 bg-white p-4">
          <div className="grid grid-cols-2 gap-2">
            <input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="Label (Home/Office)" className="rounded-lg border border-slate-200 px-3 py-2 text-sm" />
            <select value={form.province} onChange={(e) => setForm({ ...form, province: e.target.value })} className="rounded-lg border border-slate-200 px-3 py-2 text-sm">{NEPAL_PROVINCES.map((p) => <option key={p}>{p}</option>)}</select>
            <input value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} placeholder="District" className="rounded-lg border border-slate-200 px-3 py-2 text-sm" />
            <input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} placeholder="City *" className="rounded-lg border border-slate-200 px-3 py-2 text-sm" />
            <input value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} placeholder="Area" className="rounded-lg border border-slate-200 px-3 py-2 text-sm" />
            <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="Phone" className="rounded-lg border border-slate-200 px-3 py-2 text-sm" />
          </div>
          <input value={form.fullAddress} onChange={(e) => setForm({ ...form, fullAddress: e.target.value })} placeholder="Full Address *" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
          <button onClick={save} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">Save</button>
        </div>
      )}

      {addresses.length === 0 ? (
        <div className="rounded-2xl border border-dashed p-10 text-center text-slate-400">No saved addresses.</div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {addresses.map((a) => (
            <div key={a.id} className="rounded-2xl border border-slate-200 bg-white p-4 text-sm">
              <div className="flex items-center justify-between"><span className="rounded-full bg-indigo-50 px-2 py-0.5 text-xs font-medium text-indigo-600">{a.label}</span><button onClick={() => del(a.id)} className="text-rose-500">🗑</button></div>
              <p className="mt-2 text-slate-600">{a.fullAddress}, {a.area}, {a.city}, {a.district}, {a.province} {a.postalCode}</p>
              <p className="mt-1 text-slate-500">📞 {a.phone}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
