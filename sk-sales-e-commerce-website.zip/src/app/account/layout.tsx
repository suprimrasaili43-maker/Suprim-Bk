"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect } from "react";
import { useStore } from "@/components/store";

export default function AccountLayout({ children }: { children: React.ReactNode }) {
  const { user, authLoading, logout } = useStore();
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    if (!authLoading && !user) router.push("/login");
  }, [authLoading, user, router]);

  if (authLoading || !user) return <div className="p-16 text-center text-slate-400">Loading...</div>;

  const links = [
    { href: "/account", label: "Dashboard", icon: "📊" },
    { href: "/account/orders", label: "My Orders", icon: "📦" },
    { href: "/account/wishlist", label: "Wishlist", icon: "♥" },
    { href: "/account/addresses", label: "Addresses", icon: "📍" },
    { href: "/account/notifications", label: "Notifications", icon: "🔔" },
    { href: "/account/profile", label: "Profile & Security", icon: "⚙️" },
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      <h1 className="mb-4 text-2xl font-bold">My Account</h1>
      <div className="grid gap-6 md:grid-cols-4">
        <aside className="md:col-span-1">
          <div className="rounded-2xl border border-slate-200 bg-white p-3">
            <div className="mb-2 flex items-center gap-3 border-b border-slate-100 p-2">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-indigo-100 text-lg font-bold text-indigo-600">{user.name[0]}</span>
              <div><p className="text-sm font-semibold">{user.name}</p><p className="text-xs text-slate-400">{user.email}</p></div>
            </div>
            <nav className="flex flex-col gap-1 overflow-x-auto md:overflow-visible">
              <div className="flex gap-1 md:flex-col">
                {links.map((l) => (
                  <Link key={l.href} href={l.href} className={`whitespace-nowrap rounded-lg px-3 py-2 text-sm ${pathname === l.href ? "bg-indigo-50 font-medium text-indigo-700" : "hover:bg-slate-50"}`}>
                    {l.icon} {l.label}
                  </Link>
                ))}
              </div>
              <button onClick={() => { logout(); router.push("/"); }} className="mt-1 rounded-lg px-3 py-2 text-left text-sm text-rose-600 hover:bg-rose-50">🚪 Logout</button>
            </nav>
          </div>
        </aside>
        <div className="md:col-span-3">{children}</div>
      </div>
    </div>
  );
}
