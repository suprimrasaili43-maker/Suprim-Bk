"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

type Notif = { id: number; title: string; message: string; read: boolean; link?: string; createdAt: string };

export default function NotificationsPage() {
  const [notifs, setNotifs] = useState<Notif[]>([]);

  useEffect(() => {
    fetch("/api/notifications?scope=user").then((r) => r.json()).then((d) => setNotifs(d.notifications || []));
    fetch("/api/notifications", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ scope: "user" }) });
  }, []);

  return (
    <div>
      <h2 className="mb-3 text-lg font-bold">Notifications</h2>
      {notifs.length === 0 ? (
        <div className="rounded-2xl border border-dashed p-10 text-center text-slate-400">No notifications.</div>
      ) : (
        <div className="space-y-2">
          {notifs.map((n) => (
            <Link key={n.id} href={n.link || "#"} className={`block rounded-xl border p-3 ${n.read ? "border-slate-200 bg-white" : "border-indigo-200 bg-indigo-50"}`}>
              <p className="text-sm font-medium">{n.title}</p>
              <p className="text-xs text-slate-500">{n.message}</p>
              <p className="mt-1 text-[10px] text-slate-400">{new Date(n.createdAt).toLocaleString()}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
