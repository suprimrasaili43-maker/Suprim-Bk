"use client";

import Link from "next/link";
import { useStore } from "@/components/store";
import { formatNPR } from "@/lib/utils";

export default function WishlistPage() {
  const { wishlist, toggleWishlist, addToCart } = useStore();

  return (
    <div>
      <h2 className="mb-3 text-lg font-bold">My Wishlist ({wishlist.length})</h2>
      {wishlist.length === 0 ? (
        <div className="rounded-2xl border border-dashed p-10 text-center text-slate-400">
          Your wishlist is empty. <Link href="/shop" className="text-indigo-600">Browse products</Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {wishlist.map((p) => (
            <div key={p.id} className="rounded-2xl border border-slate-200 bg-white p-3">
              <Link href={`/product/${p.slug}`} className={`flex aspect-square items-center justify-center rounded-xl bg-gradient-to-br ${p.gradient || "from-indigo-400 to-sky-400"}`}>
                <span className="text-5xl">{p.emoji || "📦"}</span>
              </Link>
              <Link href={`/product/${p.slug}`} className="mt-2 line-clamp-2 block text-sm font-medium hover:text-indigo-600">{p.name}</Link>
              <p className="mt-1 font-bold text-indigo-600">{formatNPR(p.price)}</p>
              <div className="mt-2 flex gap-2">
                <button onClick={() => addToCart({ id: p.id, name: p.name, slug: p.slug, price: p.price, originalPrice: p.originalPrice, emoji: p.emoji, gradient: p.gradient, stock: 99 })} className="flex-1 rounded-lg bg-indigo-600 py-1.5 text-xs font-semibold text-white">Add to Cart</button>
                <button onClick={() => toggleWishlist(p)} className="rounded-lg border border-slate-200 px-2 text-rose-500">🗑</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
