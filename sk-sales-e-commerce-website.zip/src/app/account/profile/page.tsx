"use client";

import { useEffect, useState } from "react";
import { useStore } from "@/components/store";

export default function ProfilePage() {
  const { user, refreshUser, toast } = useStore();
  const [form, setForm] = useState({ name: "", phone: "" });
  const [pw, setPw] = useState({ currentPassword: "", newPassword: "" });

  useEffect(() => { if (user) setForm({ name: user.name, phone: user.phone || "" }); }, [user]);

  const saveProfile = async () => {
    const res = await fetch("/api/profile", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    if ((await res.json()).ok) { toast("Profile updated"); refreshUser(); }
  };

  const changePw = async () => {
    const res = await fetch("/api/profile", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "changePassword", ...pw }) });
    const d = await res.json();
    if (d.ok) { toast("Password changed"); setPw({ currentPassword: "", newPassword: "" }); }
    else toast(d.error || "Failed", "error");
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-slate-200 bg-white p-5">
        <h2 className="mb-3 font-bold">Profile Information</h2>
        <div className="space-y-3">
          <div><label className="text-xs text-slate-500">Full Name</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" /></div>
          <div><label className="text-xs text-slate-500">Email (cannot change)</label><input value={user?.email || ""} disabled className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-400" /></div>
          <div><label className="text-xs text-slate-500">Phone</label><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" /></div>
          <button onClick={saveProfile} className="rounded-lg bg-indigo-600 px-5 py-2 text-sm font-semibold text-white">Save Changes</button>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-5">
        <h2 className="mb-3 font-bold">Change Password</h2>
        <div className="space-y-3">
          <input type="password" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} placeholder="Current password" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
          <input type="password" value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} placeholder="New password (min 6)" className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm" />
          <button onClick={changePw} className="rounded-lg bg-slate-900 px-5 py-2 text-sm font-semibold text-white">Update Password</button>
        </div>
      </div>
    </div>
  );
}
