"use client";

import { use, useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useStore } from "@/components/store";
import { formatNPR, statusColor } from "@/lib/utils";

type Item = { id: number; name: string; emoji?: string; price: string; quantity: number; variant?: string };
type Order = {
  id: number; orderNumber: string; status: string; paymentMethod: string; paymentStatus: string;
  subtotal: string; deliveryCharge: string; tax: string; discount: string; total: string;
  customerName: string; phone: string; createdAt: string; address: Record<string, string>;
};

export default function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { toast } = useStore();
  const [order, setOrder] = useState<Order | null>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [reason, setReason] = useState("");
  const [showReturn, setShowReturn] = useState(false);

  const load = useCallback(() => {
    fetch(`/api/orders/${id}`).then((r) => r.json()).then((d) => { setOrder(d.order); setItems(d.items || []); });
  }, [id]);

  useEffect(() => { load(); }, [load]);

  if (!order) return <p className="text-slate-400">Loading...</p>;

  const act = async (action: string, body: Record<string, unknown> = {}) => {
    const res = await fetch(`/api/orders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, ...body }),
    });
    const d = await res.json();
    if (d.ok) { toast("Done!"); load(); setShowReturn(false); }
    else toast(d.error || "Failed", "error");
  };

  const timeline = ["Pending", "Confirmed", "Processing", "Packed", "Shipped", "Out for Delivery", "Delivered"];
  const currentIdx = timeline.indexOf(order.status);
  const canCancel = !["Shipped", "Out for Delivery", "Delivered", "Cancelled"].includes(order.status);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Link href="/account/orders" className="text-sm text-indigo-600">← Back to orders</Link>
        <Link href={`/invoice/${order.id}`} className="rounded-lg border border-slate-200 px-3 py-1.5 text-sm">🧾 Invoice</Link>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div><h2 className="text-lg font-bold">{order.orderNumber}</h2><p className="text-xs text-slate-400">{new Date(order.createdAt).toLocaleString()}</p></div>
          <span className={`rounded-full px-3 py-1 text-sm font-medium ${statusColor(order.status)}`}>{order.status}</span>
        </div>

        {/* Tracking timeline */}
        {order.status !== "Cancelled" ? (
          <div className="mt-5 flex justify-between overflow-x-auto no-scrollbar">
            {timeline.map((st, i) => (
              <div key={st} className="flex min-w-16 flex-1 flex-col items-center text-center">
                <div className={`flex h-8 w-8 items-center justify-center rounded-full text-xs ${i <= currentIdx ? "bg-emerald-500 text-white" : "bg-slate-200 text-slate-400"}`}>{i <= currentIdx ? "✓" : i + 1}</div>
                <span className={`mt-1 text-[10px] ${i <= currentIdx ? "text-slate-800" : "text-slate-400"}`}>{st}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="mt-4 rounded-lg bg-rose-50 p-3 text-sm text-rose-600">This order was cancelled.</p>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <h3 className="mb-2 font-semibold">Items</h3>
          {items.map((it) => (
            <div key={it.id} className="flex items-center justify-between border-b border-slate-100 py-2 text-sm">
              <span className="flex items-center gap-2"><span className="text-xl">{it.emoji}</span>{it.name} ×{it.quantity}{it.variant ? ` (${it.variant})` : ""}</span>
              <span className="font-medium">{formatNPR(Number(it.price) * it.quantity)}</span>
            </div>
          ))}
          <div className="mt-2 space-y-1 text-sm">
            <div className="flex justify-between"><span>Subtotal</span><span>{formatNPR(order.subtotal)}</span></div>
            {Number(order.discount) > 0 && <div className="flex justify-between text-emerald-600"><span>Discount</span><span>− {formatNPR(order.discount)}</span></div>}
            <div className="flex justify-between"><span>Delivery</span><span>{Number(order.deliveryCharge) === 0 ? "Free" : formatNPR(order.deliveryCharge)}</span></div>
            {Number(order.tax) > 0 && <div className="flex justify-between"><span>Tax</span><span>{formatNPR(order.tax)}</span></div>}
            <div className="flex justify-between border-t pt-1 font-bold"><span>Total</span><span className="text-indigo-600">{formatNPR(order.total)}</span></div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 text-sm">
            <h3 className="mb-2 font-semibold">Delivery Address</h3>
            <p className="text-slate-600">{order.customerName} · {order.phone}</p>
            <p className="text-slate-600">{order.address?.fullAddress}, {order.address?.area}, {order.address?.city}, {order.address?.province}</p>
            <div className="mt-2 flex gap-2">
              <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${statusColor(order.paymentStatus)}`}>{order.paymentStatus}</span>
              <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs">{order.paymentMethod}</span>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4">
            <h3 className="mb-2 font-semibold">Actions</h3>
            <div className="flex flex-wrap gap-2">
              {canCancel && <button onClick={() => act("cancel")} className="rounded-lg border border-rose-300 px-4 py-2 text-sm text-rose-600 hover:bg-rose-50">Cancel Order</button>}
              {order.status === "Delivered" && <button onClick={() => setShowReturn(!showReturn)} className="rounded-lg border border-slate-200 px-4 py-2 text-sm">Request Return/Refund</button>}
              <a href="tel:9767948789" className="rounded-lg border border-slate-200 px-4 py-2 text-sm">📞 Contact Support</a>
            </div>
            {showReturn && (
              <div className="mt-3 space-y-2">
                <textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={2} placeholder="Reason for return..." className="w-full rounded-lg border border-slate-200 p-2 text-sm" />
                <button onClick={() => act("return", { reason })} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">Submit Return Request</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
