"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { formatNPR, statusColor } from "@/lib/utils";

type Item = { id: number; name: string; emoji?: string; quantity: number };
type Order = { id: number; orderNumber: string; total: string; status: string; paymentMethod: string; paymentStatus: string; createdAt: string; items: Item[] };

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/orders").then((r) => r.json()).then((d) => { setOrders(d.orders || []); setLoading(false); });
  }, []);

  if (loading) return <p className="text-slate-400">Loading orders...</p>;

  return (
    <div className="space-y-3">
      <h2 className="text-lg font-bold">My Orders</h2>
      {orders.length === 0 && <div className="rounded-2xl border border-dashed p-10 text-center text-slate-400">No orders yet.</div>}
      {orders.map((o) => (
        <div key={o.id} className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2">
            <div>
              <p className="font-semibold">{o.orderNumber}</p>
              <p className="text-xs text-slate-400">{new Date(o.createdAt).toLocaleString()}</p>
            </div>
            <div className="flex items-center gap-2">
              <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${statusColor(o.status)}`}>{o.status}</span>
              <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${statusColor(o.paymentStatus)}`}>{o.paymentStatus}</span>
            </div>
          </div>
          <div className="mt-2 flex flex-wrap gap-3">
            {o.items.map((it) => (
              <span key={it.id} className="flex items-center gap-1 text-sm text-slate-600"><span className="text-lg">{it.emoji}</span>{it.name} ×{it.quantity}</span>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between">
            <span className="font-bold text-indigo-600">{formatNPR(o.total)}</span>
            <Link href={`/account/orders/${o.id}`} className="rounded-lg bg-indigo-600 px-4 py-1.5 text-sm font-semibold text-white">View / Track</Link>
          </div>
        </div>
      ))}
    </div>
  );
}
