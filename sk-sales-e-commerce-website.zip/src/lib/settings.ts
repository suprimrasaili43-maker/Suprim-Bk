import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

export type StoreSettings = {
  storeName: string;
  storeDescription: string;
  phone: string;
  email: string;
  address: string;
  // delivery
  deliveryCharge: number;
  freeDeliveryThreshold: number;
  taxPercent: number;
  deliveryEstimate: string;
  // payment
  esewaMerchantId: string;
  esewaEnabled: boolean;
  bankEnabled: boolean;
  bankName: string;
  bankAccountName: string;
  bankAccountNumber: string;
  bankBranch: string;
  bankQrUrl: string;
  codEnabled: boolean;
  codNote: string;
  // notifications
  notifyOrders: boolean;
  notifyPayments: boolean;
  notifyStock: boolean;
};

export const DEFAULT_SETTINGS: StoreSettings = {
  storeName: "SK Sales",
  storeDescription: "Your trusted online shopping store.",
  phone: "9767948789",
  email: "bksuprim634@gmail.com",
  address: "Kathmandu, Bagmati Province, Nepal",
  deliveryCharge: 100,
  freeDeliveryThreshold: 5000,
  taxPercent: 0,
  deliveryEstimate: "2-5 business days",
  esewaMerchantId: "",
  esewaEnabled: true,
  bankEnabled: true,
  bankName: "Nabil Bank",
  bankAccountName: "SK Sales Pvt. Ltd.",
  bankAccountNumber: "0000000000000000",
  bankBranch: "Kathmandu",
  bankQrUrl: "",
  codEnabled: true,
  codNote: "Pay in cash when your order is delivered to your doorstep.",
  notifyOrders: true,
  notifyPayments: true,
  notifyStock: true,
};

export async function getSettings(): Promise<StoreSettings> {
  try {
    const rows = await db.select().from(settings).where(eq(settings.id, 1)).limit(1);
    if (rows[0]) {
      return { ...DEFAULT_SETTINGS, ...(rows[0].data as Partial<StoreSettings>) };
    }
  } catch {
    // table may not exist yet
  }
  return DEFAULT_SETTINGS;
}

export async function saveSettings(data: Partial<StoreSettings>) {
  const current = await getSettings();
  const merged = { ...current, ...data };
  const existing = await db.select().from(settings).where(eq(settings.id, 1)).limit(1);
  if (existing[0]) {
    await db.update(settings).set({ data: merged, updatedAt: new Date() }).where(eq(settings.id, 1));
  } else {
    await db.insert(settings).values({ id: 1, data: merged });
  }
  return merged;
}
