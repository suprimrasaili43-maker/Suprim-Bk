import { db } from "@/db";
import {
  users,
  categories,
  products,
  coupons,
  reviews,
  orders,
  orderItems,
  settings,
} from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { DEFAULT_SETTINGS } from "@/lib/settings";
import { slugify, genOrderNumber } from "@/lib/utils";
import { sql } from "drizzle-orm";

const GRADIENTS = [
  "from-indigo-400 to-sky-400",
  "from-emerald-400 to-teal-400",
  "from-rose-400 to-pink-400",
  "from-amber-400 to-orange-400",
  "from-violet-400 to-purple-400",
  "from-cyan-400 to-blue-400",
];

export async function seedDatabase() {
  // ---- Admin + demo customers ----
  const adminEmail = process.env.ADMIN_EMAIL || "admin@sksales.com";
  const adminPassword = process.env.ADMIN_PASSWORD || "Admin@123";

  const adminHash = await hashPassword(adminPassword);
  const custHash = await hashPassword("Customer@123");

  const [admin] = await db
    .insert(users)
    .values({
      name: "SK Admin",
      email: adminEmail,
      phone: "9767948789",
      passwordHash: adminHash,
      role: "admin",
    })
    .returning();

  const [cust] = await db
    .insert(users)
    .values([
      {
        name: "Ram Shrestha",
        email: "ram@example.com",
        phone: "9800000001",
        passwordHash: custHash,
        role: "customer",
      },
      {
        name: "Sita Gurung",
        email: "sita@example.com",
        phone: "9800000002",
        passwordHash: custHash,
        role: "customer",
      },
    ])
    .returning();

  // ---- Categories ----
  const catData = [
    { name: "Electronics", emoji: "📱", description: "Gadgets & devices" },
    { name: "Mobile Accessories", emoji: "🔌", description: "Chargers, cables & more" },
    { name: "Audio", emoji: "🎧", description: "Earphones & speakers" },
    { name: "Fashion", emoji: "👕", description: "Clothing & apparel" },
    { name: "Home & Kitchen", emoji: "🏠", description: "Home essentials" },
    { name: "Beauty & Care", emoji: "💄", description: "Beauty products" },
  ];
  const insertedCats = await db
    .insert(categories)
    .values(catData.map((c) => ({ ...c, slug: slugify(c.name) })))
    .returning();

  const catByName = Object.fromEntries(insertedCats.map((c) => [c.name, c.id]));

  // ---- Products ----
  type P = {
    name: string;
    cat: string;
    brand: string;
    price: number;
    original: number;
    stock: number;
    emoji: string;
    featured?: boolean;
    isNew?: boolean;
    bestSeller?: boolean;
    desc: string;
    variants?: { name: string; options: string[] }[];
    specs?: { label: string; value: string }[];
  };

  const list: P[] = [
    { name: "Wireless Bluetooth Earbuds Pro", cat: "Audio", brand: "SoundMax", price: 2499, original: 3999, stock: 45, emoji: "🎧", featured: true, bestSeller: true, desc: "Premium wireless earbuds with active noise cancellation, 30-hour battery life and crystal-clear sound.", variants: [{ name: "Color", options: ["Black", "White", "Blue"] }], specs: [{ label: "Battery", value: "30 hours" }, { label: "Bluetooth", value: "5.3" }, { label: "Warranty", value: "1 year" }] },
    { name: "Smart Watch Fitness Tracker", cat: "Electronics", brand: "FitPro", price: 3999, original: 6499, stock: 30, emoji: "⌚", featured: true, isNew: true, desc: "Track your health with heart-rate monitor, SpO2, sleep tracking and 100+ sport modes.", variants: [{ name: "Color", options: ["Black", "Rose Gold"] }], specs: [{ label: "Display", value: "1.8 inch AMOLED" }, { label: "Battery", value: "7 days" }, { label: "Water Resistant", value: "IP68" }] },
    { name: "65W Fast USB-C Charger", cat: "Mobile Accessories", brand: "PowerUp", price: 1299, original: 1899, stock: 80, emoji: "🔌", bestSeller: true, desc: "Compact GaN fast charger with dual USB-C and USB-A ports. Charges phones and laptops.", specs: [{ label: "Output", value: "65W" }, { label: "Ports", value: "2C + 1A" }] },
    { name: "Portable Bluetooth Speaker", cat: "Audio", brand: "SoundMax", price: 2199, original: 2999, stock: 25, emoji: "🔊", featured: true, desc: "Waterproof portable speaker with deep bass and 12-hour playtime. Perfect for outdoor.", variants: [{ name: "Color", options: ["Black", "Red", "Green"] }], specs: [{ label: "Power", value: "20W" }, { label: "Battery", value: "12 hours" }, { label: "Rating", value: "IPX7" }] },
    { name: "Power Bank 20000mAh", cat: "Mobile Accessories", brand: "PowerUp", price: 1799, original: 2499, stock: 60, emoji: "🔋", bestSeller: true, isNew: true, desc: "High capacity power bank with fast charging and dual output. Charge multiple devices.", specs: [{ label: "Capacity", value: "20000mAh" }, { label: "Output", value: "22.5W" }] },
    { name: "Premium Cotton T-Shirt", cat: "Fashion", brand: "UrbanWear", price: 899, original: 1299, stock: 120, emoji: "👕", desc: "Soft breathable 100% cotton t-shirt. Comfortable everyday wear.", variants: [{ name: "Size", options: ["S", "M", "L", "XL"] }, { name: "Color", options: ["White", "Black", "Navy"] }], specs: [{ label: "Material", value: "100% Cotton" }] },
    { name: "Stainless Steel Water Bottle", cat: "Home & Kitchen", brand: "HomeLife", price: 799, original: 1199, stock: 90, emoji: "🍶", isNew: true, desc: "Vacuum insulated bottle keeps drinks hot for 12h and cold for 24h.", specs: [{ label: "Capacity", value: "750ml" }, { label: "Material", value: "Stainless Steel" }] },
    { name: "LED Desk Lamp with USB", cat: "Home & Kitchen", brand: "HomeLife", price: 1499, original: 2199, stock: 40, emoji: "💡", featured: true, desc: "Adjustable LED lamp with 3 color modes and built-in USB charging port.", specs: [{ label: "Modes", value: "3 color" }, { label: "Power", value: "10W" }] },
    { name: "Wireless Gaming Mouse", cat: "Electronics", brand: "GamePro", price: 1699, original: 2499, stock: 35, emoji: "🖱️", bestSeller: true, desc: "Ergonomic wireless mouse with 16000 DPI, RGB lighting and 70h battery.", specs: [{ label: "DPI", value: "16000" }, { label: "Battery", value: "70 hours" }] },
    { name: "Vitamin C Face Serum", cat: "Beauty & Care", brand: "GlowUp", price: 1099, original: 1599, stock: 55, emoji: "💧", isNew: true, desc: "Brightening face serum with vitamin C and hyaluronic acid for glowing skin.", specs: [{ label: "Volume", value: "30ml" }] },
    { name: "Mechanical Keyboard RGB", cat: "Electronics", brand: "GamePro", price: 3499, original: 4999, stock: 20, emoji: "⌨️", featured: true, desc: "Hot-swappable mechanical keyboard with blue switches and full RGB backlight.", variants: [{ name: "Switch", options: ["Blue", "Red", "Brown"] }], specs: [{ label: "Switches", value: "Mechanical" }, { label: "Layout", value: "Full Size" }] },
    { name: "USB-C to USB-C Cable 2m", cat: "Mobile Accessories", brand: "PowerUp", price: 499, original: 799, stock: 150, emoji: "🧵", desc: "Durable braided 100W fast charging cable, 2 meter length.", specs: [{ label: "Length", value: "2m" }, { label: "Power", value: "100W" }] },
    { name: "Non-Stick Cookware Set", cat: "Home & Kitchen", brand: "HomeLife", price: 4599, original: 6999, stock: 15, emoji: "🍳", bestSeller: true, desc: "5-piece non-stick cookware set with heat resistant handles.", specs: [{ label: "Pieces", value: "5" }] },
    { name: "Over-Ear Studio Headphones", cat: "Audio", brand: "SoundMax", price: 4299, original: 5999, stock: 22, emoji: "🎧", featured: true, isNew: true, desc: "Studio-grade over-ear headphones with rich bass and comfortable memory foam.", variants: [{ name: "Color", options: ["Black", "Silver"] }], specs: [{ label: "Driver", value: "40mm" }, { label: "Battery", value: "40 hours" }] },
    { name: "Slim Fit Denim Jeans", cat: "Fashion", brand: "UrbanWear", price: 1899, original: 2799, stock: 70, emoji: "👖", desc: "Stretchable slim-fit denim jeans, comfortable and stylish.", variants: [{ name: "Size", options: ["30", "32", "34", "36"] }], specs: [{ label: "Fit", value: "Slim" }] },
    { name: "Matte Lipstick Set of 3", cat: "Beauty & Care", brand: "GlowUp", price: 1299, original: 1899, stock: 48, emoji: "💄", bestSeller: true, desc: "Long-lasting matte lipstick set in 3 gorgeous shades.", specs: [{ label: "Shades", value: "3" }] },
  ];

  const inserted = await db
    .insert(products)
    .values(
      list.map((p, i) => {
        const disc = Math.round(((p.original - p.price) / p.original) * 100);
        return {
          name: p.name,
          slug: slugify(p.name) + "-" + (i + 1),
          description: p.desc,
          sku: "SK-" + (1000 + i),
          brand: p.brand,
          categoryId: catByName[p.cat],
          price: String(p.price),
          originalPrice: String(p.original),
          discountPercent: disc,
          stock: p.stock,
          soldCount: Math.floor(Math.random() * 200),
          emoji: p.emoji,
          gradient: GRADIENTS[i % GRADIENTS.length],
          specs: p.specs || [],
          variants: p.variants || [],
          rating: (3.8 + Math.random() * 1.2).toFixed(2),
          reviewCount: Math.floor(3 + Math.random() * 40),
          featured: !!p.featured,
          isNew: !!p.isNew,
          bestSeller: !!p.bestSeller,
        };
      }),
    )
    .returning();

  // ---- Reviews ----
  const reviewTexts = [
    "Excellent product, highly recommend!",
    "Good quality for the price. Fast delivery.",
    "Works as expected. Happy with my purchase.",
    "Amazing! Better than I expected.",
    "Great value for money. Will buy again.",
  ];
  const revRows: (typeof reviews.$inferInsert)[] = [];
  for (const p of inserted.slice(0, 10)) {
    for (let r = 0; r < 3; r++) {
      revRows.push({
        productId: p.id,
        userId: r % 2 === 0 ? cust.id : admin.id,
        userName: r % 2 === 0 ? "Ram Shrestha" : "Sita Gurung",
        rating: 4 + (r % 2),
        comment: reviewTexts[(p.id + r) % reviewTexts.length],
        approved: true,
      });
    }
  }
  await db.insert(reviews).values(revRows);

  // ---- Coupons ----
  await db.insert(coupons).values([
    { code: "WELCOME10", type: "percent", value: "10", minOrder: "1000", maxDiscount: "1000", active: true, usageLimit: 500 },
    { code: "SAVE500", type: "fixed", value: "500", minOrder: "3000", active: true, usageLimit: 200 },
    { code: "DASHAIN15", type: "percent", value: "15", minOrder: "2000", maxDiscount: "2000", active: true },
  ]);

  // ---- Sample orders ----
  const p1 = inserted[0];
  const p2 = inserted[2];
  const [order1] = await db
    .insert(orders)
    .values({
      orderNumber: genOrderNumber(),
      userId: cust.id,
      customerName: "Ram Shrestha",
      customerEmail: "ram@example.com",
      phone: "9800000001",
      status: "Delivered",
      paymentMethod: "COD",
      paymentStatus: "Paid",
      subtotal: String(Number(p1.price) + Number(p2.price)),
      deliveryCharge: "100",
      total: String(Number(p1.price) + Number(p2.price) + 100),
      deliveryMethod: "Standard Delivery",
      address: { province: "Bagmati", district: "Kathmandu", city: "Kathmandu", area: "Baneshwor", fullAddress: "House 12, Baneshwor", phone: "9800000001" },
    })
    .returning();
  await db.insert(orderItems).values([
    { orderId: order1.id, productId: p1.id, name: p1.name, price: p1.price, quantity: 1, emoji: p1.emoji, gradient: p1.gradient },
    { orderId: order1.id, productId: p2.id, name: p2.name, price: p2.price, quantity: 1, emoji: p2.emoji, gradient: p2.gradient },
  ]);

  const [order2] = await db
    .insert(orders)
    .values({
      orderNumber: genOrderNumber(),
      userId: cust.id,
      customerName: "Ram Shrestha",
      customerEmail: "ram@example.com",
      phone: "9800000001",
      status: "Processing",
      paymentMethod: "eSewa",
      paymentStatus: "Paid",
      subtotal: p1.price,
      deliveryCharge: "100",
      total: String(Number(p1.price) + 100),
      deliveryMethod: "Standard Delivery",
      address: { province: "Bagmati", district: "Lalitpur", city: "Lalitpur", area: "Pulchowk", fullAddress: "Street 5, Pulchowk", phone: "9800000001" },
    })
    .returning();
  await db.insert(orderItems).values([
    { orderId: order2.id, productId: p1.id, name: p1.name, price: p1.price, quantity: 1, emoji: p1.emoji, gradient: p1.gradient },
  ]);

  // ---- Settings ----
  await db.insert(settings).values({ id: 1, data: DEFAULT_SETTINGS }).onConflictDoNothing();

  return { ok: true, admin: adminEmail };
}

export async function isSeeded() {
  try {
    const rows = await db.select({ c: sql<number>`count(*)` }).from(products);
    return Number(rows[0]?.c ?? 0) > 0;
  } catch {
    return false;
  }
}
