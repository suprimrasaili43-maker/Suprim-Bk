export function formatNPR(value: number | string) {
  const n = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(n)) return "Rs. 0";
  return "Rs. " + n.toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

export function slugify(text: string) {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 200);
}

export function genOrderNumber() {
  const d = new Date();
  const y = d.getFullYear().toString().slice(2);
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `SK${y}${(d.getMonth() + 1).toString().padStart(2, "0")}${d
    .getDate()
    .toString()
    .padStart(2, "0")}${rand}`;
}

export const ORDER_STATUSES = [
  "Pending",
  "Confirmed",
  "Processing",
  "Packed",
  "Shipped",
  "Out for Delivery",
  "Delivered",
  "Cancelled",
];

export const RETURN_STATUSES = [
  "Return Requested",
  "Return Approved",
  "Returned",
  "Refunded",
  "Rejected",
];

export const NEPAL_PROVINCES = [
  "Koshi",
  "Madhesh",
  "Bagmati",
  "Gandaki",
  "Lumbini",
  "Karnali",
  "Sudurpashchim",
];

export function statusColor(status: string) {
  switch (status) {
    case "Delivered":
    case "Return Approved":
    case "Refunded":
    case "Paid":
    case "Confirmed":
      return "bg-emerald-100 text-emerald-700";
    case "Cancelled":
    case "Rejected":
    case "Failed":
      return "bg-red-100 text-red-700";
    case "Pending":
    case "Unpaid":
    case "Return Requested":
      return "bg-amber-100 text-amber-700";
    case "Shipped":
    case "Out for Delivery":
    case "Processing":
    case "Packed":
      return "bg-sky-100 text-sky-700";
    default:
      return "bg-slate-100 text-slate-700";
  }
}
