import { db } from "@/db";
import { notifications } from "@/db/schema";

export async function notifyAdmin(opts: {
  type: string;
  title: string;
  message: string;
  link?: string;
}) {
  await db.insert(notifications).values({
    forAdmin: true,
    type: opts.type,
    title: opts.title,
    message: opts.message,
    link: opts.link,
  });
}

export async function notifyUser(
  userId: number,
  opts: { type: string; title: string; message: string; link?: string },
) {
  await db.insert(notifications).values({
    userId,
    forAdmin: false,
    type: opts.type,
    title: opts.title,
    message: opts.message,
    link: opts.link,
  });
}
